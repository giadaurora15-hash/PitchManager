import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/home_screen.dart';
import 'screens/event_create_screen.dart';
import 'screens/booking_create_screen.dart';
import 'screens/auth/login_screen.dart';
import 'state/app_state.dart';
import 'services/offline_sync_service.dart';
import 'widgets/offline_banner.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const PitchManagerApp());
}

class PitchManagerApp extends StatelessWidget {
  const PitchManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..load(),
      child: const _Bootstrap(),
    );
  }
}

class _Bootstrap extends StatefulWidget {
  const _Bootstrap({super.key});

  @override
  State<_Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<_Bootstrap> {
  OfflineSyncService? _sync;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final app = context.read<AppState>();
      _sync = OfflineSyncService(app);
      await _sync!.start();
    });
  }

  @override
  void dispose() {
    _sync?.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, app, _) {
        return MaterialApp(
          title: 'PitchManager',
          themeMode: app.themeMode,
          theme: AppThemes.light(app.schemeId),
          darkTheme: AppThemes.dark(app.schemeId),
          routes: {
            '/booking_create': (_) => const BookingCreateScreen(),
            '/event_create': (_) => const EventCreateScreen(),
          },
          builder: (context, child) {
            if (child == null) return const SizedBox.shrink();
            return OfflineBanner(child: child);
          },
          home: app.isAuthed ? const HomeScreen() : const LoginScreen(),
        );
      },
    );
  }
}
