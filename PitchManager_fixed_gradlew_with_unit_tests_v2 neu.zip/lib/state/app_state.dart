import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import '../services/api_client.dart';

class AppState extends ChangeNotifier {
  static const _tokenKey = 'jwt_token';
  static const _themeModeKey = 'theme_mode';
  static const _schemeKey = 'color_scheme';

  String _token = '';
  String get token => _token;

  /// Convenience API client bound to the current auth token.
  ///
  /// Screens use `context.read<AppState>().api`.
  /// Creating the client is cheap; it just holds the token and helpers.
  ApiClient get api => ApiClient(token: _token);

  bool _isOnline = true;
  bool get isOnline => _isOnline;

  int _queueCount = 0;
  int get queueCount => _queueCount;

  bool get isAuthed => _token.isNotEmpty;

  String _role = '';
  String get role => _role;
  bool get canManageCourts => _role == 'admin' || _role == 'trainer';
  bool get canInviteUsers => _role == 'admin' || _role == 'trainer';

  ThemeMode _themeMode = ThemeMode.system;
  ThemeMode get themeMode => _themeMode;

  /// Selected color scheme id. See lib/theme/app_theme.dart
  String _schemeId = 'pitchmanager';
  String get schemeId => _schemeId;

void setOnline(bool v) {
  if (_isOnline == v) return;
  _isOnline = v;
  notifyListeners();
}

void setQueueCount(int v) {
  if (_queueCount == v) return;
  _queueCount = v;
  notifyListeners();
}

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_tokenKey) ?? '';
    _role = _extractRoleFromJwt(_token);

    final modeStr = prefs.getString(_themeModeKey) ?? 'system';
    _themeMode = switch (modeStr) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };

    _schemeId = prefs.getString(_schemeKey) ?? 'pitchmanager';
    notifyListeners();
  }

  String _extractRoleFromJwt(String token) {
    if (token.isEmpty) return '';
    try {
      final parts = token.split('.');
      if (parts.length < 2) return '';
      final payload = parts[1];
      final normalized = base64Url.normalize(payload);
      final jsonStr = utf8.decode(base64Url.decode(normalized));
      final data = jsonDecode(jsonStr) as Map<String, dynamic>;
      final role = data['role'];
      return role is String ? role : '';
    } catch (_) {
      return '';
    }
  }

  Future<void> setToken(String token) async {
    _token = token;
    _role = _extractRoleFromJwt(token);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    final prefs = await SharedPreferences.getInstance();
    final str = switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      _ => 'system',
    };
    await prefs.setString(_themeModeKey, str);
    notifyListeners();
  }

  Future<void> setColorScheme(String schemeId) async {
    _schemeId = schemeId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_schemeKey, schemeId);
    notifyListeners();
  }

  Future<void> logout() async {
    _token = '';
    _role = '';
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    notifyListeners();
  }
}
