import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../app_config.dart';
import '../models/booking.dart';
import '../models/court.dart';
import '../models/event.dart';
import 'offline_cache.dart';
import 'offline_queue.dart';

class ApiClient {
  final OfflineCache _cache = OfflineCache();
  final OfflineQueue _queue = OfflineQueue();

  final String? token;
  ApiClient({required this.token});

  Map<String, String> _headers({bool json = false}) {
    return {
      if (json) 'Content-Type': json ? 'application/json' : 'application/json',
      if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }
Future<String> _getWithCache(String path, {String cacheKey = ''}) async {
  final key = cacheKey.isEmpty ? path : cacheKey;
  try {
    final res = await http.get(Uri.parse('${AppConfig.baseUrl}$path'), headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('GET $path failed (${res.statusCode})');
    }
    await _cache.put(key, res.body);
    return res.body;
  } on SocketException catch (_) {
    final cached = await _cache.get(key);
    if (cached != null) return cached;
    rethrow;
  } catch (_) {
    final cached = await _cache.get(key);
    if (cached != null) return cached;
    rethrow;
  }
}

Future<http.Response> _writeOrQueue({
  required String method,
  required String path,
  required Map<String, dynamic> body,
}) async {
  final uri = Uri.parse('${AppConfig.baseUrl}$path');
  try {
    late http.Response res;
    final payload = jsonEncode(body);
    if (method == 'POST') {
      res = await http.post(uri, headers: _headers(json: true), body: payload);
    } else if (method == 'PATCH') {
      res = await http.patch(uri, headers: _headers(json: true), body: payload);
    } else if (method == 'PUT') {
      res = await http.put(uri, headers: _headers(json: true), body: payload);
    } else if (method == 'DELETE') {
      res = await http.delete(uri, headers: _headers(json: true), body: payload);
    } else {
      res = await http.post(uri, headers: _headers(json: true), body: payload);
    }
    return res;
  } on SocketException catch (_) {
    final item = OfflineQueueItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      method: method,
      path: path,
      body: body,
      createdAtMs: DateTime.now().millisecondsSinceEpoch,
    );
    await _queue.add(item);
    // Return a synthetic response for UI logic
    return http.Response(jsonEncode({'queued': true, 'path': path, 'body': body}), 202);
  }
}


  Future<String> login({required String email, required String password}) async {
    // FastAPI OAuth2PasswordRequestForm expects x-www-form-urlencoded
    final res = await http.post(
      Uri.parse('${AppConfig.baseUrl}/auth/login'),
      headers: {
        if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'username': email,
        'password': password,
      },
    );
    if (res.statusCode != 200) {
      throw Exception('Login fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    return j['access_token'] as String;
  }

  Future<List<Booking>> listBookings() async {
    final res = await http.get(
      Uri.parse('${AppConfig.baseUrl}/bookings'),
      headers: _headers(),
    );
    if (res.statusCode != 200) {
      throw Exception('Buchungen laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final data = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    return data.map(Booking.fromJson).toList();
  }

  Future<Booking> createBooking({
    required String bookingType,
    required int courtId,
    required DateTime startDt,
    required DateTime endDt,
    required int segmentMask,
    String? ageGroup,
    int? clubId,
    int? opponentClubId,
    bool overrideFullFieldRule = false,
    double? weatherLat,
    double? weatherLon,
    String? weatherLocationLabel,
  }) async {
    final payload = {
      'booking_type': bookingType,
      'court_id': courtId,
      'start_dt': startDt.toIso8601String(),
      'end_dt': endDt.toIso8601String(),
      'segment_mask': segmentMask,
      'age_group': ageGroup,
      'club_id': clubId,
      'opponent_club_id': opponentClubId,
      'override_full_field_rule': overrideFullFieldRule,
      'weather_lat': weatherLat,
      'weather_lon': weatherLon,
      'weather_location_label': weatherLocationLabel,
    };
    final res = await _writeOrQueue(method: 'POST', path: '/bookings', body: payload);
    if (res.statusCode == 202) {
      // offline queued (optimistic local object + cache update)
      final now = DateTime.now().millisecondsSinceEpoch;

      try {
        final existing = await _cache.get('bookings');
        if (existing != null) {
          final arr = (jsonDecode(existing) as List).cast<dynamic>();
          arr.insert(0, {
            'id': -now,
            'court_id': payload['court_id'],
            'booking_type': payload['booking_type'],
            'segment_mask': payload['segment_mask'],
            'start_dt': payload['start_dt'],
            'end_dt': payload['end_dt'],
            'status': 'queued',
            'series_id': null,
            'team_id': payload['team_id'],
          });
          await _cache.put('bookings', jsonEncode(arr));
        }
      } catch (_) {}

      return Booking(
        id: -now,
        courtId: payload['court_id'] as int,
        bookingType: payload['booking_type'] as String,
        startDt: DateTime.parse(payload['start_dt'] as String),
        endDt: DateTime.parse(payload['end_dt'] as String),
        segmentMask: payload['segment_mask'] as int,
        status: 'queued',
        ageGroup: payload['age_group'] as String?,
        clubId: payload['club_id'] as int?,
        opponentClubId: payload['opponent_club_id'] as int?,
        seriesId: null,
        teamId: payload['team_id'] as int?,
      );
    }
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('Buchung erstellen fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return Booking.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<void> cancelBooking(int bookingId) async {
    final res = await http.post(
      Uri.parse('${AppConfig.baseUrl}/bookings/$bookingId/cancel'),
      headers: _headers(),
    );
    if (res.statusCode != 200) {
      throw Exception('Storno fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
  }

  Future<Map<String, dynamic>> weatherAtTime({required int courtId, required DateTime timeUtc, double? lat, double? lon}) async {
    final uri = Uri.parse('${AppConfig.baseUrl}/weather/at_time')
        .replace(queryParameters: {
      if (lat != null && lon != null) 'lat': lat.toString(),
      if (lat != null && lon != null) 'lon': lon.toString(),
      if (lat == null || lon == null) 'court_id': courtId.toString(),
      'time_utc': timeUtc.toIso8601String(),
    });
    final res = await http.get(uri, headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Wetter laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> weatherCurrent({required int courtId, double? lat, double? lon}) async {
    final uri = Uri.parse('${AppConfig.baseUrl}/weather/current').replace(queryParameters: {
      if (lat != null && lon != null) 'lat': lat.toString(),
      if (lat != null && lon != null) 'lon': lon.toString(),
      if (lat == null || lon == null) 'court_id': courtId.toString(),
    });
    final res = await http.get(uri, headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Wetter laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<Court>> listCourts() async {
    final res = await http.get(
      Uri.parse('${AppConfig.baseUrl}/courts'),
      headers: _headers(),
    );
    if (res.statusCode != 200) {
      throw Exception('Plätze laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final data = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    return data.map(Court.fromJson).toList();
  }

  Future<Court> updateCourt({
    required int courtId,
    String? name,
    double? latitude,
    double? longitude,
  }) async {
    final payload = <String, dynamic>{};
    if (name != null) payload['name'] = name;
    if (latitude != null) payload['latitude'] = latitude;
    if (longitude != null) payload['longitude'] = longitude;

    final res = await http.put(
      Uri.parse('${AppConfig.baseUrl}/courts/$courtId'),
      headers: _headers(json: true),
      body: jsonEncode(payload),
    );
    if (res.statusCode != 200) {
      throw Exception('Platz speichern fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return Court.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  // -------- Events --------
  Future<List<Event>> listEvents() async {
    final res = await http.get(Uri.parse('${AppConfig.baseUrl}/events'), headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Events laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final data = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    return data.map(Event.fromJson).toList();
  }

  Future<Event> getEvent(int eventId) async {
    final res = await http.get(Uri.parse('${AppConfig.baseUrl}/events/$eventId'), headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Event laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return Event.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<Event> createEvent({
    required String title,
    required String eventType,
    String? description,
    int? courtId,
    String? locationLabel,
    required DateTime startDt,
    required DateTime endDt,
    int? capacity,
    bool isPublic = false,
    double? weatherLat,
    double? weatherLon,
    String? weatherLocationLabel,
    int? teamId,
  }) async {
    final payload = {
      'title': title,
      'event_type': eventType,
      'description': description,
      'court_id': courtId,
      'location_label': locationLabel,
      'start_dt': startDt.toIso8601String(),
      'end_dt': endDt.toIso8601String(),
      'capacity': capacity,
      if (teamId != null) 'team_id': teamId,
      'is_public': isPublic,
      'weather_lat': weatherLat,
      'weather_lon': weatherLon,
      'weather_location_label': weatherLocationLabel,
    };
    final res = await _writeOrQueue(method: 'POST', path: '/events', body: payload);
    if (res.statusCode == 202) {
      final now = DateTime.now().millisecondsSinceEpoch;
      return Event(
        id: -now,
        title: payload['title'] as String,
        eventType: payload['event_type'] as String,
        description: payload['description'] as String?,
        courtId: payload['court_id'] as int?,
        locationLabel: payload['location_label'] as String?,
        startDt: DateTime.parse(payload['start_dt'] as String),
        endDt: DateTime.parse(payload['end_dt'] as String),
        capacity: payload['capacity'] as int?,
        isPublic: (payload['is_public'] as bool?) ?? false,
        weatherLat: (payload['weather_lat'] as num?)?.toDouble(),
        weatherLon: (payload['weather_lon'] as num?)?.toDouble(),
        weatherLocationLabel: payload['weather_location_label'] as String?,
        createdBy: 0,
      );
    }
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('Event erstellen fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return Event.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<List<EventParticipant>> listEventParticipants(int eventId) async {
    final res = await http.get(
      Uri.parse('${AppConfig.baseUrl}/events/$eventId/participants'),
      headers: _headers(),
    );
    if (res.statusCode != 200) {
      throw Exception('Teilnehmer laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final data = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    return data.map(EventParticipant.fromJson).toList();
  }

  Future<List<EventParticipant>> inviteToEvent(int eventId, List<String> emails) async {
    final payload = {
      'emails': emails,
    };
    final res = await http.post(
      Uri.parse('${AppConfig.baseUrl}/events/$eventId/invite'),
      headers: _headers(json: true),
      body: jsonEncode(payload),
    );
    if (res.statusCode != 200) {
      throw Exception('Einladungen fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    final data = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    return data.map(EventParticipant.fromJson).toList();
  }

  Future<Map<String, dynamic>> sendEventReminders(int eventId, {String onlyStatus = 'invited'}) async {
    final uri = Uri.parse('${AppConfig.baseUrl}/events/$eventId/remind').replace(queryParameters: {
      'only_status': onlyStatus,
    });
    final res = await http.post(uri, headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Erinnerungen fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<int>> downloadEventIcs(int eventId) async {
    final res = await http.get(Uri.parse('${AppConfig.baseUrl}/events/$eventId/ics'), headers: _headers());
    if (res.statusCode != 200) {
      throw Exception('Kalenderdatei laden fehlgeschlagen (${res.statusCode}): ${res.body}');
    }
    return res.bodyBytes;
  }


  Future<String> registerWithInvite({
    required String token,
    required String email,
    required String password,
    String? fullName,
  }) async {
    final res = await http.post(
      Uri.parse('${AppConfig.apiBaseUrl}/auth/register-with-invite'),
      headers: _headers(json: true),
      body: jsonEncode({
        'token': token,
        'email': email,
        'password': password,
        'full_name': fullName,
      }),
    );
    if (res.statusCode != 200) {
      throw Exception('Registrierung fehlgeschlagen: ${res.body}');
    }
    final data = jsonDecode(res.body);
    return data['access_token'] as String;
  }
  
  Future<List<Map<String, dynamic>>> createInvites({
    required String role,
    required List<String> emails,
    String? relatedPlayerEmail,
    int expiresInDays = 14,
  }) async {
    final res = await http.post(
      Uri.parse('${AppConfig.apiBaseUrl}/invites'),
      headers: _headers(json: true),
      body: jsonEncode({
        'role': role,
        'emails': emails,
        'related_player_email': relatedPlayerEmail,
        'expires_in_days': expiresInDays,
      }),
    );
    if (res.statusCode != 200) {
      throw Exception('Einladungen fehlgeschlagen: ${res.body}');
    }
    return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
  }


  Future<List<dynamic>> listTeams({String? q}) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/teams${q != null ? '?q=' + Uri.encodeQueryComponent(q) : ''}');
    final res = await http.get(uri, headers: _headers());
    if (res.statusCode >= 400) {
      throw Exception('Teams laden fehlgeschlagen: ${res.body}');
    }
    return jsonDecode(res.body) as List<dynamic>;
  }
  
  Future<Map<String, dynamic>> createTeam({required String name, String? description}) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/teams');
    final body = {
      'name': name,
      'description': description,
    };
    final res = await http.post(uri, headers: _headers(json: true), body: jsonEncode(body));
    if (res.statusCode >= 400) {
      throw Exception('Team erstellen fehlgeschlagen: ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }


  Future<void> inviteEventTeam({required int eventId, required int teamId}) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/events/$eventId/invite_team?team_id=$teamId');
    final res = await http.post(uri, headers: _headers());
    if (res.statusCode >= 400) {
      throw Exception('Team einladen fehlgeschlagen: ${res.body}');
    }
  }


  Future<Map<String, dynamic>> createSeries({
    required String title,
    required String bookingType,
    required int courtId,
    required DateTime startDt,
    required DateTime endDt,
    required String rrule,
    int segmentMask = 15,
    bool overrideFullFieldRule = false,
    int? teamId,
  }) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/series');
    final body = {
      'title': title,
      'booking_type': bookingType,
      'court_id': courtId,
      'start_dt': startDt.toIso8601String(),
      'end_dt': endDt.toIso8601String(),
      'rrule': rrule,
      'segment_mask': segmentMask,
      'override_full_field_rule': overrideFullFieldRule,
      if (teamId != null) 'team_id': teamId,
    };
    final res = await http.post(uri, headers: _headers(json: true), body: jsonEncode(body));
    if (res.statusCode >= 400) {
      throw Exception('Serie erstellen fehlgeschlagen: ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }


  Future<Map<String, dynamic>> dashboardLive({String? day}) async {
    final q = (day != null && day.isNotEmpty) ? '?day=' + Uri.encodeQueryComponent(day) : '';
    final body = await _getWithCache('/dashboard/live$q', cacheKey: 'dashboard:'+ (day ?? 'today'));
    return jsonDecode(body) as Map<String, dynamic>;
  }


  Future<Map<String, dynamic>> courtBookingsDay({required int courtId, String? day}) async {
    final q = (day != null && day.isNotEmpty) ? '?day=' + Uri.encodeQueryComponent(day) : '';
    final body = await _getWithCache('/courts/$courtId/bookings_day$q', cacheKey: 'court_bookings:$courtId:'+(day ?? 'today'));
    return jsonDecode(body) as Map<String, dynamic>;
  }


  Future<Map<String, dynamic>> updateBooking({
    required int bookingId,
    int? courtId,
    DateTime? startDt,
    DateTime? endDt,
    int? segmentMask,
  }) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/bookings/$bookingId');
    final body = <String, dynamic>{
      if (courtId != null) 'court_id': courtId,
      if (startDt != null) 'start_dt': startDt.toIso8601String(),
      if (endDt != null) 'end_dt': endDt.toIso8601String(),
      if (segmentMask != null) 'segment_mask': segmentMask,
    };
    final res = await _writeOrQueue(method: 'PATCH', path: '/bookings/$bookingId', body: body);
    if (res.statusCode == 202) {
      return {'queued': true};
    }
    if (res.statusCode >= 400) {
      throw Exception(res.body);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}
