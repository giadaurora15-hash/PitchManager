import 'package:shared_preferences/shared_preferences.dart';

class OfflineCache {
  static const _prefix = 'cache_v1:';

  Future<void> put(String key, String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('$_prefix$key', value);
  }

  Future<String?> get(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('$_prefix$key');
  }
}
