import 'dart:async';
import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';

import '../app_config.dart';
import '../state/app_state.dart';
import 'offline_queue.dart';
import 'package:http/http.dart' as http;

/// Watches connectivity and flushes queued writes when the device is back online.
class OfflineSyncService {
  final AppState appState;
  final OfflineQueue queue = OfflineQueue();
  StreamSubscription? _sub;
  Timer? _periodic;

  OfflineSyncService(this.appState);

  Future<void> start() async {
    // initial state
    await _updateOnlineStatus();
    // watch changes
    _sub = Connectivity().onConnectivityChanged.listen((_) async {
      await _updateOnlineStatus();
      if (appState.isOnline) {
        await flush();
      } else {
        appState.setQueueCount(await queue.count());
      }
    });

    // periodic flush (in case connectivity events are missed)
    _periodic = Timer.periodic(const Duration(seconds: 10), (_) async {
      await _updateOnlineStatus();
      if (appState.isOnline) {
        await flush();
      } else {
        appState.setQueueCount(await queue.count());
      }
    });

    // set queue count
    appState.setQueueCount(await queue.count());
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _periodic?.cancel();
  }

  Future<void> _updateOnlineStatus() async {
    final r = await Connectivity().checkConnectivity();
    final online = r != ConnectivityResult.none;
    appState.setOnline(online);
  }

  Future<void> flush() async {
    final token = appState.token;
    if (token.isEmpty) return;

    final items = await queue.list();
    if (items.isEmpty) {
      appState.setQueueCount(0);
      return;
    }

    for (final item in items) {
      try {
        final uri = Uri.parse('${AppConfig.baseUrl}${item.path}');
        final headers = {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        };

        http.Response res;
        final body = jsonEncode(item.body);
        switch (item.method.toUpperCase()) {
          case 'POST':
            res = await http.post(uri, headers: headers, body: body);
            break;
          case 'PATCH':
            res = await http.patch(uri, headers: headers, body: body);
            break;
          case 'PUT':
            res = await http.put(uri, headers: headers, body: body);
            break;
          case 'DELETE':
            res = await http.delete(uri, headers: headers, body: body);
            break;
          default:
            res = await http.post(uri, headers: headers, body: body);
        }

        if (res.statusCode < 400) {
          await queue.removeById(item.id);
        } else {
          // keep it in queue; do not spin
        }
      } catch (_) {
        // network issue -> stop flush loop
        break;
      }
    }

    appState.setQueueCount(await queue.count());
  }
}
