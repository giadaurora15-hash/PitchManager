import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class OfflineQueueItem {
  final String id;
  final String method; // POST/PATCH/PUT/DELETE
  final String path; // e.g. /bookings/123
  final Map<String, dynamic> body;
  final int createdAtMs;

  OfflineQueueItem({
    required this.id,
    required this.method,
    required this.path,
    required this.body,
    required this.createdAtMs,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'method': method,
        'path': path,
        'body': body,
        'created_at_ms': createdAtMs,
      };

  static OfflineQueueItem fromJson(Map<String, dynamic> j) => OfflineQueueItem(
        id: j['id'] as String,
        method: j['method'] as String,
        path: j['path'] as String,
        body: (j['body'] as Map).cast<String, dynamic>(),
        createdAtMs: (j['created_at_ms'] as num).toInt(),
      );
}

class OfflineQueue {
  static const _key = 'offline_queue_v1';

  Future<List<OfflineQueueItem>> list() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final arr = jsonDecode(raw) as List<dynamic>;
      return arr.map((e) => OfflineQueueItem.fromJson((e as Map).cast<String, dynamic>())).toList();
    } catch (_) {
      return [];
    }
  }

  Future<int> count() async => (await list()).length;

  Future<void> add(OfflineQueueItem item) async {
    final items = await list();
    items.add(item);
    await _save(items);
  }

  Future<void> removeById(String id) async {
    final items = await list();
    items.removeWhere((e) => e.id == id);
    await _save(items);
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  Future<void> _save(List<OfflineQueueItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(items.map((e) => e.toJson()).toList());
    await prefs.setString(_key, raw);
  }
}
