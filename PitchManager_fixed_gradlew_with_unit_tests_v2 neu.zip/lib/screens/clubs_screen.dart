import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../app_config.dart';

class Club {
  final int id;
  final String name;
  final String? logoUrl;
  Club({required this.id, required this.name, this.logoUrl});
  factory Club.fromJson(Map<String, dynamic> j) => Club(id: j['id'], name: j['name'], logoUrl: j['logo_url']);
}

class ClubsScreen extends StatefulWidget {
  const ClubsScreen({super.key});
  @override
  State<ClubsScreen> createState() => _ClubsScreenState();
}

class _ClubsScreenState extends State<ClubsScreen> {
  List<Club> clubs = [];
  bool loading = false;

  // Setze hier deinen JWT Token nach Login (minimal gehalten)
  String token = '';

  Future<void> loadClubs() async {
    setState(() => loading = true);
    final r = await http.get(Uri.parse('${AppConfig.baseUrl}/clubs'));
    if (r.statusCode == 200) {
      final data = (jsonDecode(r.body) as List).cast<Map<String, dynamic>>();
      clubs = data.map(Club.fromJson).toList();
    }
    setState(() => loading = false);
  }

  Future<void> uploadLogo(Club club) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;

    final req = http.MultipartRequest('POST', Uri.parse('${AppConfig.baseUrl}/clubs/${club.id}/logo'));
    req.files.add(await http.MultipartFile.fromPath('file', picked.path));
    if (token.isNotEmpty) req.headers['Authorization'] = 'Bearer $token';

    final resp = await req.send();
    if (!mounted) return;
    if (resp.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Logo gespeichert')));
      await loadClubs();
    } else {
      final body = await resp.stream.bytesToString();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Upload fehlgeschlagen: ${resp.statusCode} $body')));
    }
  }

  @override
  void initState() { super.initState(); loadClubs(); }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: clubs.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, i) {
        final c = clubs[i];
        final logo = c.logoUrl != null ? '${AppConfig.baseUrl}${c.logoUrl}' : null;
        return Card(
          child: ListTile(
            leading: logo == null ? const CircleAvatar(child: Icon(Icons.shield)) : CircleAvatar(backgroundImage: NetworkImage(logo)),
            title: Text(c.name),
            subtitle: Text('ID: ${c.id}'),
            trailing: IconButton(icon: const Icon(Icons.upload_file), onPressed: () => uploadLogo(c)),
          ),
        );
      },
    );
  }
}
