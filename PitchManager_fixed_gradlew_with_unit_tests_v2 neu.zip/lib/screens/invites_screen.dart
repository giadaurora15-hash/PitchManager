import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../state/app_state.dart';

class InvitesScreen extends StatefulWidget {
  const InvitesScreen({super.key});

  @override
  State<InvitesScreen> createState() => _InvitesScreenState();
}

class _InvitesScreenState extends State<InvitesScreen> {
  final _emails = TextEditingController();
  final _playerEmail = TextEditingController();
  String _role = 'player';
  int _expiresDays = 14;
  bool _loading = false;
  List<Map<String, dynamic>> _created = const [];

  @override
  void dispose() {
    _emails.dispose();
    _playerEmail.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    setState(() => _loading = true);
    try {
      final app = context.read<AppState>();
      final api = ApiClient(token: app.token);

      final emails = _emails.text
          .split(RegExp(r'[\n,; ]+'))
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();

      if (emails.isEmpty) {
        throw Exception('Bitte mindestens eine E-Mail angeben.');
      }

      final res = await api.createInvites(
        role: _role,
        emails: emails,
        relatedPlayerEmail: _role == 'guardian' && _playerEmail.text.trim().isNotEmpty
            ? _playerEmail.text.trim()
            : null,
        expiresInDays: _expiresDays,
      );

      setState(() => _created = res);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Einladungen erstellt. (Mailversand, falls SMTP aktiv)')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Einladungen')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text('Erstelle Einladungslinks für Spieler, Eltern/Vormunde, Trainer oder Admins.',
                style: TextStyle(fontSize: 14)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _role,
              items: const [
                DropdownMenuItem(value: 'player', child: Text('Spieler')),
                DropdownMenuItem(value: 'guardian', child: Text('Vormund/Eltern')),
                DropdownMenuItem(value: 'trainer', child: Text('Trainer')),
                DropdownMenuItem(value: 'admin', child: Text('Admin')),
              ],
              onChanged: (v) => setState(() => _role = v ?? 'player'),
              decoration: const InputDecoration(labelText: 'Rolle'),
            ),
            const SizedBox(height: 12),
            if (_role == 'guardian')
              TextField(
                controller: _playerEmail,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'E-Mail des Spielers (optional)',
                  helperText: 'Wenn angegeben, wird der Vormund nach Registrierung mit dem Spieler verknüpft.',
                ),
              ),
            const SizedBox(height: 12),
            TextField(
              controller: _emails,
              keyboardType: TextInputType.emailAddress,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Empfänger E-Mails',
                helperText: 'Mehrere E-Mails mit Komma, Leerzeichen oder Zeilenumbruch trennen.',
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _expiresDays,
              items: const [
                DropdownMenuItem(value: 7, child: Text('7 Tage gültig')),
                DropdownMenuItem(value: 14, child: Text('14 Tage gültig')),
                DropdownMenuItem(value: 30, child: Text('30 Tage gültig')),
              ],
              onChanged: (v) => setState(() => _expiresDays = v ?? 14),
              decoration: const InputDecoration(labelText: 'Gültigkeit'),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: _loading ? null : _send,
              icon: const Icon(Icons.send),
              label: Text(_loading ? 'Sende…' : 'Einladungen erstellen & senden'),
            ),
            const SizedBox(height: 18),
            if (_created.isNotEmpty) ...[
              const Text('Erstellte Links', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              ..._created.map((i) => Card(
                    child: ListTile(
                      title: Text('${i['role']} – ${i['email'] ?? ''}'),
                      subtitle: Text(i['link'] ?? ''),
                      trailing: const Icon(Icons.link),
                    ),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}
