import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:provider/provider.dart';

import '../app_config.dart';
import '../services/api_client.dart';
import '../state/app_state.dart';

class ClubLite {
  final int id;
  final String name;
  ClubLite({required this.id, required this.name});
  factory ClubLite.fromJson(Map<String, dynamic> j) => ClubLite(id: j['id'], name: j['name']);
}

class BookingCreateScreen extends StatefulWidget {
  const BookingCreateScreen({super.key});

  @override
  State<BookingCreateScreen> createState() => _BookingCreateScreenState();
}

class _BookingCreateScreenState extends State<BookingCreateScreen> {
  List<dynamic> _teams = [];
  int? _teamId;
  bool _teamsLoading = true;
  bool _isSeries = false;
  int _seriesCountWeeks = 8;

  bool saving = false;
  bool loadingClubs = false;
  List<ClubLite> clubs = [];

  bool loadingWeather = false;
  Map<String, dynamic>? weather;
  String? weatherError;

  bool useAutoLocation = true;
  double? weatherLat;
  double? weatherLon;
  String? weatherLocationLabel;
  bool loadingLocation = false;
  String? locationError;

  int courtId = 1;
  String bookingType = 'training';
  String? ageGroup; // F,E,D,C,B,A,Senioren
  int? clubId;
  int? opponentClubId;

  DateTime date = DateTime.now();
  TimeOfDay start = const TimeOfDay(hour: 18, minute: 0);
  TimeOfDay end = const TimeOfDay(hour: 19, minute: 30);

  int segmentMask = 15;
  String segmentMode = 'ganz'; // quart|half|three|ganz
  String? quarterChoice;
  String? halfChoice;
  String? threeChoice;

  static const _ageGroups = ['F', 'E', 'D', 'C', 'B', 'A', 'Senioren'];

  ApiClient _api(BuildContext context) => ApiClient(token: context.read<AppState>().token);

  int _ageRank(String g) {
    const m = {'F': 1, 'E': 2, 'D': 3, 'C': 4, 'B': 5, 'A': 6, 'Senioren': 7};
    return m[g] ?? 0;
  }

  bool get _mustFullField {
    if (!(bookingType == 'spieltag' || bookingType == 'turnier')) return false;
    if (ageGroup == null) return false;
    return _ageRank(ageGroup!) >= _ageRank('C');
  }

  Future<void> loadClubs() async {
    setState(() => loadingClubs = true);
    try {
      final r = await http.get(Uri.parse('${AppConfig.baseUrl}/clubs'));
      if (r.statusCode == 200) {
        final data = (jsonDecode(r.body) as List).cast<Map<String, dynamic>>();
        clubs = data.map(ClubLite.fromJson).toList();
      }
    } finally {
      if (mounted) setState(() => loadingClubs = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _loadTeams();

    super.initState();
    loadClubs();
    _recomputeMask();
    _loadDeviceLocation().then((_) => _loadWeatherPreview());
  }

  IconData _weatherIcon(int? code) {
    // Basic icon mapping (WMO codes as used by Open-Meteo)
    if (code == null) return Icons.wb_sunny_outlined;
    if ([0,1].contains(code)) return Icons.wb_sunny_outlined;
    if ([2,3].contains(code)) return Icons.cloud_outlined;
    if ([45,48].contains(code)) return Icons.cloud_outlined;
    if (code >= 51 && code <= 57) return Icons.grain_outlined;
    if (code >= 61 && code <= 67) return Icons.umbrella_outlined;
    if (code >= 71 && code <= 77) return Icons.ac_unit_outlined;
    if (code >= 80 && code <= 86) return Icons.umbrella_outlined;
    if (code >= 95) return Icons.thunderstorm_outlined;
    return Icons.cloud_outlined;
  }


  Future<void> _loadDeviceLocation() async {
    if (!useAutoLocation) return;
    setState(() {
      loadingLocation = true;
      locationError = null;
    });
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Standortdienste sind deaktiviert');
      }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied) {
        throw Exception('Standortberechtigung verweigert');
      }
      if (perm == LocationPermission.deniedForever) {
        throw Exception('Standortberechtigung dauerhaft verweigert (in Einstellungen aktivieren)');
      }

      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      weatherLat = pos.latitude;
      weatherLon = pos.longitude;

      // Optional: reverse geocode for a friendly label
      try {
        final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
        if (placemarks.isNotEmpty) {
          final p = placemarks.first;
          final parts = <String>[
            if ((p.locality ?? '').isNotEmpty) p.locality!,
            if ((p.administrativeArea ?? '').isNotEmpty) p.administrativeArea!,
            if ((p.country ?? '').isNotEmpty) p.country!,
          ];
          if (parts.isNotEmpty) {
            weatherLocationLabel = parts.join(', ');
          }
        }
      } catch (_) {
        // ignore label failures
      }
      weatherLocationLabel ??= 'Gerätestandort';
      if (!mounted) return;
      setState(() {});
    } catch (e) {
      if (!mounted) return;
      setState(() {
        locationError = e.toString();
        weatherLat = null;
        weatherLon = null;
        weatherLocationLabel = null;
      });
    } finally {
      if (mounted) setState(() => loadingLocation = false);
    }
  }

  Future<void> _loadWeatherPreview() async {
    setState(() {
      loadingWeather = true;
      weatherError = null;
    });
    try {
      final t = _combine(date, start); // UTC
      final j = await _api(context).weatherAtTime(courtId: courtId, timeUtc: t, lat: weatherLat, lon: weatherLon);
      if (!mounted) return;
      setState(() => weather = j);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        weather = null;
        weatherError = e.toString();
      });
    } finally {
      if (mounted) setState(() => loadingWeather = false);
    }
  }

  void _recomputeMask() {
    if (_mustFullField) {
      setState(() {
        segmentMode = 'ganz';
        segmentMask = 15;
      });
      return;
    }
    int mask = 15;
    if (segmentMode == 'ganz') {
      mask = 15;
    } else if (segmentMode == 'quart') {
      const map = {'A': 1, 'B': 2, 'C': 4, 'D': 8};
      mask = map[quarterChoice] ?? 1;
    } else if (segmentMode == 'half') {
      const map = {'AB': 3, 'CD': 12, 'AC': 5, 'BD': 10};
      mask = map[halfChoice] ?? 3;
    } else if (segmentMode == 'three') {
      const map = {'ABC': 7, 'ABD': 11, 'ACD': 13, 'BCD': 14};
      mask = map[threeChoice] ?? 7;
    }
    setState(() => segmentMask = mask);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: date);
    if (d != null) {
      setState(() => date = d);
      _loadDeviceLocation().then((_) => _loadWeatherPreview());
    }
  }

  Future<void> _pickTime(bool isStart) async {
    final t = await showTimePicker(context: context, initialTime: isStart ? start : end);
    if (t != null) {
      setState(() => isStart ? start = t : end = t);
      _loadDeviceLocation().then((_) => _loadWeatherPreview());
    }
  }

  String? _validate() {
    if (courtId <= 0) return 'Platz-ID ungültig';
    if (bookingType == 'spieltag') {
      if (clubId == null || opponentClubId == null) return 'Bei Spieltag sind Heim- und Gastverein Pflicht.';
      if (clubId == opponentClubId) return 'Heim- und Gastverein dürfen nicht gleich sein.';
    }
    if ((bookingType == 'spieltag' || bookingType == 'turnier') && ageGroup == null) {
      return 'Bitte Jugend auswählen (für Spieltag/Turnier).';
    }
    return null;
  }

  DateTime _combine(DateTime d, TimeOfDay t) {
    final local = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    // Backend verlangt timezone-aware ISO strings -> wir senden UTC.
    return local.toUtc();
  }

  Future<void> save() async {
    final err = _validate();
    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
      return;
    }

    setState(() => saving = true);
    try {
    final startDt = _combine(date, start);
    final endDt = _combine(date, end);

    if (_isSeries && bookingType == 'training') {
    final rrule = 'FREQ=WEEKLY;COUNT=$_seriesCountWeeks';
    await _api(context).createSeries(
    title: 'Training',
    bookingType: bookingType,
    courtId: courtId,
    startDt: startDt,
    endDt: endDt,
    rrule: rrule,
    segmentMask: segmentMask,
    overrideFullFieldRule: overrideFullFieldRule,
    teamId: _teamId,
    );
    } else {
    await _api(context).createBooking(
    bookingType: bookingType,
    courtId: courtId,
    startDt: startDt,
    endDt: endDt,
    segmentMask: segmentMask,
    ageGroup: ageGroup,
    clubId: clubId,
    opponentClubId: opponentClubId,
    weatherLat: weatherLat,
    weatherLon: weatherLon,
    weatherLocationLabel: weatherLocationLabel,
    );
    }

    if (!mounted) return;
    Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null) {
      _prefillFromArgs(args);
    }

    final mustFull = _mustFullField;
    return Scaffold(
      appBar: AppBar(title: const Text('Buchung erstellen')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Grunddaten', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextFormField(
                    initialValue: '$courtId',
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Platz-ID'),
                    onChanged: (v) {
                      final next = int.tryParse(v);
                      if (next != null && next > 0 && next != courtId) {
                        setState(() => courtId = next);
                        _loadDeviceLocation().then((_) => _loadWeatherPreview());
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: bookingType,
                    items: const [
                      DropdownMenuItem(value: 'training', child: Text('Training')),
                      DropdownMenuItem(value: 'event', child: Text('Veranstaltung')),
                      DropdownMenuItem(value: 'spieltag', child: Text('Spieltag')),
                      DropdownMenuItem(value: 'turnier', child: Text('Turnier')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => bookingType = v);
                      _recomputeMask();
                    },
                    decoration: const InputDecoration(labelText: 'Typ'),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: ageGroup,
                    items: _ageGroups.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                    onChanged: (v) {
                      setState(() => ageGroup = v);
                      _recomputeMask();
                    },
                    decoration: const InputDecoration(labelText: 'Jugend (für Spieltag/Turnier)'),
                  ),
                  const SizedBox(height: 10),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_month_outlined),
                    title: Text('Datum: ${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}'),
                    trailing: TextButton(onPressed: _pickDate, child: const Text('Ändern')),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.schedule_outlined),
                    title: Text('Start: ${start.format(context)}'),
                    trailing: TextButton(onPressed: () => _pickTime(true), child: const Text('Ändern')),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.schedule_outlined),
                    title: Text('Ende: ${end.format(context)}'),
                    trailing: TextButton(onPressed: () => _pickTime(false), child: const Text('Ändern')),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('Wetter (Echtzeit)', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      TextButton.icon(
                        onPressed: loadingWeather ? null : _loadWeatherPreview,
                        icon: const Icon(Icons.refresh_outlined, size: 18),
                        label: const Text('Aktualisieren'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          useAutoLocation
                              ? 'Standort: ${weatherLocationLabel ?? (loadingLocation ? "wird geladen…" : "unbekannt")}'
                              : 'Standort: Platz-Koordinaten',
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ),
                      Switch(
                        value: useAutoLocation,
                        onChanged: (v) async {
                          setState(() => useAutoLocation = v);
                          if (v) {
                            await _loadDeviceLocation();
                          } else {
                            setState(() {
                              weatherLat = null;
                              weatherLon = null;
                              weatherLocationLabel = null;
                              locationError = null;
                            });
                          }
                          await _loadWeatherPreview();
                        },
                      ),
                    ],
                  ),
                  if (useAutoLocation && loadingLocation) const LinearProgressIndicator(),
                  if (useAutoLocation && !loadingLocation && locationError != null)
                    Text(locationError!, style: const TextStyle(color: Colors.redAccent)),
                                    if (loadingWeather) const LinearProgressIndicator(),
                  if (!loadingWeather && weatherError != null)
                    Text(
                      weatherError!,
                      style: const TextStyle(color: Colors.redAccent),
                    ),
                  if (!loadingWeather && weather != null) ...[
                    Row(
                      children: [
                        Icon(_weatherIcon(weather!['weather_code'] as int?), size: 22),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${weather!['summary_de'] ?? 'Wetter'} • ${((weather!['temperature_c'] as num?)?.toDouble())?.toStringAsFixed(1) ?? '-'} °C',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 12,
                      runSpacing: 6,
                      children: [
                        Chip(
                          avatar: const Icon(Icons.water_drop_outlined, size: 18),
                          label: Text('Niederschlag: ${((weather!['precipitation_mm'] as num?)?.toDouble())?.toStringAsFixed(1) ?? '-'} mm'),
                        ),
                        Chip(
                          avatar: const Icon(Icons.umbrella_outlined, size: 18),
                          label: Text('Regen-Wahrsch.: ${(weather!['precipitation_probability'] as num?)?.toInt() ?? '-'}%'),
                        ),
                        Chip(
                          avatar: const Icon(Icons.air_outlined, size: 18),
                          label: Text('Wind: ${((weather!['wind_kph'] as num?)?.toDouble())?.toStringAsFixed(0) ?? '-'} km/h'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Text('Hinweis: Werte sind stündliche Vorhersage (UTC) für den ausgewählten Platz.', style: TextStyle(color: Colors.grey)),
                  ]
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Vereine (Pflicht bei Spieltag)', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  if (loadingClubs) const LinearProgressIndicator() else ...[
                    DropdownButtonFormField<int>(
                      value: clubId,
                      items: clubs.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
                      onChanged: (v) => setState(() => clubId = v),
                      decoration: const InputDecoration(labelText: 'Heimverein'),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<int>(
                      value: opponentClubId,
                      items: clubs.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
                      onChanged: (v) => setState(() => opponentClubId = v),
                      decoration: const InputDecoration(labelText: 'Gastverein'),
                    ),
                  ]
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Platzanteil', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (mustFull)
                    const Text('Für Spieltag/Turnier ab C-Jugend wird der ganze Platz erzwungen.', style: TextStyle(color: Colors.grey))
                  else
                    Wrap(
                      spacing: 8,
                      children: [
                        ChoiceChip(label: const Text('Ganz'), selected: segmentMode == 'ganz', onSelected: (_) { setState(() => segmentMode = 'ganz'); _recomputeMask(); }),
                        ChoiceChip(label: const Text('¼'), selected: segmentMode == 'quart', onSelected: (_) { setState(() => segmentMode = 'quart'); _recomputeMask(); }),
                        ChoiceChip(label: const Text('½'), selected: segmentMode == 'half', onSelected: (_) { setState(() => segmentMode = 'half'); _recomputeMask(); }),
                        ChoiceChip(label: const Text('¾'), selected: segmentMode == 'three', onSelected: (_) { setState(() => segmentMode = 'three'); _recomputeMask(); }),
                      ],
                    ),
                  const SizedBox(height: 10),
                  if (!mustFull && segmentMode == 'quart')
                    DropdownButtonFormField<String>(
                      value: quarterChoice,
                      items: const ['A', 'B', 'C', 'D'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                      onChanged: (v) { setState(() => quarterChoice = v); _recomputeMask(); },
                      decoration: const InputDecoration(labelText: '¼ Auswahl'),
                    ),
                  if (!mustFull && segmentMode == 'half')
                    DropdownButtonFormField<String>(
                      value: halfChoice,
                      items: const ['AB', 'CD', 'AC', 'BD'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                      onChanged: (v) { setState(() => halfChoice = v); _recomputeMask(); },
                      decoration: const InputDecoration(labelText: '½ Auswahl'),
                    ),
                  if (!mustFull && segmentMode == 'three')
                    DropdownButtonFormField<String>(
                      value: threeChoice,
                      items: const ['ABC', 'ABD', 'ACD', 'BCD'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                      onChanged: (v) { setState(() => threeChoice = v); _recomputeMask(); },
                      decoration: const InputDecoration(labelText: '¾ Auswahl'),
                    ),
                  const SizedBox(height: 10),
                  Text('Segment-Maske: $segmentMask', style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: saving ? null : save,
            icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined),
            label: const Text('Speichern'),
          ),
        ],
      ),
    );
  }

Future<void> _loadTeams() async {
  try {
    final api = ApiClient(token: context.read<AppState>().token);
    final teams = await api.listTeams();
    setState(() {
      _teams = teams;
      _teamsLoading = false;
    });
  } catch (_) {
    setState(() => _teamsLoading = false);
  }
}
}
const SizedBox(height: 12),
SwitchListTile(
  title: const Text('Serientraining'),
  subtitle: const Text('Wöchentlich wiederholen (nur Training)'),
  value: _isSeries,
  onChanged: (v) => setState(() => _isSeries = v),
),
if (_isSeries) ...[
  const SizedBox(height: 8),
  TextFormField(
    initialValue: _seriesCountWeeks.toString(),
    keyboardType: TextInputType.number,
    decoration: const InputDecoration(
      labelText: 'Anzahl Wochen',
      border: OutlineInputBorder(),
    ),
    onChanged: (v) {
      final n = int.tryParse(v) ?? 8;
      setState(() => _seriesCountWeeks = n.clamp(1, 52));
    },
  ),
],


