import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../state/app_state.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Timer? _timer;

  bool _loading = true;
  Map<String, dynamic>? _data;
  String _dayMode = 'today'; // today|tomorrow
  String _typeFilter = 'all'; // all|training|game|tournament|event
  bool _onlyMyTeams = false;
  Set<int> _myTeamIds = <int>{};
  bool _teamsLoaded = false;

  String? _lastDaySent; // cache key

  ApiClient _api(BuildContext context) {
    final token = context.read<AppState>().token;
    return ApiClient(token: token);
  }

  @override
  void initState() {
    super.initState();
    _load(force: true);
    _loadMyTeams();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted) _load();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }


  String? _dayParam() {
    if (_dayMode == 'tomorrow') {
      final now = DateTime.now().toUtc().add(const Duration(days: 1));
      return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    }
    return null; // backend default: today
  }

  Future<void> _load({bool force = false}) async {
    final day = _dayParam() ?? 'today';
    if (!force && _lastDaySent == day && _data != null) return;

    setState(() => _loading = true);
    final d = await _api(context).dashboardLive(day: _dayParam());
    setState(() {
      _data = d;
      _loading = false;
      _lastDaySent = day;
    });
  }

  @override
  Widget build(BuildContext context) {
    final raw = (_data?['occupancy'] as List?) ?? const [];
    final occupancy = raw.where((c) {
      final m = c as Map<String, dynamic>;
      final qs = (m['quarters'] as List?) ?? const [];
      bool any = false;
      for (final q in qs) {
        final qm = q as Map<String, dynamic>;
        if (qm['booked'] != true) continue;
        if (_typeFilter != 'all') {
          final t = (qm['type'] ?? '').toString();
          if (t != _typeFilter) continue;
        }
        if (_onlyMyTeams) {
          final tid = qm['team_id'];
          if (tid is int) {
            if (!_myTeamIds.contains(tid)) continue;
          } else {
            continue;
          }
        }
        any = true;
        break;
      }
      return _typeFilter == 'all' && !_onlyMyTeams ? true : any;
    }).toList();

    
// KPI
final totalCourts = occupancy.length;
int bookedQuarters = 0;
int totalQuarters = totalCourts * 4;
int freeCourts = 0;
for (final c in occupancy) {
  final m = c as Map<String, dynamic>;
  final bq = (m['booked_quarters'] ?? 0) as int;
  bookedQuarters += bq;
  if (bq == 0) freeCourts += 1;
}
final utilization = totalQuarters == 0 ? 0.0 : (bookedQuarters / totalQuarters);

return Scaffold(
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _load(force: true),
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Platzübersicht',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('Heute'),
                        selected: _dayMode == 'today',
                        onSelected: (_) => setState(() {
                          _dayMode = 'today';
                          _load(force: true);
                        }),
                      ),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('Morgen'),
                        selected: _dayMode == 'tomorrow',
                        onSelected: (_) => setState(() {
                          _dayMode = 'tomorrow';
                          _load(force: true);
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Belegung je Platz in Vierteln (1/4, 1/2, 3/4, ganz). ⚠ = Konflikt (Mehrfachbelegung).',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  
const SizedBox(height: 12),
Text('Filter:', style: Theme.of(context).textTheme.labelMedium),
const SizedBox(height: 6),
SingleChildScrollView(
  scrollDirection: Axis.horizontal,
  child: Row(
    children: [
      ChoiceChip(
        label: const Text('Alle'),
        selected: _typeFilter == 'all',
        onSelected: (_) => setState(() { _typeFilter = 'all'; }),
      ),
      const SizedBox(width: 8),
      ChoiceChip(
        label: const Text('Training'),
        selected: _typeFilter == 'training',
        onSelected: (_) => setState(() { _typeFilter = 'training'; }),
      ),
      const SizedBox(width: 8),
      ChoiceChip(
        label: const Text('Spiel'),
        selected: _typeFilter == 'game',
        onSelected: (_) => setState(() { _typeFilter = 'game'; }),
      ),
      const SizedBox(width: 8),
      ChoiceChip(
        label: const Text('Turnier'),
        selected: _typeFilter == 'tournament',
        onSelected: (_) => setState(() { _typeFilter = 'tournament'; }),
      ),
      const SizedBox(width: 8),
      ChoiceChip(
        label: const Text('Event'),
        selected: _typeFilter == 'event',
        onSelected: (_) => setState(() { _typeFilter = 'event'; }),
      ),
      const SizedBox(width: 12),
      FilterChip(
        label: const Text('Nur meine Teams'),
        selected: _onlyMyTeams,
        onSelected: (v) => setState(() { _onlyMyTeams = v; }),
      ),
    ],
  ),
),
const SizedBox(height: 12),
      decoration: BoxDecoration(
    borderRadius: const BorderRadius.only(
      topLeft: Radius.circular(12),
      bottomLeft: Radius.circular(12),
    ),
    color: (type == 'training')
        ? Theme.of(context).colorScheme.primary
        : (type == 'game')
            ? Theme.of(context).colorScheme.secondary
            : (type == 'tournament')
                ? Theme.of(context).colorScheme.tertiary
                : Theme.of(context).colorScheme.primaryContainer,
  ),
),
const SizedBox(width: 8),
Expanded(
  child: Padding(
    padding: const EdgeInsets.all(8),occupancy
                      .map((c) => CourtCard(
                            court: c as Map<String, dynamic>,
                            dayMode: _dayMode,
                          ))
                      .toList(),
                  const SizedBox(height: 24),
                ],
              ),
            ),
    );
  }
}

class CourtCard extends StatelessWidget {
  final Map<String, dynamic> court;
  final String dayMode; // today|tomorrow
  const CourtCard({super.key, required this.court, required this.dayMode});

  String _fracLabel(int booked) {
    if (booked <= 0) return 'frei';
    if (booked == 1) return '1/4';
    if (booked == 2) return '1/2';
    if (booked == 3) return '3/4';
    return 'voll';
  }

  @override
  Widget build(BuildContext context) {
    final name = (court['court_name'] ?? 'Platz') as String;
    final booked = (court['booked_quarters'] ?? 0) as int;
    final quarters = (court['quarters'] as List?) ?? const [];
    final courtId = (court['court_id'] ?? 0) as int;

    String? who;
    for (final q in quarters) {
      final m = q as Map<String, dynamic>;
      if (m['booked'] == true && m['label'] != null) {
        who = m['label'].toString();
        break;
      }
    }

    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CourtDetailScreen(
            courtId: courtId,
            courtName: name,
            dayMode: dayMode,
          ),
        ),
      ),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text(name, style: Theme.of(context).textTheme.titleMedium)),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(999),
                      color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    ),
                    child: Text(_fracLabel(booked), style: Theme.of(context).textTheme.labelMedium),
                  ),
                  const SizedBox(width: 6),
                  PopupMenuButton<String>(
                    onSelected: (v) {
                      if (v == 'training') {
                        Navigator.pushNamed(context, '/booking_create',
                            arguments: {'courtId': courtId, 'type': 'training'});
                      } else if (v == 'block') {
                        Navigator.pushNamed(context, '/booking_create',
                            arguments: {'courtId': courtId, 'type': 'block'});
                      } else if (v == 'event') {
                        Navigator.pushNamed(context, '/event_create',
                            arguments: {'courtId': courtId});
                      }
                    },
                    itemBuilder: (ctx) => const [
                      PopupMenuItem(value: 'training', child: Text('Training buchen')),
                      PopupMenuItem(value: 'block', child: Text('Platz blockieren')),
                      PopupMenuItem(value: 'event', child: Text('Event erstellen')),
                    ],
                  ),
                ],
              ),
                ],
              ),
              if (who != null) ...[
                const SizedBox(height: 4),
                Text('Belegt durch: $who', style: Theme.of(context).textTheme.bodySmall),
              ],
              const SizedBox(height: 10),
              Row(
                children: List.generate(4, (i) {
                  final bit = [1, 2, 4, 8][i];
                  final q = (quarters.firstWhere(
                    (e) => (e as Map)['bit'] == bit,
                    orElse: () => {'booked': false, 'label': null, 'conflict': false},
                  ) as Map);
                  final isBooked = q['booked'] == true;
                  final isConflict = q['conflict'] == true;
                  return Expanded(
                    child: Container(
                      height: 12,
                      margin: EdgeInsets.only(right: i == 3 ? 0 : 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: isBooked
                            ? (isConflict
                                ? Theme.of(context).colorScheme.error
                                : Theme.of(context).colorScheme.primary)
                            : Theme.of(context).colorScheme.surfaceContainerHighest,
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 6),
              Row(
                children: List.generate(4, (i) {
                  final bit = [1, 2, 4, 8][i];
                  final q = (quarters.firstWhere(
                    (e) => (e as Map)['bit'] == bit,
                    orElse: () => {'booked': false, 'label': null, 'conflict': false},
                  ) as Map);
                  final label = (q['label'] ?? '').toString();
                  final conflict = q['conflict'] == true;
                  final text = conflict ? '⚠' : (label.isEmpty ? '' : (label.length > 7 ? label.substring(0, 7) : label));
                  return Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(right: i == 3 ? 0 : 6),
                      child: Text(
                        text,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.labelSmall,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CourtDetailScreen extends StatefulWidget {
  final int courtId;
  final String courtName;
  final String dayMode; // today|tomorrow
  const CourtDetailScreen({
    super.key,
    required this.courtId,
    required this.courtName,
    required this.dayMode,
  });

  @override
  State<CourtDetailScreen> createState() => _CourtDetailScreenState();
}

class _CourtDetailScreenState extends State<CourtDetailScreen> {
  String _viewMode = 'timeline'; // timeline|list

  bool _loading = true;
  List<dynamic> _bookings = const [];

  ApiClient _api(BuildContext context) {
    final token = context.read<AppState>().token;
    return ApiClient(token: token);
  }

  String? _dayParam() {
    if (widget.dayMode == 'tomorrow') {
      final now = DateTime.now().toUtc().add(const Duration(days: 1));
      return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await _api(context).courtBookingsDay(
      courtId: widget.courtId,
      day: _dayParam(),
    );
    final bookings = (res['bookings'] as List?) ?? const [];
    setState(() {
      _bookings = bookings;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.courtName),
        actions: [
          IconButton(
            tooltip: _viewMode == 'timeline' ? 'Liste' : 'Timeline',
            icon: Icon(_viewMode == 'timeline' ? Icons.view_list : Icons.timeline),
            onPressed: () => setState(() => _viewMode = _viewMode == 'timeline' ? 'list' : 'timeline'),
          )
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              
child: _viewMode == 'list'
    ? ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: _bookings.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final b = _bookings[i] as Map<String, dynamic>;
          final start = DateTime.parse(b['start_dt']).toLocal();
          final end = DateTime.parse(b['end_dt']).toLocal();
          final type = (b['type'] ?? b['booking_type'] ?? 'booking').toString();
          final team = (b['team_name'] ?? '').toString();
          final seg = (b['segment_mask'] ?? 15).toString();
          return ListTile(
            leading: const Icon(Icons.event_note),
            title: Text('${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}'
                ' – ${end.hour.toString().padLeft(2, '0')}:${end.minute.toString().padLeft(2, '0')}'),
            subtitle: Text('${type.toUpperCase()}${team.isNotEmpty ? " • $team" : ""} • Segment $seg'),
          );
        },
      )
    : _Timeline(bookings: _bookings),
    );
  }
}

class _Timeline extends StatelessWidget {
  final List<dynamic> bookings;
  const _Timeline({required this.bookings});

  @override
  Widget build(BuildContext context) {
    // Timeline from 06:00 - 22:00 (local time)
    const startHour = 6;
    const endHour = 22;
    const totalMinutes = (endHour - startHour) * 60;

    double topFor(DateTime t) {
      final minutes = (t.hour - startHour) * 60 + t.minute;
      return minutes.clamp(0, totalMinutes).toDouble();
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final height = totalMinutes.toDouble(); // 1px per minute
        return SingleChildScrollView(
          child: SizedBox(
            height: height + 40,
            child: Stack(
              children: [
                // hour lines
                for (int h = startHour; h <= endHour; h++)
                  Positioned(
                    top: ((h - startHour) * 60).toDouble(),
                    left: 0,
                    right: 0,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 54,
                          child: Text(
                            '${h.toString().padLeft(2,'0')}:00',
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                        ),
                        Expanded(
                          child: Divider(color: Theme.of(context).dividerColor),
                        ),
                      ],
                    ),
                  ),

                // booking blocks
                for (final b0 in bookings)
                  _BookingBlock(b: b0 as Map<String, dynamic>, topFor: topFor),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _BookingBlock extends StatefulWidget {
  final Map<String, dynamic> b;
  final double Function(DateTime) topFor;
  const _BookingBlock({required this.b, required this.topFor});

  @override
  State<_BookingBlock> createState() => _BookingBlockState();
}

class _BookingBlockState extends State<_BookingBlock> {
  double _dy = 0;

  @override
  Widget build(BuildContext context) {
    final b = widget.b;
    final start = DateTime.parse(b['start_dt']).toLocal();
    final end = DateTime.parse(b['end_dt']).toLocal();
    final type = (b['type'] ?? b['booking_type'] ?? 'booking').toString();
    final team = (b['team_name'] ?? '').toString();
    final seg = (b['segment_mask'] ?? 15).toString();

    final topBase = widget.topFor(start);
    final bottom = widget.topFor(end);
    final h = (bottom - topBase).clamp(12, 6000).toDouble();
    final top = topBase + _dy;

    Future<void> _commitMove() async {
      final bookingId = (b['booking_id'] ?? b['id']) as int?;
      if (bookingId == null) return;
      // 1px == 1 minute
      final rawMinutes = (_dy.round()).clamp(-720, 720);
      // snap to 15-minute grid
      final minutes = ((rawMinutes / 15).round() * 15).clamp(-720, 720);
      if (minutes == 0) return;

      final newStart = start.add(Duration(minutes: minutes));
      final newEnd = end.add(Duration(minutes: minutes));

      try {
        final token = context.read<AppState>().token;
        final api = ApiClient(token: token);
        await api.updateBooking(bookingId: bookingId, startDt: newStart.toUtc(), endDt: newEnd.toUtc());
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Buchung verschoben')));
        }
      } catch (e) {
        if (!mounted) return;

        List<dynamic> suggestions = const [];
        String message = 'Verschieben fehlgeschlagen';

        try {
          final s = e.toString();
          final idx = s.indexOf('{');
          if (idx >= 0) {
            final obj = jsonDecode(s.substring(idx)) as Map<String, dynamic>;
            final detail = obj['detail'];
            if (detail is Map<String, dynamic>) {
              message = (detail['message'] ?? message).toString();
              final sugg = detail['suggestions'];
              if (sugg is List) suggestions = sugg;
            }
          }
        } catch (_) {}

        if (suggestions.isNotEmpty) {
          // Let user pick a suggestion and apply it in one tap
          final picked = await showModalBottomSheet<Map<String, dynamic>>(
            context: context,
            showDragHandle: true,
            builder: (ctx) {
              return SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      title: const Text('Konflikt erkannt'),
                      subtitle: Text('Wähle einen Vorschlag (oder schließe).'),
                      leading: const Icon(Icons.warning_amber_rounded),
                    ),
                    const Divider(height: 1),
                    ...suggestions.take(6).map((s) {
                      final m = s as Map<String, dynamic>;
                      final cn = (m['court_name'] ?? 'Platz').toString();
                      final reason = (m['reason'] ?? '').toString();
                      return ListTile(
                        title: Text(cn),
                        subtitle: Text(reason),
                        trailing: const Icon(Icons.check),
                        onTap: () => Navigator.pop(ctx, m),
                      );
                    }).toList(),
                    const SizedBox(height: 8),
                  ],
                ),
              );
            },
          );

          if (picked != null) {
            try {
              final bookingId = (b['booking_id'] ?? b['id']) as int?;
              if (bookingId != null) {
                final newStart = DateTime.parse(picked['start_dt']).toUtc();
                final newEnd = DateTime.parse(picked['end_dt']).toUtc();
                final newCourtId = picked['court_id'] as int?;
                final token = context.read<AppState>().token;
                final api = ApiClient(token: token);
                await api.updateBooking(
                  bookingId: bookingId,
                  courtId: newCourtId,
                  startDt: newStart,
                  endDt: newEnd,
                );
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vorschlag übernommen')));
                }
              }
            } catch (e2) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Übernehmen fehlgeschlagen: $e2')));
              }
            }
          }
          return;
        }

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    }

    return Positioned(
      top: top,
      left: 70,
      right: 12,
      child: GestureDetector(
        onVerticalDragUpdate: (d) => setState(() => _dy += d.delta.dy),
        onVerticalDragEnd: (_) async {
          await _commitMove();
          setState(() => _dy = 0);
        },
        child: Container(
        height: h,
        padding: const EdgeInsets.all(0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        ),
        child: Row(
          children: [
            Container(
              width: 6,
              height: double.infinity,
              decoration: BoxDecoration(
                color: (type == 'training')
                    ? Theme.of(context).colorScheme.primary
                    : (type == 'game')
                        ? Theme.of(context).colorScheme.secondary
                        : (type == 'tournament')
                            ? Theme.of(context).colorScheme.tertiary
                            : Theme.of(context).colorScheme.primaryContainer,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Text(
            '${type.toUpperCase()}${team.isNotEmpty ? " • $team" : ""}
${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}–${end.hour.toString().padLeft(2,'0')}:${end.minute.toString().padLeft(2,'0')} • Segment: $seg
(ziehen zum Verschieben)',
            style: Theme.of(context).textTheme.labelSmall,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
}

class _KpiCard extends StatelessWidget {
  final String title;
  final String value;
  const _KpiCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.labelSmall),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
      ),
    );
  }
}
