import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/court.dart';
import '../services/api_client.dart';
import '../state/app_state.dart';

class CourtsManageScreen extends StatefulWidget {
  const CourtsManageScreen({super.key});

  @override
  State<CourtsManageScreen> createState() => _CourtsManageScreenState();
}

class _CourtsManageScreenState extends State<CourtsManageScreen> {
  late final ApiClient api;
  bool loading = true;
  String? error;
  List<Court> courts = [];

  @override
  void initState() {
    super.initState();
    final token = context.read<AppState>().token;
    api = ApiClient(token: token);
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final res = await api.listCourts();
      setState(() {
        courts = res;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _editCourt(Court c) async {
    final nameCtrl = TextEditingController(text: c.name);
    final latCtrl = TextEditingController(text: c.latitude?.toString() ?? '');
    final lonCtrl = TextEditingController(text: c.longitude?.toString() ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Platz bearbeiten'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: latCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: const InputDecoration(labelText: 'Breitengrad (Latitude)'),
              ),
              TextField(
                controller: lonCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: const InputDecoration(labelText: 'Längengrad (Longitude)'),
              ),
              const SizedBox(height: 8),
              const Text(
                'Tipp: Koordinaten sind nötig für Live-Wetter bei Buchungen.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Speichern')),
          ],
        );
      },
    );

    if (saved != true) return;

    double? parseDouble(String s) {
      final t = s.trim();
      if (t.isEmpty) return null;
      return double.tryParse(t.replaceAll(',', '.'));
    }

    try {
      final updated = await api.updateCourt(
        courtId: c.id,
        name: nameCtrl.text.trim().isEmpty ? c.name : nameCtrl.text.trim(),
        latitude: parseDouble(latCtrl.text),
        longitude: parseDouble(lonCtrl.text),
      );
      setState(() {
        final idx = courts.indexWhere((x) => x.id == c.id);
        if (idx >= 0) courts[idx] = updated;
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gespeichert')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Plätze & Standorte')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : (error != null)
                ? ListView(
                    children: [
                      const SizedBox(height: 24),
                      Center(child: Text(error!)),
                    ],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: courts.length,
                    itemBuilder: (ctx, i) {
                      final c = courts[i];
                      final coords = (c.latitude != null && c.longitude != null)
                          ? '${c.latitude!.toStringAsFixed(5)}, ${c.longitude!.toStringAsFixed(5)}'
                          : 'nicht gesetzt';
                      return Card(
                        child: ListTile(
                          title: Text(c.name),
                          subtitle: Text('Koordinaten: $coords'),
                          trailing: const Icon(Icons.edit),
                          onTap: () => _editCourt(c),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
