import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'clubs_screen.dart';
import 'bookings_screen.dart';
import 'events_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int idx = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const DashboardScreen(),
      const ClubsScreen(),
      const BookingsScreen(),
      const EventsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('PitchManager')),
      body: pages[idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => setState(() => idx = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), label: 'Vereine'),
          NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Buchungen'),
          NavigationDestination(icon: Icon(Icons.event_available_outlined), label: 'Events'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Einstellungen'),
        ],
      ),
    );
  }
}
