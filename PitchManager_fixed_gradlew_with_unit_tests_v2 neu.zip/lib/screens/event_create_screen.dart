import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import '../state/app_state.dart';

class EventCreateScreen extends StatefulWidget {
  const EventCreateScreen({super.key});

  @override
  State<EventCreateScreen> createState() => _EventCreateScreenState();
}

class _EventCreateScreenState extends State<EventCreateScreen> {
  List<dynamic> _teams = [];
  int? _teamId;
  bool _teamsLoading = true;

  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _locCtrl = TextEditingController();
  String _type = 'training';
  DateTime _start = DateTime.now().add(const Duration(hours: 2));
  DateTime _end = DateTime.now().add(const Duration(hours: 3));
  int? _capacity;
  bool _isPublic = false;

  bool _autoLocation = true;
  double? _lat;
  double? _lon;
  String? _locLabel;
  String? _locError;

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _locCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDateTime({required bool isStart}) async {
    final base = isStart ? _start : _end;
    final date = await showDatePicker(
      context: context,
      initialDate: base,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date == null) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(base));
    if (time == null) return;
    final dt = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    setState(() {
      if (isStart) {
        _start = dt;
        if (_end.isBefore(_start.add(const Duration(minutes: 15)))) {
          _end = _start.add(const Duration(hours: 1));
        }
      } else {
        _end = dt;
      }
    });
  }

  Future<void> _resolveLocation() async {
    setState(() {
      _locError = null;
    });

    if (!_autoLocation) {
      setState(() {
        _lat = null;
        _lon = null;
        _locLabel = _locCtrl.text.trim().isEmpty ? null : _locCtrl.text.trim();
      });
      return;
    }

    try {
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.deniedForever) {
        setState(() => _locError = 'Standort dauerhaft verweigert. Bitte in den Geräteeinstellungen aktivieren.');
        return;
      }
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        setState(() => _locError = 'Standortdienste sind deaktiviert.');
        return;
      }

      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      _lat = pos.latitude;
      _lon = pos.longitude;

      String label = '${pos.latitude.toStringAsFixed(5)}, ${pos.longitude.toStringAsFixed(5)}';
      try {
        final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
        if (placemarks.isNotEmpty) {
          final p = placemarks.first;
          final parts = [p.locality, p.postalCode, p.country].where((e) => (e ?? '').isNotEmpty).map((e) => e!).toList();
          if (parts.isNotEmpty) label = parts.join(' ');
        }
      } catch (_) {
        // ignore reverse geocode errors
      }
      _locLabel = label;
      _locCtrl.text = label;
      setState(() {});
    } catch (e) {
      setState(() => _locError = 'Standort konnte nicht bestimmt werden: $e');
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    await _resolveLocation();
    if (_autoLocation && (_lat == null || _lon == null)) {
      // keep user on page if location required
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_locError ?? 'Standort nicht verfügbar')),
        );
      }
      return;
    }

    final api = context.read<AppState>().api;
    try {
      await api.createEvent(
        title: _titleCtrl.text.trim(),
        eventType: _type,
        description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
        locationLabel: _locCtrl.text.trim().isEmpty ? null : _locCtrl.text.trim(),
        startDt: _start.toLocal().toUtc(),
        endDt: _end.toLocal().toUtc(),
        capacity: _capacity,
        isPublic: _isPublic,
        weatherLat: _lat,
        weatherLon: _lon,
        weatherLocationLabel: _locLabel,
      );
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Fehler: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null) {
      _prefillFromArgs(args);
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Event erstellen')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _titleCtrl,
                decoration: const InputDecoration(labelText: 'Titel'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Bitte Titel eingeben' : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _type,
                decoration: const InputDecoration(labelText: 'Typ'),
                items: const [
                  DropdownMenuItem(value: 'training', child: Text('Training')),
                  DropdownMenuItem(value: 'spieltag', child: Text('Spieltag')),
                  DropdownMenuItem(value: 'turnier', child: Text('Turnier')),
                  DropdownMenuItem(value: 'event', child: Text('Event')),
                  DropdownMenuItem(value: 'versammlung', child: Text('Versammlung')),
                ],
                onChanged: (v) => setState(() => _type = v ?? 'event'),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _descCtrl,
                decoration: const InputDecoration(labelText: 'Beschreibung (optional)'),
                maxLines: 3,
              ),
              const SizedBox(height: 10),
              SwitchListTile(
                value: _isPublic,
                onChanged: (v) => setState(() => _isPublic = v),
                title: const Text('Öffentlich (sichtbar für alle)'),
              ),
              TextFormField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Max. Teilnehmer (optional)'),
                onChanged: (v) => _capacity = int.tryParse(v),
              ),
              const Divider(height: 24),
              ListTile(
                leading: const Icon(Icons.schedule),
                title: Text('Start: ${_start.toString()}'),
                onTap: () => _pickDateTime(isStart: true),
              ),
              ListTile(
                leading: const Icon(Icons.schedule_outlined),
                title: Text('Ende: ${_end.toString()}'),
                onTap: () => _pickDateTime(isStart: false),
              ),
              const Divider(height: 24),
              SwitchListTile(
                value: _autoLocation,
                onChanged: (v) => setState(() => _autoLocation = v),
                title: const Text('Wetter-Standort automatisch (GPS) speichern'),
                subtitle: const Text('Speichert Lat/Lon in der Veranstaltung für Live-Wetter & Einladungen.'),
              ),
              TextFormField(
                controller: _locCtrl,
                decoration: const InputDecoration(labelText: 'Ort / Standort-Label'),
              ),
              if (_locError != null) ...[
                const SizedBox(height: 8),
                Text(_locError!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _submit,
                icon: const Icon(Icons.save),
                label: const Text('Speichern'),
              ),
            ],
          ),
        ),
      ),
    );
  }

Future<void> _loadTeams() async {
  try {
    final api = ApiClient(token: context.read<AppState>().token);
    final teams = await api.listTeams();
    setState(() {
      _teams = teams;
      _teamsLoading = false;
    });
  } catch (_) {
    setState(() => _teamsLoading = false);
  }
}
}
