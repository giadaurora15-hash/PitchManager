import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/booking.dart';
import '../services/api_client.dart';
import '../state/app_state.dart';
import 'booking_create_screen.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  Timer? _autoRefreshTimer;
  bool loading = false;
  List<Booking> bookings = [];
  final Map<int, Map<String, dynamic>> _weatherCache = {};

  ApiClient _api(BuildContext context) {
    final token = context.read<AppState>().token;
    return ApiClient(token: token);
  }

  Future<void> loadBookings() async {
    setState(() => loading = true);
    try {
      bookings = await _api(context).listBookings();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> cancelBooking(int bookingId) async {
    try {
      await _api(context).cancelBooking(bookingId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Storniert')));
      }
      await loadBookings();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
  }

  String _maskLabel(int mask) {
    if (mask == 15) return 'Ganzer Platz';
    const map = {1: 'A', 2: 'B', 4: 'C', 8: 'D'};
    if (map.containsKey(mask)) return '¼ Platz (${map[mask]})';
    const halves = {3: '½ (A+B)', 12: '½ (C+D)', 5: '½ (A+C)', 10: '½ (B+D)'};
    if (halves.containsKey(mask)) return halves[mask]!;
    const threeQ = {7: '¾ (A+B+C)', 11: '¾ (A+B+D)', 13: '¾ (A+C+D)', 14: '¾ (B+C+D)'};
    if (threeQ.containsKey(mask)) return threeQ[mask]!;
    return 'Maske $mask';
  }

  String _fmtRange(Booking b) {
    final start = b.startDt.toLocal();
    final end = b.endDt.toLocal();
    String two(int v) => v.toString().padLeft(2, '0');
    final date = '${start.year}-${two(start.month)}-${two(start.day)}';
    final s = '${two(start.hour)}:${two(start.minute)}';
    final e = '${two(end.hour)}:${two(end.minute)}';
    return '$date • $s-$e • ${_maskLabel(b.segmentMask)}';
  }

  IconData _weatherIcon(int? code) {
    if (code == null) return Icons.wb_sunny_outlined;
    if ([0,1].contains(code)) return Icons.wb_sunny_outlined;
    if ([2,3].contains(code)) return Icons.cloud_outlined;
    if ([45,48].contains(code)) return Icons.cloud_outlined;
    if (code >= 51 && code <= 57) return Icons.grain_outlined;
    if (code >= 61 && code <= 67) return Icons.umbrella_outlined;
    if (code >= 71 && code <= 77) return Icons.ac_unit_outlined;
    if (code >= 80 && code <= 86) return Icons.umbrella_outlined;
    if (code >= 95) return Icons.thunderstorm_outlined;
    return Icons.cloud_outlined;
  }

  Future<Map<String, dynamic>> _getWeather(Booking b) async {
    final cached = _weatherCache[b.id];
    if (cached != null) return cached;
    final j = await _api(context).weatherAtTime(courtId: b.courtId, timeUtc: b.startDt, lat: b.weatherLat, lon: b.weatherLon);
    _weatherCache[b.id] = j;
    return j;
  }

  @override
  void initState() {
    super.initState();
    loadBookings();
    _autoRefreshTimer = Timer.periodic(const Duration(minutes: 5), (_) {
      if (!mounted) return;
      setState(() => _weatherCache.clear());
    });
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: loadBookings,
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: bookings.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final b = bookings[i];
                  return Card(
                    child: ListTile(
                      title: Text('Platz ${b.courtId} • ${b.bookingType.toUpperCase()}'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_fmtRange(b)),
                          const SizedBox(height: 4),
                          FutureBuilder<Map<String, dynamic>>(
                            future: _getWeather(b),
                            builder: (context, snap) {
                              if (snap.connectionState == ConnectionState.waiting) {
                                return const Text('Wetter: ...', style: TextStyle(color: Colors.grey));
                              }
                              if (snap.hasError) {
                                return const Text('Wetter: nicht verfügbar', style: TextStyle(color: Colors.grey));
                              }
                              final w = snap.data!;
                              final temp = ((w['temperature_c'] as num?)?.toDouble())?.toStringAsFixed(1) ?? '-';
                              final prob = w['precipitation_probability'] ?? '-';
                              final txt = w['summary_de'] ?? 'Wetter';
                              final code = w['weather_code'] as int?;
                              final warnings = (w['warnings'] as List?)?.cast<String>() ?? const <String>[];
                              final locationLabel = b.weatherLocationLabel;
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(_weatherIcon(code), size: 18),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          _weatherLine(txt: txt, temp: temp, prob: prob, locationLabel: locationLabel),
                                          style: const TextStyle(color: Colors.grey),
                                        ),
                                      ),
                                    ],
                                  ),
                                  if (warnings.isNotEmpty) ...[
                                    const SizedBox(height: 6),
                                    Wrap(
                                      spacing: 6,
                                      runSpacing: -6,
                                      children: warnings.map((t) => Chip(
                                        label: Text(t, style: const TextStyle(fontSize: 12)),
                                        visualDensity: VisualDensity.compact,
                                      )).toList(),
                                    ),
                                  ]
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                      trailing: b.status == 'cancelled'
                          ? const Icon(Icons.block, color: Colors.grey)
                          : IconButton(
                              icon: const Icon(Icons.cancel_outlined),
                              onPressed: () => cancelBooking(b.id),
                            ),
                    ),
                  );
                },
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final ok = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => const BookingCreateScreen()),
          );
          if (ok == true) loadBookings();
        },
        icon: const Icon(Icons.add),
        label: const Text('Buchung'),
      ),
    );
  }
}
