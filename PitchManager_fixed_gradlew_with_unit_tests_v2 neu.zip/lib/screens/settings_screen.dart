import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme/app_theme.dart';
import 'color_scheme_screen.dart';
import 'courts_manage_screen.dart';
import 'invites_screen.dart';
import 'teams_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final schemeName = AppThemes.schemeNames[app.schemeId] ?? app.schemeId;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Einstellungen', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Design', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 10),
                DropdownButtonFormField<ThemeMode>(
                  value: app.themeMode,
                  items: const [
                    DropdownMenuItem(value: ThemeMode.system, child: Text('Automatisch (System)')),
                    DropdownMenuItem(value: ThemeMode.light, child: Text('Hell')),
                    DropdownMenuItem(value: ThemeMode.dark, child: Text('Dunkel')),
                  ],
                  onChanged: (v) {
                    if (v != null) context.read<AppState>().setThemeMode(v);
                  },
                  decoration: const InputDecoration(labelText: 'Theme'),
                ),
                const SizedBox(height: 6),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Farbschema'),
                  subtitle: Text(schemeName),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const ColorSchemeScreen()),
                    );
                  },
                ),
                if (app.canManageCourts)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Plätze & Standorte'),
                    subtitle: const Text('Koordinaten für Live-Wetter verwalten'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const CourtsManageScreen()),
                      );
                    },
                  ),

if (app.canInviteUsers)
  ListTile(
    contentPadding: EdgeInsets.zero,
    title: const Text('Einladungen & Registrierung'),
    subtitle: const Text('Links für Spieler/Eltern/Trainer/Admin erstellen'),
    trailing: const Icon(Icons.chevron_right),
    onTap: () {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const InvitesScreen()),
      );
const Divider(height: 1),
ListTile(
  leading: const Icon(Icons.groups),
  title: const Text('Teams & Gruppen'),
  subtitle: const Text('Teams anzeigen und verwalten'),
  onTap: () => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const TeamsScreen()),
  ),
),
    },
  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Abmelden'),
                onTap: () => context.read<AppState>().logout(),
              ),
            ],
          ),
        ),
      ],
    );
  }
}