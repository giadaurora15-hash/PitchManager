import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme/app_theme.dart';

class ColorSchemeScreen extends StatelessWidget {
  const ColorSchemeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(title: const Text('Farbschema')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Wähle ein Farbschema für die App. Änderungen werden sofort gespeichert.',
            style: TextStyle(fontSize: 14),
          ),
          const SizedBox(height: 12),
          ...AppThemes.schemeNames.entries.map((e) {
            final id = e.key;
            final name = e.value;
            final isSelected = app.schemeId == id;
            final preview = AppThemes.light(id).colorScheme;

            return Card(
              child: ListTile(
                title: Text(name),
                subtitle: Text(id == AppThemes.defaultSchemeId
                    ? 'Empfohlen (Teal/Grün)'
                    : 'Alternative'),
                leading: _PreviewDots(
                  primary: preview.primary,
                  secondary: preview.secondary,
                  error: preview.error,
                ),
                trailing: isSelected ? const Icon(Icons.check_circle) : null,
                onTap: () => context.read<AppState>().setColorScheme(id),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _PreviewDots extends StatelessWidget {
  final Color primary;
  final Color secondary;
  final Color error;
  const _PreviewDots({required this.primary, required this.secondary, required this.error});

  @override
  Widget build(BuildContext context) {
    Widget dot(Color c) => Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: Colors.black12)),
        );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [dot(primary), const SizedBox(width: 4), dot(secondary), const SizedBox(width: 4), dot(error)],
    );
  }
}
