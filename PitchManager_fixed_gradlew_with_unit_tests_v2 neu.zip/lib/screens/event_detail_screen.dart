import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';

import '../models/event.dart';
import '../state/app_state.dart';

class EventDetailScreen extends StatefulWidget {
  final int eventId;
  const EventDetailScreen({super.key, required this.eventId
Future<void> _showInviteTeamDialog() async {
  final api = ApiClient(token: context.read<AppState>().token);
  final teams = await api.listTeams();
  int? teamId;
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Team einladen'),
      content: DropdownButtonFormField<int>(
        value: teamId,
        items: teams
            .map((t) => DropdownMenuItem<int>(
                  value: (t as Map<String, dynamic>)['id'] as int,
                  child: Text(t['name']?.toString() ?? 'Team'),
                ))
            .toList(),
        onChanged: (v) => teamId = v,
        decoration: const InputDecoration(labelText: 'Team'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Einladen')),
      ],
    ),
  );
  if (ok == true && teamId != null) {
    await api.inviteEventTeam(eventId: widget.eventId, teamId: teamId!);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Team eingeladen')));
    }
    await _load();
  }
}
}
);

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen> {
  late Future<Event> _eventFuture;
  late Future<List<EventParticipant>> _partsFuture;

  @override
  void initState() {
    super.initState();
    _eventFuture = _loadEvent();
    _partsFuture = _loadParticipants();
  }

  Future<Event> _loadEvent() async {
    final api = context.read<AppState>().api;
    return api.getEvent(widget.eventId);
  }

  Future<List<EventParticipant>> _loadParticipants() async {
    final api = context.read<AppState>().api;
    return api.listEventParticipants(widget.eventId);
  }

  void _refresh() {
    setState(() {
      _eventFuture = _loadEvent();
      _partsFuture = _loadParticipants();
    });
  }

  Future<void> _inviteDialog() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Einladungen senden'),
          content: TextField(
            controller: ctrl,
            decoration: const InputDecoration(
              labelText: 'E-Mails (kommagetrennt)',
              hintText: 'max@verein.de, lisa@verein.de',
            ),
            keyboardType: TextInputType.emailAddress,
            minLines: 2,
            maxLines: 4,
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Senden')),
          ],
        );
      },
    );
    if (ok != true) return;

    final emails = ctrl.text
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    if (emails.isEmpty) return;

    final api = context.read<AppState>().api;
    try {
      await api.inviteToEvent(widget.eventId, emails);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Einladungen gespeichert/gesendet.')));
      }
      _refresh();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: $e')));
      }
    }
  }

  Future<void> _sendReminders() async {
    final api = context.read<AppState>().api;
    try {
      final res = await api.sendEventReminders(widget.eventId);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Erinnerungen: ${res['sent']}/${res['total']}')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: $e')));
      }
    }
  }

  Future<void> _shareIcs() async {
    final api = context.read<AppState>().api;
    try {
      final bytes = await api.downloadEventIcs(widget.eventId);
      final dir = await Directory.systemTemp.createTemp('pitchmanager');
      final file = File('${dir.path}/event-${widget.eventId}.ics');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path)], text: 'Kalenderdatei (ICS)');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('dd.MM.yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Event'),
        actions: [
          IconButton(onPressed: _shareIcs, icon: const Icon(Icons.calendar_month)),
          IconButton(onPressed: _inviteDialog, icon: const Icon(Icons.mail_outline)),
          IconButton(onPressed: _sendReminders, icon: const Icon(Icons.notifications_active_outlined)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: FutureBuilder<Event>(
          future: _eventFuture,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError || snap.data == null) {
              return ListView(children: [
                const SizedBox(height: 40),
                Center(child: Text('Fehler: ${snap.error}')),
              ]);
            }
            final e = snap.data!;
            return ListView(
              padding: const EdgeInsets.all(12),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(e.title, style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 6),
                        Text('${e.eventType} • ${fmt.format(e.startDt.toLocal())} – ${fmt.format(e.endDt.toLocal())}'),
                        if ((e.locationLabel ?? '').isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text('Ort: ${e.locationLabel}'),
                        ],
                        if ((e.description ?? '').isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Text(e.description!),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text('Teilnehmer', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                FutureBuilder<List<EventParticipant>>(
                  future: _partsFuture,
                  builder: (context, psnap) {
                    if (psnap.connectionState != ConnectionState.done) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (psnap.hasError) {
                      return Text('Fehler: ${psnap.error}');
                    }
                    final parts = psnap.data ?? [];
                    if (parts.isEmpty) {
                      return const Text('Noch keine Einladungen/Teilnehmer.');
                    }
                    return Card(
                      child: ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: parts.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = parts[i];
                          IconData icon;
                          if (p.status == 'accepted') {
                            icon = Icons.check_circle_outline;
                          } else if (p.status == 'declined') {
                            icon = Icons.cancel_outlined;
                          } else {
                            icon = Icons.mark_email_unread_outlined;
                          }
                          return ListTile(
                            leading: Icon(icon),
                            title: Text(p.email),
                            subtitle: Text(p.status),
                          );
                        },
                      ),
                    );
                  },
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
