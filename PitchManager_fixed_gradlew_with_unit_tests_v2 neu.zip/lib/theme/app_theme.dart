import 'package:flutter/material.dart';

/// Central place for app color schemes.
///
/// The default "pitchmanager" scheme matches the palette:
/// - Primary: #0F6C7D (teal/petrol)
/// - Secondary: #2E7D32 (green)
/// - Error: #C62828 (red)
/// - Background: #F4F6F8
class AppThemes {
  static const String defaultSchemeId = 'pitchmanager';

  static const Map<String, String> schemeNames = {
    'pitchmanager': 'PitchManager (Teal/Grün)',
    'blue': 'Blau',
    'indigo': 'Indigo',
    'green': 'Grün',
    'orange': 'Orange',
    'purple': 'Lila',
  };

  static ThemeData light(String schemeId) {
    final cfg = _configFor(schemeId);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: cfg.primary,
        secondary: cfg.secondary,
        error: cfg.error,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: cfg.background,
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: cfg.primary,
        foregroundColor: Colors.white,
      ),
    );
  }

  static ThemeData dark(String schemeId) {
    final cfg = _configFor(schemeId);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: cfg.primary,
        secondary: cfg.secondary,
        error: cfg.error,
        brightness: Brightness.dark,
      ),
    );
  }

  static SchemeConfig _configFor(String schemeId) {
    return switch (schemeId) {
      'blue' => const SchemeConfig(primary: Color(0xFF1976D2), secondary: Color(0xFF2E7D32)),
      'indigo' => const SchemeConfig(primary: Color(0xFF3949AB), secondary: Color(0xFF26A69A)),
      'green' => const SchemeConfig(primary: Color(0xFF2E7D32), secondary: Color(0xFF0F6C7D)),
      'orange' => const SchemeConfig(primary: Color(0xFFF57C00), secondary: Color(0xFF0F6C7D)),
      'purple' => const SchemeConfig(primary: Color(0xFF7B1FA2), secondary: Color(0xFF0F6C7D)),
      _ => const SchemeConfig(
        primary: Color(0xFF0F6C7D),
        secondary: Color(0xFF2E7D32),
        error: Color(0xFFC62828),
        background: Color(0xFFF4F6F8),
      ),
    };
  }
}

class SchemeConfig {
  final Color primary;
  final Color secondary;
  final Color error;
  final Color background;
  const SchemeConfig({
    required this.primary,
    required this.secondary,
    this.error = const Color(0xFFC62828),
    this.background = const Color(0xFFF4F6F8),
  });
}
