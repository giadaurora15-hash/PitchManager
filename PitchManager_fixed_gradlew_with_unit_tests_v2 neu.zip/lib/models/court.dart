class Court {
  final int id;
  final String name;
  final double? latitude;
  final double? longitude;

  Court({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
  });

  factory Court.fromJson(Map<String, dynamic> j) {
    return Court(
      id: j['id'] as int,
      name: (j['name'] ?? '').toString(),
      latitude: (j['latitude'] is num) ? (j['latitude'] as num).toDouble() : null,
      longitude: (j['longitude'] is num) ? (j['longitude'] as num).toDouble() : null,
    );
  }
}
