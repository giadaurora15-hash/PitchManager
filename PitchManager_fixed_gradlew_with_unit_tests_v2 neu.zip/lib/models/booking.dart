class Booking {
  final int id;
  final int courtId;
  final String bookingType;
  final DateTime startDt;
  final DateTime endDt;
  final int segmentMask;
  final String status;
  final String? ageGroup;
  final int? clubId;
  final int? opponentClubId;
  final int? seriesId;
  final double? weatherLat;
  final double? weatherLon;
  final String? weatherLocationLabel;

  Booking({
    required this.id,
    required this.courtId,
    required this.bookingType,
    required this.startDt,
    required this.endDt,
    required this.segmentMask,
    required this.status,
    this.ageGroup,
    this.clubId,
    this.opponentClubId,
    this.seriesId,
    this.weatherLat,
    this.weatherLon,
    this.weatherLocationLabel,
  });

  factory Booking.fromJson(Map<String, dynamic> j) {
    return Booking(
      id: j['id'],
      courtId: j['court_id'],
      bookingType: j['booking_type'],
      startDt: DateTime.parse(j['start_dt']),
      endDt: DateTime.parse(j['end_dt']),
      segmentMask: j['segment_mask'],
      status: j['status'],
      ageGroup: j['age_group'],
      clubId: j['club_id'],
      opponentClubId: j['opponent_club_id'],
      seriesId: j['series_id'],
      weatherLat: (j['weather_lat'] as num?)?.toDouble(),
      weatherLon: (j['weather_lon'] as num?)?.toDouble(),
      weatherLocationLabel: j['weather_location_label'],
    );
  }
}
