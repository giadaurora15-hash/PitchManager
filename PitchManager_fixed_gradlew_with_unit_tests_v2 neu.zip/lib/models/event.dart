class Event {
  final int id;
  final String title;
  final String eventType;
  final String? description;
  final int? courtId;
  final String? locationLabel;
  final DateTime startDt;
  final DateTime endDt;
  final int? capacity;
  final bool isPublic;
  final double? weatherLat;
  final double? weatherLon;
  final String? weatherLocationLabel;
  final int createdBy;

  Event({
    required this.id,
    required this.title,
    required this.eventType,
    required this.description,
    required this.courtId,
    required this.locationLabel,
    required this.startDt,
    required this.endDt,
    required this.capacity,
    required this.isPublic,
    required this.weatherLat,
    required this.weatherLon,
    required this.weatherLocationLabel,
    required this.createdBy,
  });

  factory Event.fromJson(Map<String, dynamic> j) => Event(
        id: j['id'] as int,
        title: j['title'] as String,
        eventType: j['event_type'] as String,
        description: j['description'] as String?,
        courtId: j['court_id'] as int?,
        locationLabel: j['location_label'] as String?,
        startDt: DateTime.parse(j['start_dt'] as String),
        endDt: DateTime.parse(j['end_dt'] as String),
        capacity: j['capacity'] as int?,
        isPublic: (j['is_public'] as bool?) ?? false,
        weatherLat: (j['weather_lat'] as num?)?.toDouble(),
        weatherLon: (j['weather_lon'] as num?)?.toDouble(),
        weatherLocationLabel: j['weather_location_label'] as String?,
        createdBy: j['created_by'] as int,
      );
}

class EventParticipant {
  final int id;
  final int eventId;
  final String email;
  final String status; // invited|accepted|declined
  final DateTime? respondedAt;

  EventParticipant({
    required this.id,
    required this.eventId,
    required this.email,
    required this.status,
    required this.respondedAt,
  });

  factory EventParticipant.fromJson(Map<String, dynamic> j) => EventParticipant(
        id: j['id'] as int,
        eventId: j['event_id'] as int,
        email: j['email'] as String,
        status: j['status'] as String,
        respondedAt: j['responded_at'] == null ? null : DateTime.parse(j['responded_at'] as String),
      );
}
