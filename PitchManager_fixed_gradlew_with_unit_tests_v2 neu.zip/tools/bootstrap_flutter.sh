#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter ist nicht installiert. Bitte Flutter SDK installieren und 'flutter --version' testen."
  exit 1
fi

if [ ! -f ".metadata" ] || [ ! -d "android" ] || [ ! -d "ios" ]; then
  echo "Erzeuge Flutter Scaffold (android + ios) im aktuellen Verzeichnis..."
  flutter create . --platforms=android,ios
else
  echo "Flutter Scaffold scheint vorhanden zu sein (android + ios)."
fi

echo "Fertig. Jetzt: flutter pub get && flutter run"


# Ensure Android location permissions for live weather (geolocator)
ensure_location_permissions() {
  local manifest="android/app/src/main/AndroidManifest.xml"
  if [ -f "$manifest" ]; then
    if ! grep -q "ACCESS_FINE_LOCATION" "$manifest"; then
      # Insert permissions after <manifest ...> line
      perl -0777 -i -pe 's/(<manifest[^>]*>)/$1\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"\/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"\/>/s' "$manifest"
    fi
  fi
}

ensure_location_permissions
