# PitchManager ⚽️

PitchManager ist eine **Flutter-App** + **FastAPI-Backend** zur Platz-/Buchungsverwaltung (Training, Spieltag, Turnier, Events) mit:
- **Teilplatz-Logik** (A/B/C/D über Bitmasken `segment_mask`)
- **Serienbuchungen** (RRULE)
- **Regeln** (z. B. „Spieltag/Turnier ab C-Jugend → ganzer Platz“)
- **Vereinslogos** (Upload)

---

## Features
- Buchungen: `training`, `event`, `spieltag`, `turnier`
- Teilplätze: ¼ / ½ / ¾ / ganz (A/B/C/D)
- Konfliktprüfung: Zeitüberlappung + `(existing_mask & new_mask) != 0`
- Serien (RRULE) + Storno (ein Termin / future / all)
- Rollen: `user`, `trainer`, `admin` (JWT)
- Rate limiting (SlowAPI)
- Docker-Setup + Healthcheck

---

## Schnellstart (Docker)

1) Environment anlegen:
```bash
cp .env.example .env
```

2) Starten:
```bash
docker compose up --build
```

API:
- Swagger: `http://localhost:8000/docs`
- Health: `http://localhost:8000/health`

> Standardmäßig laufen beim Container-Start automatisch **Alembic-Migrations** (`AUTO_MIGRATE=true`).

---

## Lokal starten (ohne Docker)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env

# Migrationen
alembic -c alembic.ini upgrade head

uvicorn backend.main:app --reload
```

---

## Flutter App

```bash
flutter pub get
flutter run
```

Backend-URL:
- Android Emulator: `http://10.0.2.2:8000`
- iOS Simulator / Desktop: `http://localhost:8000`

---

## APK in GitHub bauen (ohne lokales Android-Setup)

Dieses Repository enthält GitHub Actions Workflows, die automatisch ein **Release-APK** bauen.

### 1) Build als Workflow-Artifact (bei Push auf main/master)
1. Push nach `main` (oder `master`).
2. Öffne GitHub → **Actions** → Workflow **Build APK (Artifact)**.
3. Öffne den letzten Run → lade **app-release-apk** herunter.

> Das ist ein **unsigned** Release-APK (für interne Tests / Sideloading).

### 2) APK als GitHub Release (Tag v*)
Erstelle einen Tag wie z. B. `v1.0.0` und push ihn:

```bash
git tag v1.0.0
git push origin v1.0.0
```

Dann baut GitHub Actions das APK und hängt es automatisch an ein GitHub **Release** an.

### Optional: Signiertes APK / Play-Store
Für Play Store brauchst du ein **signiertes** App Bundle (`.aab`) oder signiertes APK.
Das kann ich dir auch direkt einbauen (Keystore als GitHub Secret + Signing in CI).

---

## Platzsegmente (A/B/C/D)

Layout:
```
A | B
-----
C | D
```

Bitmasken:
- A=1, B=2, C=4, D=8, Ganz=15

---

## Wichtige Hinweise (Prod)
- Setze **JWT_SECRET** auf einen sicheren Wert.
- Setze **CORS_ORIGINS** explizit (kein `*`).
- In Produktion: **AUTO_CREATE_DB=false** und Migrationen via Alembic fahren.

---

## Live-Wetter in Buchungen

Die App zeigt Live-Wetterdaten und eine stündliche Vorhersage zur Buchungszeit (Training/Spieltag/Turnier/Event).

### Plätze & Standorte (Koordinaten)

Damit Wetterdaten korrekt sind, müssen Plätze (`courts`) Latitude/Longitude haben.

- Rollen: **`admin` und `trainer`** dürfen Plätze inkl. Koordinaten bearbeiten.
- App: **Einstellungen → Plätze & Standorte** (nur sichtbar für Admin/Trainer)

## Tests

Backend Smoke Tests:

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

### Backend E2E Tests

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

## Teams & Gruppen

- Teams verwalten: `/teams`
- Events/Buchungen können optional einem Team zugewiesen werden (`team_id`).
- Event: Team einladen: `POST /events/{id}/invite_team?team_id=...`

## Scheduled Reminders (GitHub Actions)

To enable automatic reminder emails, set these GitHub repo secrets:

- `REMINDER_URL` → your deployed backend endpoint, e.g. `https://YOUR-DOMAIN/api/automation/send_reminders?hours_before=24&window_minutes=30`
- `REMINDER_BEARER_TOKEN` → a valid JWT for an admin/trainer user (create via `/auth/token`).

The workflow runs daily at **08:00 UTC** (≈ 09:00 Berlin in winter) and can be triggered manually via **Actions → Scheduled Reminders**.



---

## Build APK via GitHub Actions

This repo includes workflows to build an **Android APK** automatically.

### Option A: On every push to main/master
- Workflow: **Build APK (Artifact)**
- Output: `app-release.apk` as a GitHub Actions artifact.

### Option B: Release on a tag
- Create a tag like `v1.0.0` and push it.
- Workflow: **Release APK**
- Output: a GitHub Release with the APK attached.

> Note: The APK built by the workflow is **unsigned** (works for testing / internal distribution). For Play Store you should add a keystore and sign the release build.

## Branding
- `branding/app-icon.png` (final icon)
- Font: Inter
- Icon rule: use only **Pitch Manager** on the arena in the app icon.


## Internal APK build (GitHub Actions)
- Workflow **Build APK (Artifact)** builds an **installable debug APK** for internal distribution.
- Download it from **Actions → run → Artifacts → app-debug-apk**.


## GitHub Actions (Internal APK)
- Workflow builds with Flutter **3.22.3** (Dart 3.3+) to satisfy pubspec SDK constraints.


## Build APK in GitHub (Internal)
1. Push to `main`.
2. Go to **Actions → Build APK (Internal)**.
3. Download **Artifacts → app-debug-apk**.
4. Install `app-debug.apk` on Android (allow unknown sources).

### Notes
- Uses Flutter 3.22.3 (Dart 3.3+).
- Debug APK is unsigned and intended for internal distribution.
