from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """App configuration loaded from environment.

    - Reads a local .env file when present (useful for dev/docker-compose).
    - Keeps sane defaults for local development.
    """

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Core
    app_name: str = "PitchManager API"
    environment: str = "dev"  # dev|prod

    # Networking / security
    cors_origins: str = "http://localhost:3000,http://localhost:5173,http://localhost:8080"

    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_exp_hours: int = 72

    # Database
    database_url: str = "sqlite:///./app.db"

    # Storage
    upload_dir: str = "uploads"

    # Optional bootstrapping
    auto_create_db: bool = True  # SQLite/dev convenience (prod should run migrations)
    seed_demo_data: bool = True

    # Rate limiting
    rate_limit_default: str = "60/minute"

    # Public URL used for invitation/RSVP links (must be reachable by members)
    public_base_url: str = "http://localhost:8000"

    # SMTP for invitations/reminders
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_user: str | None = None
    smtp_password: str | None = None
    smtp_from: str = "PitchManager <noreply@pitchmanager.local>"
    smtp_tls: bool = True


def get_settings() -> Settings:
    """Load settings from environment.

    We intentionally do **not** cache settings because the test-suite overrides
    environment variables (e.g. `DATABASE_URL`) between modules.
    """
    return Settings()
