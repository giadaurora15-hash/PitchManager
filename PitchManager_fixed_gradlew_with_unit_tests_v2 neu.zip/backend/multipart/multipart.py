"""Submodule shim for `from multipart.multipart import ...` imports."""

from __future__ import annotations

from python_multipart.multipart import *  # noqa: F403,F401
