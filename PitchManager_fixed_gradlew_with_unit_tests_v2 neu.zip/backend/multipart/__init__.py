"""Compatibility shim for Starlette/FastAPI multipart import.

Starlette imports `multipart` and `multipart.multipart.parse_options_header`.
The upstream `python-multipart` package is transitioning to `python_multipart`
namespace and emits a PendingDeprecationWarning when importing `multipart`.

To keep `-W error` test runs clean, we provide a local `multipart` package
that forwards to `python_multipart` without emitting warnings.
"""

from __future__ import annotations

# Re-export the public API expected by Starlette.
from python_multipart import __version__  # noqa: F401
from python_multipart.multipart import MultipartParser, QuerystringParser  # noqa: F401
from python_multipart.multipart import MultipartParser, QuerystringParser  # noqa: F401

