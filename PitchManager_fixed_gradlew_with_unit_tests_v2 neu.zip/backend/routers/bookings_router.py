from __future__ import annotations
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from ..db import get_db
from .. import models
from ..models import Booking, BookingSeries, Rules, Court
from ..schemas import BookingIn, BookingOut, SeriesIn, SeriesOut, BookingUpdateIn
from ..auth import get_current_user, require_roles
from ..rules import should_force_full_field
from dateutil.rrule import rrulestr
from ..services.audit_service import log_action

def _suggest_alternatives(db: Session, booking: models.Booking, limit: int = 5) -> list[dict]:
    """Suggest alternative court/time slots in 15-min steps."""
    # prepare bookings index for the time window
    courts = db.query(models.Court).order_by(models.Court.name.asc()).all()
    # candidate time shifts in minutes
    shifts = [0, 15, -15, 30, -30, 45, -45, 60, -60]
    suggestions: list[dict] = []

    def conflicts(court_id: int, start_dt, end_dt, seg_mask: int) -> bool:
        overlaps = (
            db.query(models.Booking)
            .filter(
                models.Booking.id != booking.id,
                models.Booking.court_id == court_id,
                models.Booking.status == "active",
                models.Booking.start_dt < end_dt,
                models.Booking.end_dt > start_dt,
            )
            .all()
        )
        for o in overlaps:
            if (o.segment_mask & seg_mask) != 0:
                return True
        return False

    # 1) same time, other courts
    for c in courts:
        if c.id == booking.court_id:
            continue
        if not conflicts(c.id, booking.start_dt, booking.end_dt, booking.segment_mask):
            suggestions.append({
                "court_id": c.id,
                "court_name": c.name,
                "start_dt": booking.start_dt.isoformat(),
                "end_dt": booking.end_dt.isoformat(),
                "segment_mask": booking.segment_mask,
                "reason": "Freier anderer Platz",
            })
            if len(suggestions) >= limit:
                return suggestions

    # 2) same court, shifted time
    for sh in shifts:
        if sh == 0:
            continue
        ns = booking.start_dt + timedelta(minutes=sh)
        ne = booking.end_dt + timedelta(minutes=sh)
        if not conflicts(booking.court_id, ns, ne, booking.segment_mask):
            suggestions.append({
                "court_id": booking.court_id,
                "court_name": next((c.name for c in courts if c.id == booking.court_id), f"Platz {booking.court_id}"),
                "start_dt": ns.isoformat(),
                "end_dt": ne.isoformat(),
                "segment_mask": booking.segment_mask,
                "reason": f"Zeitverschiebung {sh} min",
            })
            if len(suggestions) >= limit:
                break

    return suggestions

def _can_view_team_item(db: Session, user: models.User, team_id: int | None) -> bool:
    if team_id is None:
        return True
    if user.role == "admin":
        return True
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user.id)
        .first()
    )
    return tm is not None

def _require_team_trainer_or_admin(db: Session, user: models.User, team_id: int | None):
    if team_id is None:
        return
    if user.role == "admin":
        return
    if user.role != "trainer":
        raise HTTPException(status_code=403, detail="Not allowed")
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user.id, models.TeamMember.role == "trainer")
        .first()
    )
    if not tm:
        raise HTTPException(status_code=403, detail="Trainer not assigned to this team")

router = APIRouter(tags=["bookings"])

def get_rules(db: Session) -> Rules:
    r = db.query(Rules).first()
    if not r:
        r = Rules()
        db.add(r); db.commit(); db.refresh(r)
    return r

def ensure_court_exists(db: Session, court_id: int):
    if not db.get(Court, court_id):
        raise HTTPException(status_code=400, detail="Invalid court_id")

def validate_spieltag_fields(booking_type: str, club_id: int | None, opponent_club_id: int | None):
    if booking_type.lower() == "spieltag":
        if club_id is None or opponent_club_id is None:
            raise HTTPException(status_code=400, detail="Spieltag requires club_id and opponent_club_id")
        if club_id == opponent_club_id:
            raise HTTPException(status_code=400, detail="Heimverein und Gastverein dürfen nicht gleich sein")

def apply_full_field_rule(db: Session, user_role: str, data: dict) -> dict:
    r = get_rules(db)
    force = should_force_full_field(data["booking_type"], data.get("age_group"), r.full_field_min_age_group, r.full_field_types)
    override = bool(data.get("override_full_field_rule"))
    if force and not override:
        data["segment_mask"] = 15
        return data
    if force and override:
        if user_role == "admin" and r.allow_override_for_admin:
            return data
        if user_role == "trainer" and r.allow_override_for_trainer:
            return data
        data["segment_mask"] = 15
    return data

def check_conflict(db: Session, court_id: int, start_dt: datetime, end_dt: datetime, segment_mask: int, exclude_booking_id: int | None = None):
    q = db.query(Booking).filter(
        Booking.court_id == court_id,
        Booking.status == "active",
        Booking.start_dt < end_dt,
        Booking.end_dt > start_dt,
    )
    if exclude_booking_id:
        q = q.filter(Booking.id != exclude_booking_id)
    for b in q.all():
        if (b.segment_mask & segment_mask) != 0:
            raise HTTPException(status_code=409, detail=f"Booking conflict with booking_id={b.id}")

@router.get("/bookings", response_model=list[BookingOut])
def list_bookings(db: Session = Depends(get_db), user=Depends(get_current_user)):
    bs = db.query(Booking).order_by(Booking.start_dt.desc()).limit(200).all()
    bs = [b for b in bs if _can_view_team_item(db, user, getattr(b, 'team_id', None))]
    return [BookingOut(
        id=b.id, booking_type=b.booking_type, court_id=b.court_id,
        start_dt=b.start_dt, end_dt=b.end_dt, segment_mask=b.segment_mask,
        status=b.status, age_group=b.age_group, club_id=b.club_id, opponent_club_id=b.opponent_club_id,
        weather_lat=b.weather_lat, weather_lon=b.weather_lon, weather_location_label=b.weather_location_label,
        series_id=b.series_id,
        team_id=getattr(b,'team_id',None)
    ) for b in bs]

@router.post("/bookings", response_model=BookingOut)
def create_booking(payload: BookingIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_court_exists(db, payload.court_id)
    validate_spieltag_fields(payload.booking_type, payload.club_id, payload.opponent_club_id)
    data = apply_full_field_rule(db, user.role, payload.model_dump())

    if data["end_dt"] <= data["start_dt"]:
        raise HTTPException(status_code=400, detail="end_dt must be after start_dt")
    if not (1 <= data["segment_mask"] <= 15):
        raise HTTPException(status_code=400, detail="segment_mask must be 1..15")

    check_conflict(db, data["court_id"], data["start_dt"], data["end_dt"], data["segment_mask"])
    b = Booking(
        booking_type=data["booking_type"].lower(),
        court_id=data["court_id"],
        start_dt=data["start_dt"],
        end_dt=data["end_dt"],
        segment_mask=data["segment_mask"],
        age_group=data.get("age_group"),
        club_id=data.get("club_id"),
        opponent_club_id=data.get("opponent_club_id"),
        weather_snapshot=data.get("weather_snapshot"),
        weather_lat=data.get("weather_lat"),
        weather_lon=data.get("weather_lon"),
        weather_location_label=data.get("weather_location_label"),
        created_by=user.id
    )
    db.add(b); db.commit(); db.refresh(b)
    log_action(db, actor_user_id=user.id, action="booking.create", entity_type="booking", entity_id=b.id, payload={"court_id": b.court_id, "start_dt": b.start_dt.isoformat(), "end_dt": b.end_dt.isoformat(), "type": b.booking_type})
    return BookingOut(
        id=b.id, booking_type=b.booking_type, court_id=b.court_id,
        start_dt=b.start_dt, end_dt=b.end_dt, segment_mask=b.segment_mask,
        status=b.status, age_group=b.age_group, club_id=b.club_id, opponent_club_id=b.opponent_club_id,
        weather_lat=b.weather_lat, weather_lon=b.weather_lon, weather_location_label=b.weather_location_label,
        series_id=b.series_id,
        team_id=getattr(b,'team_id',None)
    )

@router.post("/bookings/{booking_id}/cancel", response_model=BookingOut)
def cancel_booking(booking_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    b = db.get(Booking, booking_id)
    if not b:
        raise HTTPException(status_code=404, detail="Not found")
    if user.role != "admin" and b.created_by != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")
    b.status = "cancelled"
    db.commit(); db.refresh(b)
    log_action(db, actor_user_id=user.id, action="booking.cancel", entity_type="booking", entity_id=b.id, payload={"status": b.status})
    return BookingOut(
        id=b.id, booking_type=b.booking_type, court_id=b.court_id,
        start_dt=b.start_dt, end_dt=b.end_dt, segment_mask=b.segment_mask,
        status=b.status, age_group=b.age_group, club_id=b.club_id, opponent_club_id=b.opponent_club_id,
        weather_lat=b.weather_lat, weather_lon=b.weather_lon, weather_location_label=b.weather_location_label,
        series_id=b.series_id,
        team_id=getattr(b,'team_id',None)
    )

@router.get("/series", response_model=list[SeriesOut])
def list_series(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ss = db.query(BookingSeries).order_by(BookingSeries.id.desc()).limit(200).all()
    return [SeriesOut(
        id=s.id, title=s.title, booking_type=s.booking_type, court_id=s.court_id,
        start_dt=s.start_dt, end_dt=s.end_dt, rrule=s.rrule
    ) for s in ss]

@router.post("/series", response_model=SeriesOut)
def create_series(payload: SeriesIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_court_exists(db, payload.court_id)
    validate_spieltag_fields(payload.booking_type, payload.club_id, payload.opponent_club_id)
    data = apply_full_field_rule(db, user.role, payload.model_dump())

    if data["end_dt"] <= data["start_dt"]:
        raise HTTPException(status_code=400, detail="end_dt must be after start_dt")
    if not (1 <= data["segment_mask"] <= 15):
        raise HTTPException(status_code=400, detail="segment_mask must be 1..15")

    s = BookingSeries(
        title=data["title"],
        booking_type=data["booking_type"].lower(),
        court_id=data["court_id"],
        start_dt=data["start_dt"],
        end_dt=data["end_dt"],
        rrule=data["rrule"],
        age_group=data.get("age_group"),
        club_id=data.get("club_id"),
        opponent_club_id=data.get("opponent_club_id"),
        segment_mask=data["segment_mask"],
        created_by=user.id
    )
    db.add(s); db.commit(); db.refresh(s)

    rule = rrulestr(s.rrule, dtstart=s.start_dt)
    horizon = s.start_dt.replace(year=s.start_dt.year + 1)
    count = 0
    for occ in rule.between(s.start_dt, horizon, inc=True):
        occ_end = occ + (s.end_dt - s.start_dt)
        check_conflict(db, s.court_id, occ, occ_end, s.segment_mask)
        db.add(Booking(
            booking_type=s.booking_type,
            court_id=s.court_id,
            start_dt=occ,
            end_dt=occ_end,
            segment_mask=s.segment_mask,
            age_group=s.age_group,
            club_id=s.club_id,
            opponent_club_id=s.opponent_club_id,
            series_id=s.id,
            created_by=user.id
        ))
        count += 1
        if count >= 200:
            break
    db.commit()

    return SeriesOut(id=s.id, title=s.title, booking_type=s.booking_type, court_id=s.court_id, start_dt=s.start_dt, end_dt=s.end_dt, rrule=s.rrule)

@router.post("/series/{series_id}/cancel")
def cancel_series(series_id: int, scope: str = Query("all", pattern="^(all|future|one)$"), booking_id: int | None = None,
                 db: Session = Depends(get_db), user=Depends(get_current_user)):
    s = db.get(BookingSeries, series_id)
    if not s:
        raise HTTPException(status_code=404, detail="Series not found")
    if user.role != "admin" and s.created_by != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")

    q = db.query(Booking).filter(Booking.series_id == series_id, Booking.status == "active")
    if scope == "one":
        if not booking_id:
            raise HTTPException(status_code=400, detail="booking_id required for scope=one")
        q = q.filter(Booking.id == booking_id)
    elif scope == "future":
        if not booking_id:
            raise HTTPException(status_code=400, detail="booking_id required for scope=future")
        anchor = db.get(Booking, booking_id)
        if not anchor:
            raise HTTPException(status_code=404, detail="Anchor booking not found")
        q = q.filter(Booking.start_dt >= anchor.start_dt)

    updated = 0
    for b in q.all():
        b.status = "cancelled"
        updated += 1
    db.commit()
    return {"status": "ok", "cancelled": updated}


@router.patch("/bookings/{booking_id}", response_model=BookingOut)
def update_booking(
    booking_id: int,
    payload: BookingUpdateIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(require_roles("admin", "trainer")),
):
    b = db.query(models.Booking).filter(models.Booking.id == booking_id).first()
    if not b:
        raise HTTPException(status_code=404, detail="Booking not found")

    # Trainers can only edit bookings belonging to their teams (if team_id set)
    _require_team_trainer_or_admin(db, user, getattr(b, "team_id", None))

    if payload.start_dt is not None:
        b.start_dt = payload.start_dt
    if payload.end_dt is not None:
        b.end_dt = payload.end_dt
    if payload.segment_mask is not None:
        b.segment_mask = payload.segment_mask

    # Basic validation
    if b.end_dt <= b.start_dt:
        raise HTTPException(status_code=400, detail="Invalid time range")

    # Conflict check (same court, overlapping time, overlapping segments)
    overlaps = (
        db.query(models.Booking)
        .filter(
            models.Booking.id != b.id,
            models.Booking.court_id == b.court_id,
            models.Booking.status == "active",
            models.Booking.start_dt < b.end_dt,
            models.Booking.end_dt > b.start_dt,
        )
        .all()
    )
    for other in overlaps:
        if (other.segment_mask & b.segment_mask) != 0:
            raise HTTPException(status_code=409, detail={"message":"Booking conflict","suggestions": _suggest_alternatives(db, b)})

    db.commit()
    db.refresh(b)

    return BookingOut(
        id=b.id,
        court_id=b.court_id,
        booking_type=b.booking_type,
        segment_mask=b.segment_mask,
        start_dt=b.start_dt,
        end_dt=b.end_dt,
        status=b.status,
        series_id=b.series_id,
        team_id=getattr(b, "team_id", None),
    )


