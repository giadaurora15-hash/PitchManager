from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse, Response
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..auth import get_current_user, require_roles
from ..db import get_db
from ..core.config import get_settings
from ..models import Event, EventParticipant, User
from ..schemas import EventIn, EventOut, EventInviteIn, EventParticipantOut
from ..services.emailer import send_email
from ..services.audit_service import log_action
from .. import models


def _can_view_team_item(db: Session, user: models.User, team_id: int | None) -> bool:
    if team_id is None:
        return True
    if user.role == "admin":
        return True
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user.id)
        .first()
    )
    return tm is not None

def _require_team_trainer_or_admin(db: Session, user: models.User, team_id: int | None):
    if team_id is None:
        return
    if user.role == "admin":
        return
    if user.role != "trainer":
        raise HTTPException(status_code=403, detail="Not allowed")
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user.id, models.TeamMember.role == "trainer")
        .first()
    )
    if not tm:
        raise HTTPException(status_code=403, detail="Trainer not assigned to this team")

router = APIRouter(prefix="/events", tags=["events"])


def _accepted_count(db: Session, event_id: int) -> int:
    return db.execute(
        select(EventParticipant).where(
            EventParticipant.event_id == event_id,
            EventParticipant.status == "accepted",
        )
    ).scalars().all().__len__()

def _promote_waitlist(db: Session, event_id: int) -> EventParticipant | None:
    # Promote earliest waitlist participant to accepted
    p = db.execute(
        select(EventParticipant)
        .where(EventParticipant.event_id == event_id, EventParticipant.status == "waitlist")
        .order_by(EventParticipant.invited_at.asc())
    ).scalars().first()
    if not p:
        return None
    p.status = "accepted"
    p.responded_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(p)
    return p


def _event_to_out(e: Event) -> EventOut:
    return EventOut(
        id=e.id,
        title=e.title,
        event_type=e.event_type,
        description=e.description,
        court_id=e.court_id,
        location_label=e.location_label,
        start_dt=e.start_dt,
        end_dt=e.end_dt,
        capacity=e.capacity,
        is_public=e.is_public,
        weather_lat=e.weather_lat,
        weather_lon=e.weather_lon,
        weather_location_label=e.weather_location_label,
        created_by=e.created_by,
    )


@router.get("", response_model=list[EventOut])
def list_events(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    events = db.execute(select(Event).order_by(Event.start_dt.desc())).scalars().all()
    return [_event_to_out(e) for e in events]


@router.post("", response_model=EventOut)
def create_event(
    payload: EventIn,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "trainer")),
):
    e = Event(
        title=payload.title,
        event_type=payload.event_type,
        description=payload.description,
        court_id=payload.court_id,
        location_label=payload.location_label,
        start_dt=payload.start_dt,
        end_dt=payload.end_dt,
        capacity=payload.capacity,
        is_public=payload.is_public,
        weather_lat=payload.weather_lat,
        weather_lon=payload.weather_lon,
        weather_location_label=payload.weather_location_label,
        created_by=user.id,
    )
    db.add(e)
    db.commit()
    db.refresh(e)
    log_action(db, actor_user_id=user.id, action="event.create", entity_type="event", entity_id=e.id, payload={"title": e.title, "type": e.event_type})
    return _event_to_out(e)


@router.get("/{event_id}", response_model=EventOut)
def get_event(
    event_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")
    return _event_to_out(e)


@router.get("/{event_id}/participants", response_model=list[EventParticipantOut])
def list_participants(
    event_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "trainer")),
):
    rows = db.execute(select(EventParticipant).where(EventParticipant.event_id == event_id)).scalars().all()
    return [
        EventParticipantOut(
            id=r.id,
            event_id=r.event_id,
            email=r.email,
            status=r.status,  # type: ignore
            responded_at=r.responded_at,
        )
        for r in rows
    ]


@router.post("/{event_id}/invite", response_model=list[EventParticipantOut])
def invite_participants(
    event_id: int,
    payload: EventInviteIn,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "trainer")),
):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")

    settings = get_settings()
    created: list[EventParticipant] = []
    for email in payload.emails:
        email_s = str(email).lower().strip()
        if not email_s:
            continue
        # Upsert behavior
        existing = db.execute(
            select(EventParticipant).where(
                EventParticipant.event_id == event_id,
                EventParticipant.email == email_s,
            )
        ).scalars().first()
        if existing:
            created.append(existing)
            continue

        p = EventParticipant(event_id=event_id, email=email_s)
        db.add(p)
        created.append(p)

    db.commit()
    log_action(db, actor_user_id=user.id, action="event.invite", entity_type="event", entity_id=e.id, payload={"count": len(created)})
    # Refresh tokens
    for p in created:
        db.refresh(p)

    # Send emails (best-effort)
    for p in created:
        yes = f"{settings.public_base_url}/events/rsvp/{p.invite_token}?response=yes"
        no = f"{settings.public_base_url}/events/rsvp/{p.invite_token}?response=no"
        subject = f"Einladung: {e.title}"
        text = (
            f"Hallo!\n\nDu wurdest zu einer Vereinsveranstaltung eingeladen:\n"
            f"\nTitel: {e.title}\nTyp: {e.event_type}\n"
            f"Beginn (UTC): {e.start_dt.isoformat()}\nEnde (UTC): {e.end_dt.isoformat()}\n"
            f"Ort: {e.location_label or (e.weather_location_label or '—')}\n\n"
            f"Bitte antworte hier:\nZusage: {yes}\nAbsage: {no}\n\n"
            f"(Automatisch generiert durch PitchManager)"
        )
        try:
            send_email(p.email, subject, text)
        except Exception:
            # If SMTP isn't configured, keep data saved; organizer can resend later.
            pass

    return [
        EventParticipantOut(
            id=r.id,
            event_id=r.event_id,
            email=r.email,
            status=r.status,  # type: ignore
            responded_at=r.responded_at,
        )
        for r in created
    ]


@router.post("/{event_id}/remind", response_model=dict)
def send_reminders(
    event_id: int,
    only_status: str = Query(default="invited", description="invited|accepted|declined"),
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "trainer")),
):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")
    settings = get_settings()
    participants = db.execute(
        select(EventParticipant).where(EventParticipant.event_id == event_id, EventParticipant.status == only_status)
    ).scalars().all()

    sent = 0
    for p in participants:
        yes = f"{settings.public_base_url}/events/rsvp/{p.invite_token}?response=yes"
        no = f"{settings.public_base_url}/events/rsvp/{p.invite_token}?response=no"
        subject = f"Erinnerung: {e.title}"
        text = (
            f"Hallo!\n\nErinnerung für: {e.title}\n"
            f"Beginn (UTC): {e.start_dt.isoformat()}\n\n"
            f"Zusage: {yes}\nAbsage: {no}\n"
        )
        try:
            send_email(p.email, subject, text)
            sent += 1
        except Exception:
            pass

    return {"sent": sent, "total": len(participants)}


@router.get("/rsvp/{token}", response_class=HTMLResponse)
def rsvp(token: str, response: str = Query(..., pattern="^(yes|no)$"), db: Session = Depends(get_db)):
    p = db.execute(select(EventParticipant).where(EventParticipant.invite_token == token)).scalars().first()
    if not p or p.status == "revoked" or p.revoked_at is not None:
        raise HTTPException(status_code=404, detail="Invalid invitation")
    e = db.get(Event, p.event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")

    now = datetime.now(timezone.utc)
    if response == "yes":
        # Capacity handling: if full, put on waitlist.
        if e.capacity is not None:
            accepted = db.execute(
                select(EventParticipant).where(
                    EventParticipant.event_id == e.id,
                    EventParticipant.status == "accepted",
                )
            ).scalars().all()
            if len(accepted) >= e.capacity:
                p.status = "waitlist"
                p.responded_at = now
                db.commit()
                return HTMLResponse(
                    content=(
                        "<html><head><meta charset='utf-8'><title>RSVP</title></head>"
                        "<body style='font-family: system-ui; padding: 24px;'>"
                        "<h2>Danke! Du stehst auf der Warteliste.</h2>"
                        f"<p><b>{e.title}</b></p>"
                        "<p>Alle Plätze sind aktuell belegt. Du wirst automatisch nachrücken, sobald ein Platz frei wird.</p>"
                        "</body></html>"
                    )
                )
        p.status = "accepted"
        p.responded_at = now
        db.commit()
        status_label = "Zusage"
    else:
        p.status = "declined"
        p.responded_at = now
        db.commit()
        status_label = "Absage"
        # Promote from waitlist if capacity allows
        if e.capacity is not None:
            accepted_cnt = db.execute(
                select(EventParticipant).where(
                    EventParticipant.event_id == e.id,
                    EventParticipant.status == "accepted",
                )
            ).scalars().all()
            if len(accepted_cnt) < e.capacity:
                _promote_waitlist(db, e.id)

    return HTMLResponse(
        content=(
            "<html><head><meta charset='utf-8'><title>RSVP</title></head>"
            "<body style='font-family: system-ui; padding: 24px;'>"
            f"<h2>Danke! Antwort gespeichert.</h2>"
            f"<p><b>{e.title}</b></p>"
            f"<p>Status: <b>{status_label}</b></p>"
            "</body></html>"
        )
    )



@router.get("/{event_id}/ics")
def event_ics(
    event_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(status_code=404, detail="Event not found")

    def fmt(dt: datetime) -> str:
        return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    uid = f"event-{e.id}@pitchmanager"
    desc = (e.description or "").replace("\n", "\\n")
    loc = (e.location_label or e.weather_location_label or "").replace("\n", " ")
    ics = (
        "BEGIN:VCALENDAR\r\n"
        "VERSION:2.0\r\n"
        "PRODID:-//PitchManager//EN\r\n"
        "BEGIN:VEVENT\r\n"
        f"UID:{uid}\r\n"
        f"DTSTAMP:{fmt(datetime.now(timezone.utc))}\r\n"
        f"DTSTART:{fmt(e.start_dt)}\r\n"
        f"DTEND:{fmt(e.end_dt)}\r\n"
        f"SUMMARY:{e.title}\r\n"
        f"DESCRIPTION:{desc}\r\n"
        f"LOCATION:{loc}\r\n"
        "END:VEVENT\r\n"
        "END:VCALENDAR\r\n"
    )
    return Response(content=ics, media_type="text/calendar", headers={"Content-Disposition": f"attachment; filename=event-{e.id}.ics"})

@router.post("/{event_id}/invite_team")
def invite_team(
    event_id: int,
    team_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    require_roles(user, "admin", "trainer")
    _require_team_trainer_or_admin(db, user, team_id)

    event = db.query(models.Event).filter(models.Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    members = (
        db.query(models.TeamMember, models.User)
        .join(models.User, models.User.id == models.TeamMember.user_id)
        .filter(models.TeamMember.team_id == team_id)
        .all()
    )
    emails = [u.email for tm, u in members if u.email]
    if not emails:
        return {"detail": "No members in team", "invited": 0}

    # Reuse existing invite logic endpoint if present:
    # We call same internal helper by posting to existing invite function, but simplest: add participants as invited.
    invited = 0
    for email in set(emails):
        existing = (
            db.query(models.EventParticipant)
            .filter(models.EventParticipant.event_id == event_id, models.EventParticipant.email == email)
            .first()
        )
        if existing:
            continue
        db.add(models.EventParticipant(event_id=event_id, email=email, status="invited"))
        invited += 1
    db.commit()
    return {"invited": invited, "team_id": team_id}
