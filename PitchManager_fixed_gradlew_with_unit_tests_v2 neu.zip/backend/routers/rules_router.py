from __future__ import annotations
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Rules
from ..schemas import RulesOut, RulesIn
from ..auth import require_roles

router = APIRouter(prefix="/rules", tags=["rules"])

def get_or_create(db: Session) -> Rules:
    r = db.query(Rules).first()
    if not r:
        r = Rules()
        db.add(r); db.commit(); db.refresh(r)
    return r

@router.get("", response_model=RulesOut)
def get_rules(db: Session = Depends(get_db)):
    r = get_or_create(db)
    return RulesOut(
        full_field_min_age_group=r.full_field_min_age_group,
        full_field_types=[t.strip() for t in r.full_field_types.split(",") if t.strip()],
        allow_override_for_admin=r.allow_override_for_admin,
        allow_override_for_trainer=r.allow_override_for_trainer,
    )

@router.put("", response_model=RulesOut, dependencies=[Depends(require_roles("admin"))])
def update_rules(payload: RulesIn, db: Session = Depends(get_db)):
    r = get_or_create(db)
    r.full_field_min_age_group = payload.full_field_min_age_group
    r.full_field_types = ",".join(payload.full_field_types)
    r.allow_override_for_admin = payload.allow_override_for_admin
    r.allow_override_for_trainer = payload.allow_override_for_trainer
    db.commit()
    return get_rules(db)
