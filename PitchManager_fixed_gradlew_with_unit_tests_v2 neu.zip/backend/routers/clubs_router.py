from __future__ import annotations
import os, uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Club
from ..schemas import ClubIn, ClubOut
from ..auth import require_roles
from ..core.config import get_settings

router = APIRouter(prefix="/clubs", tags=["clubs"])

UPLOAD_DIR = get_settings().upload_dir
MAX_BYTES = 2 * 1024 * 1024
ALLOWED = {"image/png","image/jpeg","image/webp"}

def club_to_out(c: Club) -> ClubOut:
    logo_url = f"/uploads/{os.path.basename(c.logo_path)}" if c.logo_path else None
    return ClubOut(id=c.id, name=c.name, logo_url=logo_url)

@router.get("", response_model=list[ClubOut])
def list_clubs(db: Session = Depends(get_db)):
    clubs = db.query(Club).order_by(Club.name.asc()).all()
    return [club_to_out(c) for c in clubs]

@router.post("", response_model=ClubOut, dependencies=[Depends(require_roles("admin"))])
def create_club(payload: ClubIn, db: Session = Depends(get_db)):
    if db.query(Club).filter(Club.name == payload.name).first():
        raise HTTPException(status_code=400, detail="Club already exists")
    c = Club(name=payload.name)
    db.add(c); db.commit(); db.refresh(c)
    return club_to_out(c)

@router.put("/{club_id}", response_model=ClubOut, dependencies=[Depends(require_roles("admin"))])
def update_club(club_id: int, payload: ClubIn, db: Session = Depends(get_db)):
    c = db.get(Club, club_id)
    if not c:
        raise HTTPException(status_code=404, detail="Not found")
    c.name = payload.name
    db.commit(); db.refresh(c)
    return club_to_out(c)

@router.post("/{club_id}/logo", response_model=ClubOut, dependencies=[Depends(require_roles("admin","trainer"))])
async def upload_logo(club_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    c = db.get(Club, club_id)
    if not c:
        raise HTTPException(status_code=404, detail="Club not found")
    if file.content_type not in ALLOWED:
        raise HTTPException(status_code=400, detail="Unsupported file type")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="File too large (max 2MB)")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    ext = ".png" if file.content_type=="image/png" else ".jpg" if file.content_type=="image/jpeg" else ".webp"
    fname = f"club_{club_id}_{uuid.uuid4().hex}{ext}"
    path = os.path.join(UPLOAD_DIR, fname)
    with open(path, "wb") as f:
        f.write(data)
    c.logo_path = path
    db.commit(); db.refresh(c)
    return club_to_out(c)
