"""API routers package.

Keep this module lightweight: individual routers are imported where they are
registered (e.g. in `backend/main.py`).
"""

