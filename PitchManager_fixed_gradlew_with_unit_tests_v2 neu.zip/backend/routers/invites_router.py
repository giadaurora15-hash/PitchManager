from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..auth import require_roles
from ..core.config import get_settings
from ..db import get_db
from ..models import Invitation, User
from ..schemas import InviteCreateIn, InviteOut, RegisterWithInviteIn, TokenOut
from ..services.emailer import send_email
from ..services.audit_service import log_action

router = APIRouter(prefix="/invites", tags=["invites"])

ALLOWED_ROLES = {"player","guardian","trainer","admin"}

def _make_token() -> str:
    # 48 chars url-safe
    import secrets
    return secrets.token_urlsafe(36)

def _invite_link(token: str) -> str:
    s = get_settings()
    # This is a backend URL; the app can open a registration screen and paste token.
    return f"{s.public_base_url.rstrip('/')}/auth/register?token={token}"

@router.post("", response_model=list[InviteOut])
def create_invites(
    payload: InviteCreateIn,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin","trainer")),
):
    role = payload.role.lower()
    if role not in ALLOWED_ROLES:
        raise HTTPException(status_code=400, detail="Invalid role")

    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(days=payload.expires_in_days)

    created: list[InviteOut] = []
    for email in payload.emails:
        token = _make_token()
        inv = Invitation(
            token=token,
            email=str(email).lower(),
            role=role,
            related_player_email=str(payload.related_player_email).lower() if payload.related_player_email else None,
            created_by_user_id=user.id,
            expires_at=expires_at,
        )
        db.add(inv)
        db.flush()  # assign id

        link = _invite_link(token)

        # Send email if SMTP configured
        subject = "PitchManager – Einladung zur Registrierung"
        text = (
            f"Du wurdest eingeladen, dich bei PitchManager zu registrieren.\n\n"
            f"Rolle: {role}\n"
            f"Registrierungslink: {link}\n\n"
            f"Dieser Link ist gültig bis: {expires_at.isoformat()}\n"
        )
        try:
            send_email(str(email), subject, text)
        except Exception:
            # Not fatal; keep invite and return link so it can be shared manually.
            pass

        created.append(
            InviteOut(
                token=token,
                role=role,
                email=email,
                related_player_email=payload.related_player_email,
                expires_at=expires_at,
                used_at=None,
                revoked_at=None,
                link=link,
            )
        )

    db.commit()
    log_action(db, actor_user_id=user.id, action="invite.create", entity_type="invitation", entity_id=None, payload={"role": role, "count": len(created)})
    return created


@router.get("", response_model=list[InviteOut])
def list_invites(
    include_used: bool = False,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin","trainer")),
):
    q = select(Invitation).order_by(Invitation.created_at.desc())
    if not include_used:
        q = q.where(Invitation.used_at.is_(None), Invitation.revoked_at.is_(None))
    rows = db.execute(q).scalars().all()
    out: list[InviteOut] = []
    for inv in rows:
        out.append(
            InviteOut(
                token=inv.token,
                role=inv.role,
                email=inv.email,
                related_player_email=inv.related_player_email,
                expires_at=inv.expires_at,
                used_at=inv.used_at,
                revoked_at=inv.revoked_at,
                link=_invite_link(inv.token),
            )
        )
    return out


@router.post("/{token}/revoke", response_model=InviteOut)
def revoke_invite(
    token: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin","trainer")),
):
    inv = db.execute(select(Invitation).where(Invitation.token == token)).scalars().first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invite not found")
    if inv.used_at is not None:
        raise HTTPException(status_code=400, detail="Invite already used")
    inv.revoked_at = datetime.now(timezone.utc)
    db.commit()
    log_action(db, actor_user_id=user.id, action="invite.revoke", entity_type="invitation", entity_id=inv.id, payload={"email": inv.email, "role": inv.role})
    return InviteOut(
        token=inv.token,
        role=inv.role,
        email=inv.email,
        related_player_email=inv.related_player_email,
        expires_at=inv.expires_at,
        used_at=inv.used_at,
        revoked_at=inv.revoked_at,
        link=_invite_link(inv.token),
    )


# ---- Registration using an invitation token ----

@router.post("/register", response_model=TokenOut, include_in_schema=False)
def register_with_invite_internal(
    payload: RegisterWithInviteIn,
    db: Session = Depends(get_db),
):
    """Kept for internal testing; prefer /auth/register-with-invite."""
    from ..routers.auth_router import register_with_invite
    return register_with_invite(payload, db)
