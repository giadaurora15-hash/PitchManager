from __future__ import annotations
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Invitation, GuardianLink
from ..schemas import RegisterIn, RegisterWithInviteIn, TokenOut
from ..auth import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=TokenOut)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    """Bootstrap registration (first admin).

    For security, normal registration happens via invitation links.
    This endpoint only works when there are no users yet.
    """
    has_any = db.query(User).limit(1).first()
    if has_any:
        raise HTTPException(status_code=403, detail="Registration requires an invitation")
    role = (payload.role or "admin").lower()
    if role not in ("admin","trainer"):
        role = "admin"
    user = User(email=payload.email.lower(), password_hash=hash_password(payload.password), role=role)
    db.add(user); db.commit(); db.refresh(user)
    return TokenOut(access_token=create_access_token(user))

@router.post("/register-with-invite", response_model=TokenOut)
def register_with_invite(payload: RegisterWithInviteIn, db: Session = Depends(get_db)):
    """Register a user using an invitation token."""
    inv = db.query(Invitation).filter(Invitation.token == payload.token).first()
    if not inv:
        raise HTTPException(status_code=400, detail="Invalid invitation token")
    now = datetime.utcnow()  # keep naive for SQLite compatibility
    if inv.revoked_at is not None:
        raise HTTPException(status_code=400, detail="Invitation revoked")
    if inv.used_at is not None:
        raise HTTPException(status_code=400, detail="Invitation already used")
    if inv.expires_at is not None and inv.expires_at.replace(tzinfo=None) < now:
        raise HTTPException(status_code=400, detail="Invitation expired")

    email = payload.email.lower()
    if inv.email and inv.email.lower() != email:
        raise HTTPException(status_code=400, detail="Invitation email mismatch")
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    role = (inv.role or "player").lower()
    if role not in ("player","guardian","trainer","admin"):
        raise HTTPException(status_code=400, detail="Invalid role in invitation")

    user = User(email=email, password_hash=hash_password(payload.password), role=role)
    db.add(user)
    db.flush()

    # Create guardian<->player link if relevant.
    if role == "guardian" and inv.related_player_email:
        db.add(GuardianLink(guardian_user_id=user.id, player_user_id=None, player_email=inv.related_player_email.lower()))
    if role == "player":
        # Resolve pending guardian links by email
        db.query(GuardianLink).filter(
            GuardianLink.player_user_id.is_(None),
            GuardianLink.player_email == email,
        ).update({GuardianLink.player_user_id: user.id})

    inv.used_at = now
    db.add(inv)

    db.commit()
    db.refresh(user)
    return TokenOut(access_token=create_access_token(user))

@router.post("/login", response_model=TokenOut)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form.username).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return TokenOut(access_token=create_access_token(user))
