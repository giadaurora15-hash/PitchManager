from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from ..db import get_db
from ..auth import get_current_user, require_roles
from .. import models, schemas

router = APIRouter(prefix="/teams", tags=["teams"])

def _ensure_team_edit_rights(db: Session, user: models.User, team_id: int):
    if user.role == "admin":
        return
    if user.role != "trainer":
        raise HTTPException(status_code=403, detail="Not allowed")
    tm = db.query(models.TeamMember).filter(
        models.TeamMember.team_id == team_id,
        models.TeamMember.user_id == user.id,
        models.TeamMember.role == "trainer",
    ).first()
    if not tm:
        raise HTTPException(status_code=403, detail="Trainer not assigned to this team")


@router.get("", response_model=List[schemas.TeamOut])
def list_teams(
    q: Optional[str] = Query(default=None, description="Search by team name"),
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    # All authenticated users can view teams
    query = db.query(models.Team)
    if user.role == "trainer":
        query = query.join(models.TeamMember, models.TeamMember.team_id == models.Team.id).filter(models.TeamMember.user_id == user.id)
    if q:
        query = query.filter(models.Team.name.ilike(f"%{q}%"))
    teams = query.order_by(models.Team.name.asc()).all()
    return teams


@router.post("", response_model=schemas.TeamOut)
def create_team(
    payload: schemas.TeamCreate,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    require_roles(user, "admin", "trainer")
    team = models.Team(
        name=payload.name.strip(),
        description=payload.description,
        is_active=True,
    )
    db.add(team)
    db.commit()
    db.refresh(team)

    # Optional trainer assignment
    if payload.trainer_user_ids:
        for uid in payload.trainer_user_ids:
            db.add(models.TeamMember(team_id=team.id, user_id=uid, role="trainer"))
        db.commit()

    return team


@router.get("/{team_id}", response_model=schemas.TeamDetailOut)
def get_team(
    team_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    team = db.query(models.Team).filter(models.Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")
    members = (
        db.query(models.TeamMember, models.User)
        .join(models.User, models.User.id == models.TeamMember.user_id)
        .filter(models.TeamMember.team_id == team_id)
        .all()
    )
    trainers = [schemas.TeamMemberUser(user_id=u.id, email=u.email, role=tm.role) for tm,u in members if tm.role=="trainer"]
    players = [schemas.TeamMemberUser(user_id=u.id, email=u.email, role=tm.role) for tm,u in members if tm.role!="trainer"]
    return schemas.TeamDetailOut(
        id=team.id,
        name=team.name,
        description=team.description,
        is_active=team.is_active,
        trainers=trainers,
        members=players,
    )


@router.post("/{team_id}/members", response_model=schemas.TeamDetailOut)
def add_members(
    team_id: int,
    payload: schemas.TeamMembersUpdate,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    require_roles(user, "admin", "trainer")
    team = db.query(models.Team).filter(models.Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")

    # upsert members
    existing = {
        tm.user_id: tm
        for tm in db.query(models.TeamMember).filter(models.TeamMember.team_id == team_id).all()
    }
    for m in payload.members:
        if m.user_id in existing:
            existing[m.user_id].role = m.role
        else:
            db.add(models.TeamMember(team_id=team_id, user_id=m.user_id, role=m.role))
    db.commit()
    return get_team(team_id, db, user)


@router.delete("/{team_id}/members/{user_id}", response_model=schemas.TeamDetailOut)
def remove_member(
    team_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    require_roles(user, "admin", "trainer")
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user_id)
        .first()
    )
    if tm:
        db.delete(tm)
        db.commit()
    return get_team(team_id, db, user)
