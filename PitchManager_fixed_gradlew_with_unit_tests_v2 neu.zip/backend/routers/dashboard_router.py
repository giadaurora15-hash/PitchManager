from __future__ import annotations

from datetime import datetime, date, time, timedelta, timezone
import asyncio
from fastapi import APIRouter, Depends, Query, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from ..db import get_db, SessionLocal
from ..auth import get_current_user
from .. import models

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _day_bounds_utc(d: date) -> tuple[datetime, datetime]:
    start = datetime.combine(d, time.min, tzinfo=timezone.utc)
    end = start + timedelta(days=1)
    return start, end


def _segment_bits(mask: int) -> list[int]:
    return [bit for bit in (1, 2, 4, 8) if mask & bit]


def active_bookings(db: Session) -> list[dict]:
    n = now_utc()
    bs = (
        db.query(models.Booking)
        .filter(
            models.Booking.status == "active",
            models.Booking.start_dt <= n,
            models.Booking.end_dt > n,
        )
        .all()
    )
    courts = {c.id: c.name for c in db.query(models.Court).all()}
    teams = {t.id: t.name for t in db.query(models.Team).all()} if hasattr(models, "Team") else {}
    out = []
    for b in bs:
        out.append(
            {
                "booking_id": b.id,
                "court_id": b.court_id,
                "court_name": courts.get(b.court_id, f"Platz {b.court_id}"),
                "type": b.booking_type,
                "segment_mask": b.segment_mask,
                "team_id": getattr(b, "team_id", None),
                "team_name": teams.get(getattr(b, "team_id", None)),
                "start_dt": b.start_dt.isoformat(),
                "end_dt": b.end_dt.isoformat(),
            }
        )
    return out


def courts_occupancy(db: Session, d: date) -> list[dict]:
    start, end = _day_bounds_utc(d)

    courts = db.query(models.Court).order_by(models.Court.name.asc()).all()
    teams = {t.id: t.name for t in db.query(models.Team).all()} if hasattr(models, "Team") else {}

    # all bookings intersecting the day
    bs = (
        db.query(models.Booking)
        .filter(
            models.Booking.status == "active",
            models.Booking.start_dt < end,
            models.Booking.end_dt > start,
        )
        .all()
    )

    # Aggregate per court per quarter
    by_court: dict[int, dict] = {}
    for c in courts:
        by_court[c.id] = {
            "court_id": c.id,
            "court_name": c.name,
            "mask": 0,
            "quarters": {1: {"label": None, "type": None, "count": 0}, 2: {"label": None, "type": None, "count": 0}, 4: {"label": None, "type": None, "count": 0}, 8: {"label": None, "type": None, "count": 0}},
        }

    for b in bs:
        entry = by_court.get(b.court_id)
        if not entry:
            continue
        bits = _segment_bits(b.segment_mask or 15)
        label = teams.get(getattr(b, "team_id", None)) or (b.booking_type or "gebucht")
        btype = b.booking_type or "booking"
        for bit in bits:
            entry["mask"] |= bit
            # keep first label; do not overwrite
            entry["quarters"][bit]["count"] += 1
            if entry["quarters"][bit]["label"] is None:
                entry["quarters"][bit]["label"] = label
                entry["quarters"][bit]["type"] = btype

    out = []
    for c in courts:
        entry = by_court[c.id]
        mask = entry["mask"]
        count = sum(1 for bit in (1, 2, 4, 8) if mask & bit)
        fraction = count / 4.0
        quarters = [
            {"bit": bit, "booked": bool(mask & bit), "label": entry["quarters"][bit]["label"], "type": entry["quarters"][bit]["type"], "conflict": entry["quarters"][bit]["count"] > 1}
            for bit in (1, 2, 4, 8)
        ]
        out.append(
            {
                "court_id": c.id,
                "court_name": c.name,
                "mask": mask,
                "booked_quarters": count,
                "fraction": fraction,
                "quarters": quarters,
            }
        )
    return out


@router.get("/live")
def live(
    day: str | None = Query(default=None, description="YYYY-MM-DD, default: today (UTC)"),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    d = date.fromisoformat(day) if day else now_utc().date()
    return {
        "server_time": now_utc().isoformat(),
        "active": active_bookings(db),
        "occupancy": courts_occupancy(db, d),
        "day": d.isoformat(),
    }


@router.websocket("/ws/live")
async def ws_live(websocket: WebSocket):
    # Websocket uses token query param like ?token=...
    token = websocket.query_params.get("token")
    if not token:
        await websocket.close(code=4401)
        return

    await websocket.accept()
    try:
        while True:
            db = SessionLocal()
            try:
                payload = {
                    "server_time": now_utc().isoformat(),
                    "active": active_bookings(db),
                    "occupancy": courts_occupancy(db, now_utc().date()),
                    "day": now_utc().date().isoformat(),
                }
            finally:
                db.close()
            await websocket.send_json(payload)
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        return
