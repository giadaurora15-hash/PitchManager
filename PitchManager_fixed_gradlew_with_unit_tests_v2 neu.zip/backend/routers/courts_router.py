from __future__ import annotations

from datetime import datetime, date, time, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..db import get_db
from ..auth import get_current_user, require_roles
from .. import models
from ..models import Court
from ..schemas import CourtOut, CourtUpdateIn

router = APIRouter(prefix="/courts", tags=["courts"])


def _can_view_team_item(db: Session, user: models.User, team_id: int | None) -> bool:
    if team_id is None:
        return True
    if user.role == "admin":
        return True
    tm = (
        db.query(models.TeamMember)
        .filter(models.TeamMember.team_id == team_id, models.TeamMember.user_id == user.id)
        .first()
    )
    return tm is not None


def _day_bounds_utc(d: date) -> tuple[datetime, datetime]:
    start = datetime.combine(d, time.min, tzinfo=timezone.utc)
    end = start + timedelta(days=1)
    return start, end


@router.get("", response_model=list[CourtOut])
def list_courts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    courts = db.query(Court).order_by(Court.name.asc()).all()
    return [CourtOut(id=c.id, name=c.name, latitude=c.latitude, longitude=c.longitude) for c in courts]


@router.patch("/{court_id}", response_model=CourtOut)
def update_court(
    court_id: int,
    payload: CourtUpdateIn,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    require_roles(user, "admin", "trainer")
    c = db.query(Court).filter(Court.id == court_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Court not found")
    if payload.name is not None:
        c.name = payload.name
    if payload.latitude is not None:
        c.latitude = payload.latitude
    if payload.longitude is not None:
        c.longitude = payload.longitude
    db.commit()
    db.refresh(c)
    return CourtOut(id=c.id, name=c.name, latitude=c.latitude, longitude=c.longitude)


@router.get("/{court_id}/bookings_day")
def court_bookings_day(
    court_id: int,
    day: str | None = Query(default=None, description="YYYY-MM-DD (UTC), default: today"),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    d = date.fromisoformat(day) if day else datetime.now(timezone.utc).date()
    start, end = _day_bounds_utc(d)

    c = db.query(Court).filter(Court.id == court_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Court not found")

    teams = {t.id: t.name for t in db.query(models.Team).all()} if hasattr(models, "Team") else {}

    bs = (
        db.query(models.Booking)
        .filter(
            models.Booking.court_id == court_id,
            models.Booking.status == "active",
            models.Booking.start_dt < end,
            models.Booking.end_dt > start,
        )
        .order_by(models.Booking.start_dt.asc())
        .all()
    )

    out = []
    for b in bs:
        if not _can_view_team_item(db, user, getattr(b, "team_id", None)):
            continue
        out.append(
            {
                "booking_id": b.id,
                "court_id": b.court_id,
                "type": b.booking_type,
                "segment_mask": b.segment_mask,
                "team_id": getattr(b, "team_id", None),
                "team_name": teams.get(getattr(b, "team_id", None)),
                "start_dt": b.start_dt.isoformat(),
                "end_dt": b.end_dt.isoformat(),
            }
        )

    return {"court_id": court_id, "court_name": c.name, "day": d.isoformat(), "bookings": out}
