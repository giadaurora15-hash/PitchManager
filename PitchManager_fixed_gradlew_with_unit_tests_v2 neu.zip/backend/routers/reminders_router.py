from __future__ import annotations

from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..db import get_db
from ..auth import get_current_user, require_roles
from .. import models
from ..services.emailer import send_email

router = APIRouter(prefix="/automation", tags=["automation"])


@router.post("/send_reminders")
def send_reminders(
    hours_before: int = 24,
    window_minutes: int = 30,
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    """Send automatic reminders for events starting ~hours_before from now.

    - Admin can trigger for all events.
    - Trainer can trigger only for teams they train (team_id set) or their own events.
    """
    require_roles(user, "admin", "trainer")

    now = datetime.now(timezone.utc)
    target = now + timedelta(hours=hours_before)
    start_min = target - timedelta(minutes=window_minutes)
    start_max = target + timedelta(minutes=window_minutes)

    q = db.query(models.Event).filter(models.Event.start_dt >= start_min, models.Event.start_dt <= start_max)

    if user.role == "trainer":
        # only events for teams the trainer is assigned to OR events created by trainer (if model has creator_user_id)
        trainer_team_ids = [
            tm.team_id for tm in db.query(models.TeamMember)
            .filter(models.TeamMember.user_id == user.id, models.TeamMember.role == "trainer")
            .all()
        ]
        if trainer_team_ids:
            q = q.filter((models.Event.team_id == None) | (models.Event.team_id.in_(trainer_team_ids)))  # noqa: E711
        else:
            q = q.filter(models.Event.team_id == None)  # noqa: E711

    events = q.order_by(models.Event.start_dt.asc()).all()

    sent = 0
    failed = 0
    details = []

    for ev in events:
        parts = db.query(models.EventParticipant).filter(models.EventParticipant.event_id == ev.id).all()
        recipients = [p.email for p in parts if p.email and p.status in ("invited", "accepted")]

        # If no explicit participants but team_id set, remind whole team members
        if not recipients and ev.team_id:
            members = (
                db.query(models.TeamMember, models.User)
                .join(models.User, models.User.id == models.TeamMember.user_id)
                .filter(models.TeamMember.team_id == ev.team_id)
                .all()
            )
            recipients = [u.email for tm, u in members if u.email]

        subj = f"Erinnerung: {ev.title} in {hours_before}h"
        when = ev.start_dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        body = f"""Hallo,

Erinnerung: {ev.title}
Wann: {when}
Ort: {ev.location or '-'}
Bitte prüfe deine Teilnahme in der App.

Viele Grüße
PitchManager
"""

        for email in set(recipients):
            try:
                send_email(email, subj, body)
                sent += 1
            except Exception as e:
                failed += 1
                details.append({"event_id": ev.id, "email": email, "error": str(e)})

    return {"events": len(events), "sent": sent, "failed": failed, "errors": details[:50]}
