from __future__ import annotations

from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from slowapi import Limiter
from slowapi.util import get_remote_address

from ..auth import get_current_user
from ..db import get_db
from ..models import Court
from ..schemas import WeatherOut

router = APIRouter(prefix="/weather", tags=["weather"])

limiter = Limiter(key_func=get_remote_address)

# Simple in-memory cache for provider responses (5 minutes)
_CACHE: dict[str, tuple[float, dict]] = {}
_CACHE_TTL_SECONDS = 300

# Open-Meteo weather codes (WMO interpretation) -> short German labels
# Docs: https://open-meteo.com/en/docs  (weather_code)
_CODE_DE: dict[int, str] = {
    0: "Klar",
    1: "Überwiegend klar",
    2: "Teilweise bewölkt",
    3: "Bewölkt",
    45: "Nebel",
    48: "Reif-Nebel",
    51: "Leichter Niesel",
    53: "Niesel",
    55: "Starker Niesel",
    56: "Leichter gefrierender Niesel",
    57: "Gefrierender Niesel",
    61: "Leichter Regen",
    63: "Regen",
    65: "Starker Regen",
    66: "Leichter gefrierender Regen",
    67: "Gefrierender Regen",
    71: "Leichter Schneefall",
    73: "Schneefall",
    75: "Starker Schneefall",
    77: "Schneekörner",
    80: "Leichte Schauer",
    81: "Schauer",
    82: "Starke Schauer",
    85: "Leichte Schneeschauer",
    86: "Starke Schneeschauer",
    95: "Gewitter",
    96: "Gewitter (Hagel)",
    99: "Gewitter (starker Hagel)",
}


def _code_to_de(code: int | None) -> str | None:
    if code is None:
        return None
    return _CODE_DE.get(int(code), "Wetter")


def _warnings_for(
    weather_code: int | None,
    precip_prob: int | None,
    precip_mm: float | None,
    wind_gust_kph: float | None,
) -> list[str]:
    warnings: list[str] = []
    # Thunderstorm codes in Open-Meteo docs
    if weather_code in (95, 96, 99):
        warnings.append("Gewitter")
    # Simple “heavy rain” heuristic
    if precip_prob is not None and precip_prob >= 70 and (precip_mm is None or precip_mm >= 2.0):
        warnings.append("Starkregen möglich")
    # Wind gust threshold (kph)
    if wind_gust_kph is not None and wind_gust_kph >= 50:
        warnings.append("Starker Wind")
    return warnings


def _resolve_coords(db: Session, court_id: int | None, lat: float | None, lon: float | None) -> tuple[float, float]:
    if lat is not None and lon is not None:
        return float(lat), float(lon)

    if court_id is None:
        raise HTTPException(status_code=400, detail="Provide lat/lon or court_id")

    court = db.query(Court).filter(Court.id == court_id).first()
    if not court:
        raise HTTPException(status_code=404, detail="Court not found")
    if court.latitude is None or court.longitude is None:
        raise HTTPException(status_code=400, detail="Court has no latitude/longitude set")

    return float(court.latitude), float(court.longitude)


async def _fetch_open_meteo(lat: float, lon: float) -> dict:
    # Cache by rounded coords to reduce provider calls.
    key = f"{lat:.3f},{lon:.3f}"
    now = datetime.now(timezone.utc).timestamp()
    hit = _CACHE.get(key)
    if hit and (now - hit[0]) < _CACHE_TTL_SECONDS:
        return hit[1]

    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "timezone": "UTC",
        "windspeed_unit": "kmh",
        "current": "temperature_2m,precipitation,weather_code,wind_speed_10m,wind_gusts_10m",
        "hourly": "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m",
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            data = r.json()
    except httpx.HTTPError as e:
        # Convert provider/network errors into a stable upstream error for callers.
        raise HTTPException(status_code=502, detail="Weather provider unreachable") from e
    _CACHE[key] = (now, data)
    return data


def _nearest_hour_index(times: list[str], target_utc: datetime) -> int:
    # Open-Meteo hourly timestamps are ISO8601 strings in UTC like "2025-12-29T13:00"
    # We'll pick the closest hour (by absolute delta).
    best_i = 0
    best_delta = None
    for i, t in enumerate(times):
        try:
            dt = datetime.fromisoformat(t).replace(tzinfo=timezone.utc)
        except Exception:
            continue
        delta = abs((dt - target_utc).total_seconds())
        if best_delta is None or delta < best_delta:
            best_delta = delta
            best_i = i
    return best_i


@router.get("/current", response_model=WeatherOut)
@limiter.limit("30/minute")
async def current_weather(
    request: Request,
    court_id: int | None = Query(None, ge=1),
    lat: float | None = Query(None, ge=-90, le=90),
    lon: float | None = Query(None, ge=-180, le=180),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    lat_v, lon_v = _resolve_coords(db, court_id, lat, lon)

    data = await _fetch_open_meteo(lat_v, lon_v)
    cur = data.get("current") or {}

    code = cur.get("weather_code")
    temp = cur.get("temperature_2m")
    precip_mm = cur.get("precipitation")
    wind = cur.get("wind_speed_10m")
    wind_gust = cur.get("wind_gusts_10m")

    summary = _code_to_de(code)
    warnings = _warnings_for(code, None, precip_mm, wind_gust)

    return WeatherOut(
        latitude=lat_v,
        longitude=lon_v,
        time_utc=datetime.now(timezone.utc),
        temperature_c=temp,
        precipitation_mm=precip_mm,
        precipitation_probability=None,
        wind_kph=wind,
        wind_gust_kph=wind_gust,
        weather_code=code,
        summary_de=summary,
        warnings=warnings,
    )


@router.get("/at_time", response_model=WeatherOut)
@limiter.limit("30/minute")
async def weather_at_time(
    request: Request,
    court_id: int | None = Query(None, ge=1),
    lat: float | None = Query(None, ge=-90, le=90),
    lon: float | None = Query(None, ge=-180, le=180),
    time_utc: datetime = Query(..., description="ISO8601 datetime with timezone (UTC recommended)"),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    if time_utc.tzinfo is None or time_utc.utcoffset() is None:
        raise HTTPException(status_code=400, detail="time_utc must include timezone")
    time_utc = time_utc.astimezone(timezone.utc)

    lat_v, lon_v = _resolve_coords(db, court_id, lat, lon)

    data = await _fetch_open_meteo(lat_v, lon_v)
    hourly = data.get("hourly") or {}
    times = hourly.get("time") or []
    if not times:
        raise HTTPException(status_code=502, detail="Weather provider returned no hourly data")

    i = _nearest_hour_index(times, time_utc)

    temp = (hourly.get("temperature_2m") or [None])[i]
    precip_prob = (hourly.get("precipitation_probability") or [None])[i]
    precip_mm = (hourly.get("precipitation") or [None])[i]
    wind = (hourly.get("wind_speed_10m") or [None])[i]
    wind_gust = (hourly.get("wind_gusts_10m") or [None])[i]
    code = (hourly.get("weather_code") or [None])[i]

    summary = _code_to_de(code)
    warnings = _warnings_for(code, precip_prob, precip_mm, wind_gust)

    return WeatherOut(
        latitude=lat_v,
        longitude=lon_v,
        time_utc=time_utc,
        temperature_c=temp,
        precipitation_mm=precip_mm,
        precipitation_probability=precip_prob,
        wind_kph=wind,
        wind_gust_kph=wind_gust,
        weather_code=code,
        summary_de=summary,
        warnings=warnings,
    )
