from __future__ import annotations
AGE_RANK = {"F":1, "E":2, "D":3, "C":4, "B":5, "A":6, "S":7, "SENIOREN":7}

def age_rank(age_group: str | None) -> int:
    if not age_group:
        return 0
    return AGE_RANK.get(age_group.strip().upper(), 0)

def parse_types(csv: str) -> set[str]:
    return {t.strip().lower() for t in (csv or "").split(",") if t.strip()}

def should_force_full_field(booking_type: str, age_group: str | None, min_age: str, types_csv: str) -> bool:
    if booking_type.lower() not in parse_types(types_csv):
        return False
    return age_rank(age_group) >= age_rank(min_age)
