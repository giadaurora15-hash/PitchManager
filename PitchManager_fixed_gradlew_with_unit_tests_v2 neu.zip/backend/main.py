from __future__ import annotations

import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from slowapi.middleware import SlowAPIMiddleware
from fastapi.responses import JSONResponse
from fastapi import Request

from .core.config import get_settings
from .db import get_engine, Base, SessionLocal
from .models import Court, Rules

from .routers.auth_router import router as auth_router
from .routers.clubs_router import router as clubs_router
from .routers.rules_router import router as rules_router
from .routers.bookings_router import router as bookings_router
from .routers.dashboard_router import router as dashboard_router
from .routers.courts_router import router as courts_router
from .routers.weather_router import router as weather_router
from .routers.events_router import router as events_router
from .routers.invites_router import router as invites_router
from .routers.reminders_router import router as reminders_router
from .routers.teams_router import router as teams_router


settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup/shutdown.

    FastAPI's `@app.on_event` is deprecated; lifespan is the recommended API.
    """

    # For production: prefer running Alembic migrations in the entrypoint.
    # For development / SQLite: allow auto-create tables.
    if settings.auto_create_db:
        Base.metadata.create_all(bind=get_engine())
    if settings.seed_demo_data:
        db = SessionLocal()
        try:
            _seed(db)
        finally:
            db.close()

    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)

# ---- Rate limiting ----
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.rate_limit_default])
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)


@app.exception_handler(RateLimitExceeded)
def _rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(status_code=429, content={"detail": "Rate limit exceeded"})


# ---- CORS ----
origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
allow_all = len(origins) == 0
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else origins,
    allow_credentials=False if allow_all else True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


# ---- Static uploads ----
UPLOAD_DIR = settings.upload_dir
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.get("/health")
@limiter.limit("30/minute")
def health(request: Request):
    return {"status": "ok"}


def _seed(db: Session):
    # Idempotent demo data for local development.
    if db.query(Court).count() == 0:
        # Default coords: Berlin (can be changed via /courts admin endpoint)
        db.add_all(
            [
                Court(name="Platz 1", latitude=52.5200, longitude=13.4050),
                Court(name="Platz 2", latitude=52.5200, longitude=13.4050),
                Court(name="Platz 3", latitude=52.5200, longitude=13.4050),
            ]
        )
    if db.query(Rules).count() == 0:
        db.add(
            Rules(
                full_field_min_age_group="C",
                full_field_types="spieltag,turnier",
                allow_override_for_admin=True,
                allow_override_for_trainer=False,
            )
        )
    db.commit()


app.include_router(auth_router)
app.include_router(clubs_router)
app.include_router(rules_router)
app.include_router(bookings_router)
app.include_router(dashboard_router)
app.include_router(courts_router)
app.include_router(weather_router)
app.include_router(events_router)
app.include_router(invites_router)
app.include_router(teams_router)
app.include_router(reminders_router)