"""invitations and roles

Revision ID: 0005_invitations_and_roles
Revises: 0004_events_and_participants
Create Date: 2025-12-30
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "0005_invitations_and_roles"
down_revision = "0004_events_and_participants"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "invitations",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=32), nullable=False),
        sa.Column("token", sa.String(length=64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("used", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("revoked", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.create_index("ix_invitations_token", "invitations", ["token"], unique=True)
    op.create_index("ix_invitations_email", "invitations", ["email"], unique=False)

    op.create_table(
        "guardian_links",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("guardian_user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("player_user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=True),
        sa.Column("player_email", sa.String(length=255), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_guardian_links_guardian", "guardian_links", ["guardian_user_id"])
    op.create_index("ix_guardian_links_player", "guardian_links", ["player_user_id"])
    op.create_index("ix_guardian_links_player_email", "guardian_links", ["player_email"])
    # SQLite-safe unique constraint
    with op.batch_alter_table("guardian_links") as batch:
        batch.create_unique_constraint(
            "uq_guardian_player", ["guardian_user_id", "player_user_id"]
        )


def downgrade() -> None:
    with op.batch_alter_table("guardian_links") as batch:
        batch.drop_constraint("uq_guardian_player", type_="unique")
    op.drop_index("ix_guardian_links_player_email", table_name="guardian_links")
    op.drop_index("ix_guardian_links_player", table_name="guardian_links")
    op.drop_index("ix_guardian_links_guardian", table_name="guardian_links")
    op.drop_table("guardian_links")

    op.drop_index("ix_invitations_email", table_name="invitations")
    op.drop_index("ix_invitations_token", table_name="invitations")
    op.drop_table("invitations")
