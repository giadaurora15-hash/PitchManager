"""initial schema

Revision ID: 0001_initial
Revises: 
Create Date: 2025-12-28
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # users
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=20), nullable=False, server_default="user"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    # clubs
    op.create_table(
        "clubs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=200), nullable=False),
        sa.Column("logo_path", sa.String(length=500), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_clubs_name", "clubs", ["name"], unique=True)

    # courts
    op.create_table(
        "courts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.UniqueConstraint("name", name="uq_courts_name"),
    )

    # rules
    op.create_table(
        "rules",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("full_field_min_age_group", sa.String(length=10), nullable=False, server_default="C"),
        sa.Column("full_field_types", sa.String(length=200), nullable=False, server_default="spieltag,turnier"),
        sa.Column("allow_override_for_admin", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("allow_override_for_trainer", sa.Boolean(), nullable=False, server_default=sa.false()),
    )

    # booking_series
    op.create_table(
        "booking_series",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("booking_type", sa.String(length=20), nullable=False),
        sa.Column("court_id", sa.Integer(), sa.ForeignKey("courts.id"), nullable=False),
        sa.Column("start_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("end_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("rrule", sa.Text(), nullable=False),
        sa.Column("age_group", sa.String(length=10), nullable=True),
        sa.Column("club_id", sa.Integer(), sa.ForeignKey("clubs.id"), nullable=True),
        sa.Column("opponent_club_id", sa.Integer(), sa.ForeignKey("clubs.id"), nullable=True),
        sa.Column("segment_mask", sa.Integer(), nullable=False, server_default="15"),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
    )

    # bookings
    op.create_table(
        "bookings",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("booking_type", sa.String(length=20), nullable=False),
        sa.Column("court_id", sa.Integer(), sa.ForeignKey("courts.id"), nullable=False),
        sa.Column("start_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("end_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("segment_mask", sa.Integer(), nullable=False, server_default="15"),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="active"),
        sa.Column("age_group", sa.String(length=10), nullable=True),
        sa.Column("club_id", sa.Integer(), sa.ForeignKey("clubs.id"), nullable=True),
        sa.Column("opponent_club_id", sa.Integer(), sa.ForeignKey("clubs.id"), nullable=True),
        sa.Column("weather_snapshot", sa.Text(), nullable=True),
        sa.Column("series_id", sa.Integer(), sa.ForeignKey("booking_series.id"), nullable=True),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("court_id", "start_dt", "end_dt", "segment_mask", name="uq_booking_exact"),
    )
    op.create_index("ix_bookings_start_dt", "bookings", ["start_dt"], unique=False)
    op.create_index("ix_bookings_end_dt", "bookings", ["end_dt"], unique=False)
    op.create_index("ix_bookings_court_start", "bookings", ["court_id", "start_dt"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_bookings_court_start", table_name="bookings")
    op.drop_index("ix_bookings_end_dt", table_name="bookings")
    op.drop_index("ix_bookings_start_dt", table_name="bookings")
    op.drop_table("bookings")
    op.drop_table("booking_series")
    op.drop_table("rules")
    op.drop_table("courts")
    op.drop_index("ix_clubs_name", table_name="clubs")
    op.drop_table("clubs")
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")
