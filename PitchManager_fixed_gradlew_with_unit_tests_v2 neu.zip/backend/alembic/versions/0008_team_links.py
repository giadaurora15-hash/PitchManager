"""link events/bookings to teams

Revision ID: 0008_team_links
Revises: 0007_teams_groups
Create Date: 2026-01-01
"""

from alembic import op
import sqlalchemy as sa


revision = "0008_team_links"
down_revision = "0007_teams_groups"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("bookings") as batch:
        batch.add_column(sa.Column("team_id", sa.Integer(), sa.ForeignKey("teams.id", ondelete="SET NULL"), nullable=True))
        batch.create_index("ix_bookings_team_id", ["team_id"], unique=False)

    with op.batch_alter_table("events") as batch:
        batch.add_column(sa.Column("team_id", sa.Integer(), sa.ForeignKey("teams.id", ondelete="SET NULL"), nullable=True))
        batch.create_index("ix_events_team_id", ["team_id"], unique=False)


def downgrade():
    with op.batch_alter_table("events") as batch:
        batch.drop_index("ix_events_team_id")
        batch.drop_column("team_id")

    with op.batch_alter_table("bookings") as batch:
        batch.drop_index("ix_bookings_team_id")
        batch.drop_column("team_id")
