"""events and participants

Revision ID: 0004_events_and_participants
Revises: 0003_booking_weather_location
Create Date: 2025-12-30
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "0004_events_and_participants"
down_revision = "0003_booking_weather_location"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("event_type", sa.String(length=30), nullable=False, server_default="event"),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("court_id", sa.Integer(), sa.ForeignKey("courts.id"), nullable=True),
        sa.Column("location_label", sa.String(length=200), nullable=True),
        sa.Column("start_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("end_dt", sa.DateTime(timezone=True), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=True),
        sa.Column("is_public", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("weather_lat", sa.Float(), nullable=True),
        sa.Column("weather_lon", sa.Float(), nullable=True),
        sa.Column("weather_location_label", sa.String(length=200), nullable=True),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )
    op.create_index("ix_events_start", "events", ["start_dt"])

    op.create_table(
        "event_participants",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("event_id", sa.Integer(), sa.ForeignKey("events.id"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="invited"),
        sa.Column("responded_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("invite_token", sa.String(length=64), nullable=False),
        sa.Column("invited_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
        sa.UniqueConstraint("event_id", "email", name="uq_event_email"),
        sa.UniqueConstraint("invite_token", name="uq_event_invite_token"),
    )
    op.create_index("ix_event_participants_event", "event_participants", ["event_id"])
    op.create_index("ix_event_participants_email", "event_participants", ["email"])
    op.create_index("ix_event_participants_event_status", "event_participants", ["event_id", "status"])


def downgrade() -> None:
    op.drop_index("ix_event_participants_event_status", table_name="event_participants")
    op.drop_index("ix_event_participants_email", table_name="event_participants")
    op.drop_index("ix_event_participants_event", table_name="event_participants")
    op.drop_table("event_participants")
    op.drop_index("ix_events_start", table_name="events")
    op.drop_table("events")
