"""Add booking weather location columns

Revision ID: 0003_booking_weather_location
Revises: 0002_courts_geo
Create Date: 2025-12-28

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0003_booking_weather_location'
down_revision = '0002_courts_geo'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('bookings') as batch_op:
        batch_op.add_column(sa.Column('weather_lat', sa.Float(), nullable=True))
        batch_op.add_column(sa.Column('weather_lon', sa.Float(), nullable=True))
        batch_op.add_column(sa.Column('weather_location_label', sa.String(length=200), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table('bookings') as batch_op:
        batch_op.drop_column('weather_location_label')
        batch_op.drop_column('weather_lon')
        batch_op.drop_column('weather_lat')
