"""teams and groups

Revision ID: 0007_teams_groups
Revises: 0006_audit_revokes_waitlist
Create Date: 2026-01-01
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "0007_teams_groups"
down_revision = "0006_audit_revokes_waitlist"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "teams",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_teams_name", "teams", ["name"], unique=True)

    op.create_table(
        "team_members",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("team_id", sa.Integer(), sa.ForeignKey("teams.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("role", sa.String(length=32), nullable=False, server_default="member"),
    )
    op.create_index("ix_team_members_team_id", "team_members", ["team_id"], unique=False)
    op.create_index("ix_team_members_user_id", "team_members", ["user_id"], unique=False)
    op.create_unique_constraint("uq_team_user", "team_members", ["team_id", "user_id"])
    op.create_index("ix_team_members_team_role", "team_members", ["team_id", "role"], unique=False)


def downgrade():
    # SQLite-safe: use batch_alter_table for dropping constraints
    with op.batch_alter_table("team_members") as batch:
        batch.drop_constraint("uq_team_user", type_="unique")
    op.drop_index("ix_team_members_team_role", table_name="team_members")
    op.drop_index("ix_team_members_user_id", table_name="team_members")
    op.drop_index("ix_team_members_team_id", table_name="team_members")
    op.drop_table("team_members")

    op.drop_index("ix_teams_name", table_name="teams")
    op.drop_table("teams")
