"""add geo coordinates to courts

Revision ID: 0002_courts_geo
Revises: 0001_initial
Create Date: 2025-12-28
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "0002_courts_geo"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("courts", sa.Column("latitude", sa.Float(), nullable=True))
    op.add_column("courts", sa.Column("longitude", sa.Float(), nullable=True))


def downgrade() -> None:
    op.drop_column("courts", "longitude")
    op.drop_column("courts", "latitude")
