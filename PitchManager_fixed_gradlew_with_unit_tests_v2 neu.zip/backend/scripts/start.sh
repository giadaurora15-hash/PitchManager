#!/usr/bin/env bash
set -euo pipefail

cd /app

AUTO_MIGRATE="${AUTO_MIGRATE:-true}"

if [[ "$AUTO_MIGRATE" == "true" ]]; then
  echo "[startup] running migrations"
  alembic -c backend/alembic.ini upgrade head
fi

exec uvicorn backend.main:app --host 0.0.0.0 --port "${PORT:-8000}"
