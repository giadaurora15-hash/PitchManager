from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import String, Integer, DateTime, ForeignKey, Boolean, Text, UniqueConstraint, Index, Float
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

import uuid

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="user")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Club(Base):
    __tablename__ = "clubs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    logo_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Court(Base):
    __tablename__ = "courts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    # Optional geo coordinates for live weather (WGS84).
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)

class Rules(Base):
    __tablename__ = "rules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    full_field_min_age_group: Mapped[str] = mapped_column(String(10), default="C")
    full_field_types: Mapped[str] = mapped_column(String(200), default="spieltag,turnier")
    allow_override_for_admin: Mapped[bool] = mapped_column(Boolean, default=True)
    allow_override_for_trainer: Mapped[bool] = mapped_column(Boolean, default=False)

class BookingSeries(Base):
    __tablename__ = "booking_series"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    booking_type: Mapped[str] = mapped_column(String(20))
    court_id: Mapped[int] = mapped_column(ForeignKey("courts.id"))
    start_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    rrule: Mapped[str] = mapped_column(Text)
    age_group: Mapped[str | None] = mapped_column(String(10), nullable=True)
    club_id: Mapped[int | None] = mapped_column(ForeignKey("clubs.id"), nullable=True)
    opponent_club_id: Mapped[int | None] = mapped_column(ForeignKey("clubs.id"), nullable=True)
    segment_mask: Mapped[int] = mapped_column(Integer, default=15)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))

class Booking(Base):
    __tablename__ = "bookings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    booking_type: Mapped[str] = mapped_column(String(20))
    court_id: Mapped[int] = mapped_column(ForeignKey("courts.id"))
    start_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    end_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    segment_mask: Mapped[int] = mapped_column(Integer, default=15)
    status: Mapped[str] = mapped_column(String(20), default="active")
    age_group: Mapped[str | None] = mapped_column(String(10), nullable=True)
    club_id: Mapped[int | None] = mapped_column(ForeignKey("clubs.id"), nullable=True)
    opponent_club_id: Mapped[int | None] = mapped_column(ForeignKey("clubs.id"), nullable=True)
    weather_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    weather_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    weather_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    weather_location_label: Mapped[str | None] = mapped_column(String(200), nullable=True)
    series_id: Mapped[int | None] = mapped_column(ForeignKey("booking_series.id"), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    team_id: Mapped[int | None] = mapped_column(ForeignKey("teams.id", ondelete="SET NULL"), nullable=True, index=True)
    __table_args__ = (
        UniqueConstraint("court_id", "start_dt", "end_dt", "segment_mask", name="uq_booking_exact"),
        Index("ix_bookings_court_start", "court_id", "start_dt"),
    )


class Event(Base):
    """Vereinsveranstaltung (Training, Spieltag, Turnier, Event, Versammlung, etc.)."""

    __tablename__ = "events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    event_type: Mapped[str] = mapped_column(String(30), default="event")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    court_id: Mapped[int | None] = mapped_column(ForeignKey("courts.id"), nullable=True)
    location_label: Mapped[str | None] = mapped_column(String(200), nullable=True)

    start_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    end_dt: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)

    capacity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    is_public: Mapped[bool] = mapped_column(Boolean, default=False)

    # Weather location snapshot (from device GPS at creation time)
    weather_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    weather_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    weather_location_label: Mapped[str | None] = mapped_column(String(200), nullable=True)

    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_events_start", "start_dt"),
    )


class EventParticipant(Base):
    """Teilnehmer/Einladung für ein Event."""

    __tablename__ = "event_participants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), index=True)

    # Optional reference to a user account; invitations can be email-only.
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    email: Mapped[str] = mapped_column(String(320), index=True)

    status: Mapped[str] = mapped_column(String(20), default="invited")  # invited|accepted|declined|waitlist|revoked
    responded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    invite_token: Mapped[str] = mapped_column(String(64), unique=True, index=True, default=lambda: uuid.uuid4().hex)
    invited_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("event_id", "email", name="uq_event_email"),
        Index("ix_event_participants_event_status", "event_id", "status"),
    )


class Invitation(Base):
    __tablename__ = "invitations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    email: Mapped[str | None] = mapped_column(String(320), nullable=True, index=True)
    role: Mapped[str] = mapped_column(String(20))
    related_player_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class GuardianLink(Base):
    __tablename__ = "guardian_links"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    guardian_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    player_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    player_email: Mapped[str | None] = mapped_column(String(320), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        UniqueConstraint("guardian_user_id", "player_user_id", name="uq_guardian_player"),
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity_type: Mapped[str] = mapped_column(String(60), index=True)
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    payload_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)

class Team(Base):
    __tablename__ = "teams"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False, unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class TeamMember(Base):
    __tablename__ = "team_members"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    role: Mapped[str] = mapped_column(String(32), nullable=False, default="member")  # member|trainer|guardian

    __table_args__ = (
        UniqueConstraint("team_id", "user_id", name="uq_team_user"),
        Index("ix_team_members_team_role", "team_id", "role"),
    )