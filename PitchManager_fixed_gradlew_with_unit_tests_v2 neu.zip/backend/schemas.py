from __future__ import annotations
from datetime import datetime, timezone
from pydantic import BaseModel, EmailStr, Field
from pydantic import ConfigDict
from pydantic import field_validator, model_validator
from typing import Literal

class RegisterIn(BaseModel):
    """Bootstrap registration.

    Only allowed when no users exist yet (first admin account).
    """
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = Field(default="admin")

class RegisterWithInviteIn(BaseModel):
    token: str = Field(min_length=10, max_length=128)
    email: EmailStr
    password: str = Field(min_length=6)
    full_name: str | None = Field(default=None, max_length=120)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class InviteCreateIn(BaseModel):
    role: Literal["player","guardian","trainer","admin"]
    emails: list[EmailStr] = Field(min_length=1)
    related_player_email: EmailStr | None = None
    expires_in_days: int = Field(default=14, ge=1, le=365)

class InviteOut(BaseModel):
    token: str
    role: str
    email: EmailStr | None = None
    related_player_email: EmailStr | None = None
    expires_at: datetime | None = None
    used_at: datetime | None = None
    revoked_at: datetime | None = None
    link: str

class ClubOut(BaseModel):
    id: int
    name: str
    logo_url: str | None = None

class ClubIn(BaseModel):
    name: str


class CourtOut(BaseModel):
    id: int
    name: str
    latitude: float | None = None
    longitude: float | None = None


class CourtUpdateIn(BaseModel):
    name: str | None = None
    latitude: float | None = None
    longitude: float | None = None

class RulesOut(BaseModel):
    full_field_min_age_group: str
    full_field_types: list[str]
    allow_override_for_admin: bool
    allow_override_for_trainer: bool

class RulesIn(BaseModel):
    full_field_min_age_group: str = "C"
    full_field_types: list[str] = ["spieltag","turnier"]
    allow_override_for_admin: bool = True
    allow_override_for_trainer: bool = False

class BookingIn(BaseModel):
    team_id: int | None = None
    booking_type: str
    court_id: int
    start_dt: datetime
    end_dt: datetime
    segment_mask: int = 15
    age_group: str | None = None
    club_id: int | None = None
    opponent_club_id: int | None = None
    weather_snapshot: str | None = None
    weather_lat: float | None = None
    weather_lon: float | None = None
    weather_location_label: str | None = None
    override_full_field_rule: bool = False

    @model_validator(mode="before")
    @classmethod
    def _validate_same_local_day(cls, data):
        """Reject bookings that span multiple *local* calendar days.

        The API receives timezone-aware datetimes. Even if we normalize to UTC
        internally, we still want to block requests that cross midnight in the
        user's provided timezone (e.g. 23:30+01:00 -> 00:30+01:00).
        """
        try:
            start = data.get("start_dt")
            end = data.get("end_dt")
        except AttributeError:
            return data
        if start is not None and end is not None:
            # Only enforce when both are datetime-like.
            try:
                if start.date() != end.date():
                    raise ValueError("Bookings must not span multiple days")
            except (AttributeError, TypeError):
                # Let field validation handle type / timezone errors.
                pass
        return data

    @field_validator("start_dt", "end_dt")
    @classmethod
    def _require_tz(cls, v: datetime) -> datetime:
        # Require timezone-aware datetimes to avoid DST/timezone bugs.
        if v.tzinfo is None or v.utcoffset() is None:
            raise ValueError("start_dt/end_dt must include a timezone offset (e.g. 2025-01-01T18:00:00+01:00)")
        return v.astimezone(timezone.utc)

    @model_validator(mode="after")
    def _validate_range(self):
        if self.end_dt <= self.start_dt:
            raise ValueError("end_dt must be after start_dt")
        if not (1 <= self.segment_mask <= 15):
            raise ValueError("segment_mask must be 1..15")
        return self


class BookingUpdateIn(BaseModel):
    court_id: int | None = None
    start_dt: datetime | None = None
    end_dt: datetime | None = None
    segment_mask: int | None = None

class BookingOut(BaseModel):
    team_id: int | None = None
    id: int
    booking_type: str
    court_id: int
    start_dt: datetime
    end_dt: datetime
    segment_mask: int
    status: str
    age_group: str | None = None
    club_id: int | None = None
    opponent_club_id: int | None = None
    weather_lat: float | None = None
    weather_lon: float | None = None
    weather_location_label: str | None = None
    series_id: int | None = None

class SeriesIn(BaseModel):
    team_id: int | None = None
    title: str
    booking_type: str
    court_id: int
    start_dt: datetime
    end_dt: datetime
    rrule: str
    age_group: str | None = None
    club_id: int | None = None
    opponent_club_id: int | None = None
    segment_mask: int = 15
    override_full_field_rule: bool = False

    @model_validator(mode="before")
    @classmethod
    def _validate_same_local_day(cls, data):
        try:
            start = data.get("start_dt")
            end = data.get("end_dt")
        except AttributeError:
            return data
        if start is not None and end is not None:
            try:
                if start.date() != end.date():
                    raise ValueError("Series instances must not span multiple days")
            except (AttributeError, TypeError):
                pass
        return data

    @field_validator("start_dt", "end_dt")
    @classmethod
    def _require_tz(cls, v: datetime) -> datetime:
        if v.tzinfo is None or v.utcoffset() is None:
            raise ValueError("start_dt/end_dt must include a timezone offset")
        return v.astimezone(timezone.utc)

    @model_validator(mode="after")
    def _validate_range(self):
        if self.end_dt <= self.start_dt:
            raise ValueError("end_dt must be after start_dt")
        if not (1 <= self.segment_mask <= 15):
            raise ValueError("segment_mask must be 1..15")
        return self

class SeriesOut(BaseModel):
    team_id: int | None = None
    id: int
    title: str
    booking_type: str
    court_id: int
    start_dt: datetime
    end_dt: datetime
    rrule: str


class WeatherOut(BaseModel):
    """Weather for a specific time (UTC) at a given location."""

    source: str = "open-meteo"
    latitude: float
    longitude: float
    time_utc: datetime
    temperature_c: float | None = None
    precipitation_mm: float | None = None
    precipitation_probability: int | None = None
    wind_kph: float | None = None
    wind_gust_kph: float | None = None
    weather_code: int | None = None
    summary_de: str | None = None
    warnings: list[str] = []


class EventIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    event_type: str = Field(default="event", max_length=30)
    description: str | None = None
    court_id: int | None = None
    location_label: str | None = None
    start_dt: datetime
    end_dt: datetime
    capacity: int | None = Field(default=None, ge=1)
    is_public: bool = False
    weather_lat: float | None = None
    weather_lon: float | None = None
    weather_location_label: str | None = None

    @field_validator("start_dt", "end_dt")
    @classmethod
    def _require_tz(cls, v: datetime) -> datetime:
        if v.tzinfo is None or v.utcoffset() is None:
            raise ValueError("start_dt/end_dt must include a timezone offset")
        return v.astimezone(timezone.utc)

    @model_validator(mode="after")
    def _validate_range(self):
        if self.end_dt <= self.start_dt:
            raise ValueError("end_dt must be after start_dt")
        return self


class EventOut(BaseModel):
    team_id: int | None = None
    id: int
    title: str
    event_type: str
    description: str | None = None
    court_id: int | None = None
    location_label: str | None = None
    start_dt: datetime
    end_dt: datetime
    capacity: int | None = None
    is_public: bool
    weather_lat: float | None = None
    weather_lon: float | None = None
    weather_location_label: str | None = None
    created_by: int


class EventInviteIn(BaseModel):
    emails: list[EmailStr] = Field(default_factory=list)


class EventParticipantOut(BaseModel):
    id: int
    event_id: int
    email: EmailStr
    status: Literal["invited", "accepted", "declined"]
    responded_at: datetime | None = None

class TeamCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    description: str | None = None
    trainer_user_ids: list[int] | None = None


class TeamOut(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class TeamMemberIn(BaseModel):
    user_id: int
    role: str = Field(default="member", pattern=r"^(member|trainer|guardian)$")


class TeamMembersUpdate(BaseModel):
    members: list[TeamMemberIn]


class TeamMemberUser(BaseModel):
    user_id: int
    email: str
    role: str


class TeamDetailOut(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    trainers: list[TeamMemberUser] = []
    members: list[TeamMemberUser] = []
