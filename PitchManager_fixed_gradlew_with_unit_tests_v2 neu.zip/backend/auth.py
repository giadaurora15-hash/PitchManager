from __future__ import annotations

from datetime import datetime, timedelta, timezone
import jwt
import bcrypt
from fastapi import HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .db import get_db
from .core.config import get_settings
from .models import User
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

_settings = get_settings()
JWT_SECRET = _settings.jwt_secret
JWT_ALG = _settings.jwt_algorithm
JWT_EXP_HOURS = _settings.jwt_exp_hours

def hash_password(pw: str) -> str:
    # bcrypt expects bytes; store the resulting hash as a UTF-8 string.
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(pw.encode("utf-8"), salt)
    return hashed.decode("utf-8")

def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False

def create_access_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role,
        "iat": now,
        "exp": now + timedelta(hours=JWT_EXP_HOURS),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def get_current_user(db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)) -> User:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        uid = int(payload["sub"])
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = db.get(User, uid)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

def require_roles(*roles: str):
    def dep(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Forbidden")
        return user
    return dep
