import pathlib
import sys
import pytest
from fastapi.testclient import TestClient

# Ensure repo root on path so `import backend...` works no matter where pytest is run from.
REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from backend.main import app


def _bootstrap_admin():
    from backend.db import SessionLocal
    from backend import models
    from backend.auth import hash_password
    email='admin_smoke@example.com'
    pw='Admin12345!'
    with SessionLocal() as db:
        if not db.query(models.User).filter(models.User.email==email).first():
            db.add(models.User(email=email, role='admin', password_hash=hash_password(pw)))
            db.commit()
    return email,pw


def _login(client, email, password):
    r = client.post('/auth/login', data={'username': email, 'password': password})
    assert r.status_code == 200, r.text
    return r.json()['access_token']


@pytest.fixture(scope="session")
def client():
    return TestClient(app)

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200

def test_openapi(client):
    r = client.get("/openapi.json")
    assert r.status_code == 200
    assert "paths" in r.json()

def test_dashboard_live(client):
    email,pw = _bootstrap_admin()
    token = _login(client, email, pw)
    r = client.get('/dashboard/live', headers={'Authorization': f'Bearer {token}'})
    assert r.status_code == 200
    j = r.json()
    assert 'occupancy' in j
    assert isinstance(j['occupancy'], list)
