import pathlib
import sys
import datetime as dt
import pytest

# Ensure repo root on path so `import backend...` works no matter where pytest is run from.
REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from backend import rules
from backend import auth
from backend.schemas import BookingIn
from backend.models import User


class DummyDB:
    def __init__(self, user=None):
        self._user = user
    def get(self, model, pk):
        # minimal SQLAlchemy Session.get-like stub
        if model is User and self._user and int(pk) == int(self._user.id):
            return self._user
        return None


def aware(dt_str: str) -> dt.datetime:
    # Helper to build timezone-aware datetimes from ISO strings.
    return dt.datetime.fromisoformat(dt_str)


def test_rules_age_rank():
    assert rules.age_rank(None) == 0
    assert rules.age_rank("") == 0
    assert rules.age_rank("c") == rules.AGE_RANK["C"]
    assert rules.age_rank(" Senioren ") == rules.AGE_RANK["SENIOREN"]
    assert rules.age_rank("unknown") == 0


def test_rules_parse_types():
    assert rules.parse_types("") == set()
    assert rules.parse_types(" spieltag , Turnier ") == {"spieltag", "turnier"}
    assert rules.parse_types("a,b,a") == {"a", "b"}


def test_rules_should_force_full_field():
    # Booking type not in allowed list -> False
    assert rules.should_force_full_field("spieltag", "C", "C", "turnier") is False
    # Booking type in allowed list but too young -> False
    assert rules.should_force_full_field("turnier", "D", "C", "turnier,spieltag") is False
    # Booking type in list and age >= min -> True
    assert rules.should_force_full_field("turnier", "C", "C", "turnier,spieltag") is True
    # Missing age_group -> age_rank 0 -> False
    assert rules.should_force_full_field("turnier", None, "C", "turnier") is False


def test_auth_hash_and_verify_password_roundtrip():
    pw = "S3cure!pass"
    hashed = auth.hash_password(pw)
    assert isinstance(hashed, str) and len(hashed) > 20
    assert auth.verify_password(pw, hashed) is True
    assert auth.verify_password("wrong", hashed) is False


def test_auth_create_access_token_contains_expected_claims():
    u = User(id=123, email="a@example.com", role="admin")
    token = auth.create_access_token(u)
    payload = auth.jwt.decode(token, auth.JWT_SECRET, algorithms=[auth.JWT_ALG])
    assert payload["sub"] == "123"
    assert payload["email"] == "a@example.com"
    assert payload["role"] == "admin"
    # exp should be present and in the future (epoch seconds)
    assert "exp" in payload


def test_auth_get_current_user_invalid_token_raises():
    db = DummyDB(User(id=1, email="x@example.com", role="admin"))
    with pytest.raises(Exception) as e:
        auth.get_current_user(db=db, token="not-a-jwt")
    # FastAPI HTTPException has status_code
    assert getattr(e.value, "status_code", None) == 401


def test_auth_get_current_user_user_not_found_raises():
    # Create a token for sub=999 but DB has no such user
    u = User(id=999, email="x@example.com", role="admin")
    token = auth.create_access_token(u)
    db = DummyDB(user=None)
    with pytest.raises(Exception) as e:
        auth.get_current_user(db=db, token=token)
    assert getattr(e.value, "status_code", None) == 401


def test_auth_get_current_user_success():
    u = User(id=42, email="x@example.com", role="trainer")
    token = auth.create_access_token(u)
    db = DummyDB(user=u)
    got = auth.get_current_user(db=db, token=token)
    assert got.id == 42
    assert got.role == "trainer"


def test_auth_require_roles_allows_and_blocks():
    u_admin = User(id=1, email="a@example.com", role="admin")
    u_player = User(id=2, email="p@example.com", role="player")

    dep = auth.require_roles("admin", "trainer")
    assert dep(user=u_admin) is u_admin

    with pytest.raises(Exception) as e:
        dep(user=u_player)
    assert getattr(e.value, "status_code", None) == 403


def test_schema_bookingin_requires_timezone_and_normalizes_to_utc():
    # Naive datetimes should fail
    with pytest.raises(ValueError):
        BookingIn(
            booking_type="spieltag",
            court_id=1,
            start_dt=dt.datetime(2026, 1, 3, 10, 0, 0),
            end_dt=dt.datetime(2026, 1, 3, 11, 0, 0),
        )

    b = BookingIn(
        booking_type="spieltag",
        court_id=1,
        start_dt=aware("2026-01-03T10:00:00+01:00"),
        end_dt=aware("2026-01-03T11:00:00+01:00"),
    )
    # normalized to UTC
    assert b.start_dt.tzinfo is not None
    assert b.start_dt.utcoffset() == dt.timedelta(0)
    assert b.end_dt.utcoffset() == dt.timedelta(0)


def test_schema_bookingin_validates_range_and_same_day():
    # end before start
    with pytest.raises(ValueError):
        BookingIn(
            booking_type="spieltag",
            court_id=1,
            start_dt=aware("2026-01-03T10:00:00+01:00"),
            end_dt=aware("2026-01-03T09:00:00+01:00"),
        )

    # spans multiple UTC days should fail (note +01 offset turns end into next UTC day)
    with pytest.raises(ValueError):
        BookingIn(
            booking_type="spieltag",
            court_id=1,
            start_dt=aware("2026-01-03T23:30:00+01:00"),
            end_dt=aware("2026-01-04T00:30:00+01:00"),
        )
