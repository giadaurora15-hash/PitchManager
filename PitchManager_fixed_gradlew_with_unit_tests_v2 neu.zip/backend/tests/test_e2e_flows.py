import os
import pathlib
import sys
import uuid
import pytest
from fastapi.testclient import TestClient

REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

# Use a temp SQLite DB file for test isolation
TEST_DB = REPO_ROOT / "backend" / "test_e2e.db"

@pytest.fixture(scope="session", autouse=True)
def _env():
    # Ensure a clean DB for the whole session
    if TEST_DB.exists():
        TEST_DB.unlink()
    os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB}"
    os.environ["AUTO_MIGRATE"] = "false"
    os.environ["AUTO_CREATE_DB"] = "true"
    yield
    if TEST_DB.exists():
        TEST_DB.unlink()

@pytest.fixture(scope="session")
def client():
    from backend.main import app
    # Create tables directly for tests (works even without Alembic in CI)
    from backend.db import Base, get_engine
    Base.metadata.create_all(bind=get_engine())
    return TestClient(app)

def _login(client, email, password):
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]

def _auth_headers(token):
    return {"Authorization": f"Bearer {token}"}

def test_full_core_flow(client):
    # 1) Bootstrap admin (may be blocked if already exists; in clean DB it should succeed)
    admin_email = "admin@example.com"
    admin_pw = "Admin12345!"
    r = client.post("/auth/register", json={"email": admin_email, "password": admin_pw, "role": "admin"})
    assert r.status_code in (200, 201, 409, 400, 403), r.text

    # fallback: some deployments disable bootstrap registration entirely
    if r.status_code == 403 and "invitation" in r.text.lower():
        from backend.db import SessionLocal
        from backend import models
        from backend.auth import hash_password
        with SessionLocal() as db:
            if not db.query(models.User).filter(models.User.email == admin_email).first():
                db.add(models.User(email=admin_email, role="admin", password_hash=hash_password(admin_pw)))
                db.commit()

    admin_token = _login(client, admin_email, admin_pw)
    h_admin = _auth_headers(admin_token)

    # 1b) Create a team (admin)
    r = client.post("/teams", json={"name": f"U13 Mannschaft {uuid.uuid4().hex[:6]}", "description": "Jugend"}, headers=h_admin)
    assert r.status_code in (200, 201, 400, 409), r.text  # if validation differs
    r = client.get("/teams", headers=h_admin)
    assert r.status_code == 200
    assert isinstance(r.json(), list)

    # 2) Create club and court (if endpoints exist)
    club_name = f"Verein {uuid.uuid4().hex[:6]}"
    r = client.post("/clubs", json={"name": club_name}, headers=h_admin)
    assert r.status_code in (200, 201, 400, 409), r.text

    # Fetch courts list (may be empty initially)
    r = client.get("/courts", headers=h_admin)
    assert r.status_code == 200, r.text
    courts = r.json()
    if not courts:
        # If create endpoint exists in your codebase, create one court via direct DB fallback
        # (keeps tests compatible even if only PUT exists).
        from backend.db import SessionLocal
        from backend import models
        with SessionLocal() as db:
            c = models.Court(name="Platz 1", latitude=52.52, longitude=13.405)
            db.add(c)
            db.commit()
    r = client.get("/courts", headers=h_admin)
    courts = r.json()
    assert len(courts) >= 1
    court_id = courts[0]["id"]

    # 3) Create an invite for a player
    player_email = f"player_{uuid.uuid4().hex[:6]}@example.com"
    r = client.post("/invites", json={"emails":[player_email], "role":"player"}, headers=h_admin)
    assert r.status_code in (200, 201), r.text
    data = r.json()
    # Expect token or links returned
    token = None
    if isinstance(data, dict):
        token = data.get("token") or (data.get("invites",[{}])[0].get("token") if "invites" in data else None)
        if token is None and "links" in data and data["links"]:
            token = data["links"][0].split("/")[-1]
    elif isinstance(data, list) and data:
        token = data[0].get("token")
    assert token, f"No invite token in response: {data}"

    # 4) Register with invite
    pw = "Player12345!"
    r = client.post("/auth/register-with-invite", json={"token": token, "email": player_email, "password": pw})
    assert r.status_code in (200, 201), r.text

    # 5) Player login
    player_token = _login(client, player_email, pw)
    h_player = _auth_headers(player_token)

    # 6) Create a booking (player)
    # Use a simple 1-hour booking now+1h (server may enforce future; accept 400 as non-fatal)
    import datetime as dt
    start = dt.datetime.now(dt.timezone.utc).replace(minute=0, second=0, microsecond=0) + dt.timedelta(hours=2)
    end = start + dt.timedelta(hours=1)

    booking_payload = {
        "court_id": court_id,
        "booking_type": "training",
        "start_dt": start.isoformat().replace("+00:00","Z"),
        "end_dt": end.isoformat().replace("+00:00","Z"),
        "weather_lat": 52.52,
        "weather_lon": 13.405,
        "weather_location_label": "Berlin"
    }
    r = client.post("/bookings", json=booking_payload, headers=h_player)
    assert r.status_code in (200, 201, 400, 409), r.text

    # 7) Create an event (admin/trainer)
    event_payload = {
        "title": "Sommerfest",
        "event_type": "event",
        "start_dt": start.isoformat().replace("+00:00","Z"),
        "end_dt": end.isoformat().replace("+00:00","Z"),
        "location": "Vereinsheim",
        "capacity": 5
    }
    r = client.post("/events", json=event_payload, headers=h_admin)
    assert r.status_code in (200, 201), r.text
    event = r.json()
    event_id = event.get("id") or event.get("event_id")
    assert event_id

    # 8) Invite participant to event (admin)

    # 8b) Invite whole team (admin)
    r = client.post(f"/events/{event_id}/invite_team?team_id=1", headers=h_admin)
    assert r.status_code in (200, 201, 400, 404, 422), r.text


    r = client.post(f"/events/{event_id}/invite", json={"emails":[player_email]}, headers=h_admin)
    assert r.status_code in (200, 201, 400, 409), r.text  # SMTP may be missing -> should still store invite

    # 9) Get ICS
    r = client.get(f"/events/{event_id}/ics", headers=h_player)
    assert r.status_code in (200, 401, 403), r.text  # Depending on access rules
