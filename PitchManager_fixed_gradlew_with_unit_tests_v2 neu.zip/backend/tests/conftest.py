import os
from pathlib import Path


def pytest_sessionstart(session):
    """Ensure the SQLite test database starts clean.

    CI sets DATABASE_URL to a file-based sqlite DB (e.g. sqlite:///./test_ci.db).
    If the file exists (e.g. on re-runs), state can leak across test sessions and
    cause false "booking conflict" failures.
    """

    db_url = os.getenv("DATABASE_URL", "").strip()
    if not db_url.startswith("sqlite:///") or ":memory:" in db_url:
        return

    # sqlite:///relative/path.db  -> relative to current working dir
    # sqlite:////abs/path.db      -> absolute path
    if db_url.startswith("sqlite:////"):
        raw_path = db_url[len("sqlite:////"):]
        db_path = Path("/" + raw_path)
    else:
        raw_path = db_url[len("sqlite:///"):]
        db_path = Path(raw_path)
    try:
        if db_path.exists() and db_path.is_file():
            db_path.unlink()
    except OSError:
        # If deletion fails, let tests proceed; they'll surface a clearer error.
        pass
