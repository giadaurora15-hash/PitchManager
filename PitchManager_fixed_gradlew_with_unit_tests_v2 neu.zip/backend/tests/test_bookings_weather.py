import os
import pathlib
import sys
import datetime as dt

import pytest
from fastapi.testclient import TestClient


REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

TEST_DB = REPO_ROOT / "backend" / "test_bookings_weather.db"


@pytest.fixture(scope="module", autouse=True)
def _env():
    if TEST_DB.exists():
        TEST_DB.unlink()
    os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB}"
    os.environ["AUTO_MIGRATE"] = "false"
    os.environ["AUTO_CREATE_DB"] = "true"
    yield
    if TEST_DB.exists():
        TEST_DB.unlink()


@pytest.fixture(scope="module")
def client():
    from backend.main import app
    from backend.db import Base, get_engine
    Base.metadata.create_all(bind=get_engine())
    return TestClient(app)


def _login(client, email, password):
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def _auth_headers(token):
    return {"Authorization": f"Bearer {token}"}


def _bootstrap_admin(email="admin_bw@example.com", pw="Admin12345!"):
    from backend.db import SessionLocal
    from backend import models
    from backend.auth import hash_password

    with SessionLocal() as db:
        if not db.query(models.User).filter(models.User.email == email).first():
            db.add(models.User(email=email, role="admin", password_hash=hash_password(pw)))
            db.commit()
    return email, pw


def _ensure_court():
    from backend.db import SessionLocal
    from backend import models

    with SessionLocal() as db:
        c = db.query(models.Court).first()
        if c:
            return c.id
        c = models.Court(name="Platz 1", latitude=52.52, longitude=13.405)
        db.add(c)
        db.commit()
        db.refresh(c)
        return c.id


def test_openapi_has_patch_booking(client):
    r = client.get("/openapi.json")
    assert r.status_code == 200
    paths = r.json().get("paths", {})
    assert "/bookings/{booking_id}" in paths
    assert "patch" in paths["/bookings/{booking_id}"]


def test_cancel_series_and_update_booking(client):
    email, pw = _bootstrap_admin()
    token = _login(client, email, pw)
    h = _auth_headers(token)
    court_id = _ensure_court()

    start = dt.datetime.now(dt.timezone.utc).replace(minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
    end = start + dt.timedelta(hours=1)

    # Create series
    series_payload = {
        "title": "Test-Serie",
        "court_id": court_id,
        "booking_type": "training",
        "start_dt": start.isoformat().replace("+00:00", "Z"),
        "end_dt": end.isoformat().replace("+00:00", "Z"),
        "segment_mask": 1,
        "rrule": "FREQ=DAILY;COUNT=3",
    }
    r = client.post("/series", json=series_payload, headers=h)
    assert r.status_code in (200, 201), r.text
    series_id = r.json()["id"]

    # List bookings, pick one booking from series
    r = client.get("/bookings", headers=h)
    assert r.status_code == 200, r.text
    bookings = [b for b in r.json() if b.get("series_id") == series_id]
    assert bookings, "Expected bookings created for series"
    booking_id = bookings[0]["id"]

    # Update booking time via PATCH
    new_start = start + dt.timedelta(hours=2)
    new_end = new_start + dt.timedelta(hours=1)
    r = client.patch(
        f"/bookings/{booking_id}",
        json={
            "start_dt": new_start.isoformat().replace("+00:00", "Z"),
            "end_dt": new_end.isoformat().replace("+00:00", "Z"),
        },
        headers=h,
    )
    assert r.status_code in (200, 201), r.text

    # Cancel only the updated booking
    r = client.post(f"/series/{series_id}/cancel?scope=one&booking_id={booking_id}", headers=h)
    assert r.status_code == 200, r.text
    assert r.json().get("status") == "ok"
    assert r.json().get("cancelled") == 1


def test_weather_provider_failure_returns_502(client, monkeypatch):
    email, pw = _bootstrap_admin("admin_bw2@example.com")
    token = _login(client, email, pw)
    h = _auth_headers(token)

    # Force the provider call to fail inside the real provider fetch.
    from backend.routers import weather_router
    import httpx

    class _FailingClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def get(self, *args, **kwargs):
            raise httpx.ConnectError("no network")

    monkeypatch.setattr(weather_router.httpx, "AsyncClient", _FailingClient)

    r = client.get("/weather/current?lat=52.52&lon=13.405", headers=h)
    assert r.status_code == 502