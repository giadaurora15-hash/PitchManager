from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

from .core.config import get_settings

_engine = None
_engine_url: str | None = None


def get_engine():
    """Return a SQLAlchemy Engine for the current DATABASE_URL.

    Tests in this repo change DATABASE_URL via environment variables.
    Creating the engine at import time can lead to state leaking across
    test modules. We therefore lazily create (and recreate) the engine when
    the URL changes.
    """
    global _engine, _engine_url
    url = get_settings().database_url
    if _engine is None or url != _engine_url:
        connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
        _engine = create_engine(url, connect_args=connect_args)
        _engine_url = url
    return _engine


def SessionLocal():  # noqa: N802 (keep legacy name used throughout the repo)
    """Create a new Session bound to the current engine."""
    SessionMaker = sessionmaker(bind=get_engine(), autoflush=False, autocommit=False)
    return SessionMaker()

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
