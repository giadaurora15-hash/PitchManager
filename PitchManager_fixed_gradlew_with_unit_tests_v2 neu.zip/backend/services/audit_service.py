from __future__ import annotations
import json
from typing import Any, Optional
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from ..models import AuditLog

def log_action(
    db: Session,
    *,
    actor_user_id: Optional[int],
    action: str,
    entity_type: str,
    entity_id: Optional[int] = None,
    payload: Optional[dict[str, Any]] = None,
) -> None:
    """Best-effort audit log. Never raises."""
    try:
        entry = AuditLog(
            actor_user_id=actor_user_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            payload_json=json.dumps(payload, ensure_ascii=False) if payload else None,
            created_at=datetime.now(timezone.utc),
        )
        db.add(entry)
        db.commit()
    except Exception:
        db.rollback()
