from __future__ import annotations

import smtplib
from email.message import EmailMessage

from ..core.config import get_settings


def send_email(to_email: str, subject: str, text: str) -> None:
    """Send a plain-text email using SMTP settings from environment.

    If SMTP is not configured, this raises RuntimeError so callers can return a helpful error.
    """

    s = get_settings()
    if not s.smtp_host:
        raise RuntimeError("SMTP is not configured (set SMTP_HOST/SMTP_PORT/SMTP_FROM, etc.)")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = s.smtp_from
    msg["To"] = to_email
    msg.set_content(text)

    port = int(s.smtp_port)
    if s.smtp_tls:
        server = smtplib.SMTP(s.smtp_host, port)
        server.starttls()
    else:
        server = smtplib.SMTP(s.smtp_host, port)

    try:
        if s.smtp_user:
            server.login(s.smtp_user, s.smtp_password or "")
        server.send_message(msg)
    finally:
        try:
            server.quit()
        except Exception:
            pass
