"""Shim submodule for `from multipart.multipart import ...` imports."""

from python_multipart.multipart import *  # noqa: F403,F401
