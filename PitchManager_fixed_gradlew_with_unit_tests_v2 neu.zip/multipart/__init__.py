"""Local shim to satisfy Starlette/FastAPI `import multipart`.

We forward to `python_multipart` to avoid PendingDeprecationWarning under
strict test settings (`-W error`).
"""

from python_multipart import __version__  # noqa: F401
from python_multipart.multipart import MultipartParser, QuerystringParser  # noqa: F401
